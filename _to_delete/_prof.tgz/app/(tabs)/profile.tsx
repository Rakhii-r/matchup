/**
 * Profile — the player's own statistics screen.
 *
 * Every figure on it is either a column returned by `get_player_stats` /
 * `get_player_batting_history` or a stated division of two of them (an average
 * per match, a share of matches). Nothing is seeded, estimated or extrapolated,
 * which is why the whole screen has to read correctly at zero.
 *
 * Two things the reference design has and this does not, on purpose:
 *   - No "Level 12 / Pro Player" badge. There is no level, rank or XP column
 *     anywhere in the schema, and deriving one from match count would invent a
 *     product mechanic rather than report a fact.
 *   - No Fielding tab, and no Bowling tab. Nothing records a catch or a run-out
 *     against a fielder, and `wickets` is the only bowling figure that exists —
 *     one number is a tile, not a section, so it sits in Overview.
 *
 * The account settings, admin rows and logout that used to be the whole screen
 * are unchanged; they now sit below the statistics.
 */
import { useMemo, useState } from 'react';
import { Image, Pressable, ScrollView, StyleSheet, View, useWindowDimensions } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { useRouter } from 'expo-router';
import Svg, { Circle, Line, Polyline, Text as SvgText } from 'react-native-svg';

import { authRepository } from '@features/auth/data/authRepository';
import { useAuthStore } from '@core/auth/authStore';
import {
  PLAYING_ROLE_LABEL,
  type BattingHistoryRow,
  type PlayerStats,
} from '@features/dashboard/data/dashboardRepository';
import {
  usePlayerBattingHistory,
  usePlayerStats,
} from '@features/dashboard/presentation/useDashboard';
import { useSportLabel } from '@features/sports/presentation/useSports';
import type { Sport } from '@shared/types/database.types';
import { useTheme } from '@shared/theme/ThemeContext';
import { R, S, useMock, type MockPalette } from '@shared/theme/mockTheme';
import { AppLogo } from '@shared/ui/AppLogo';
import { AppText } from '@shared/ui/AppText';
import {
  IconBolt,
  IconChevron,
  IconMoon,
  IconSun,
  IconEdit,
  IconGear,
  IconLogout,
  IconMenu,
  IconPin,
  IconShieldCheck,
  IconStar,
  IconUser,
} from '@shared/ui/icons';

type Styles = ReturnType<typeof makeStyles>;

/**
 * A line chart needs a line. Below three points the "trend" is a single segment
 * or a lone dot, which reads as a broken chart rather than as an absence of
 * data, so the section says so in words instead. An account whose only
 * completed match predates in-app scoring lands here, and that is the state
 * this screen ships in.
 */
const MIN_TREND_POINTS = 3;

const CHART_HEIGHT = 168;
const PAD_L = 34;
const PAD_R = 14;
const PAD_T = 20;
const PAD_B = 24;

const MONTH = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];

const OUTCOME_LABEL: Record<BattingHistoryRow['outcome'], string> = {
  won: 'Won',
  lost: 'Lost',
  tied: 'Tied',
};

type TabKey = 'overview' | 'batting' | 'recent';

const TABS: { key: TabKey; label: string }[] = [
  { key: 'overview', label: 'Overview' },
  { key: 'batting', label: 'Batting' },
  { key: 'recent', label: 'Recent' },
];

// A factory rather than a constant: the tints are palette values, and a frozen
// array would keep dark tints after a switch to light.
const settingsFor = (
  M: MockPalette,
): { key: string; label: string; Icon: typeof IconEdit; tint: string; route?: string }[] => [
  { key: 'edit', label: 'Edit Profile', Icon: IconEdit, tint: M.border, route: '/profile/edit' },
  { key: 'sports', label: 'Sport Preferences', Icon: IconBolt, tint: M.border, route: '/profile/edit' },
];

function formatDay(iso: string): string {
  const d = new Date(iso);
  return `${d.getDate()} ${MONTH[d.getMonth()]} ${String(d.getFullYear()).slice(2)}`;
}

/**
 * A per-match average, or an em dash. With no matches played the division is
 * 0/0: printing "0.00" would claim a measured average of zero, and printing the
 * raw result would put NaN on screen.
 */
function perMatch(total: number, matches: number): string {
  return matches > 0 ? (total / matches).toFixed(2) : '—';
}

function shareOfMatches(part: number, matches: number): string {
  return matches > 0 ? `${Math.round((100 * part) / matches)}% of matches` : '—';
}

interface FormatBucket {
  key: string;
  label: string;
  matches: number;
  runs: number;
  avg: string;
}

/**
 * Group the history by `matches.overs`. That column is nullable — fixtures from
 * before the format was captured have no value — so those rows are labelled as
 * unrecorded rather than assigned a guessed format. When NO row has an overs
 * value there is nothing to compare and the caller drops the section entirely.
 */
function buildFormats(rows: BattingHistoryRow[]): FormatBucket[] {
  if (!rows.some((r) => r.overs !== null)) return [];
  const byKey = new Map<string, { overs: number | null; matches: number; runs: number }>();
  for (const row of rows) {
    const key = row.overs === null ? 'unrecorded' : String(row.overs);
    const bucket = byKey.get(key) ?? { overs: row.overs, matches: 0, runs: 0 };
    byKey.set(key, {
      overs: bucket.overs,
      matches: bucket.matches + 1,
      runs: bucket.runs + row.runs,
    });
  }
  return [...byKey.values()]
    .sort((a, b) => (a.overs ?? Number.MAX_SAFE_INTEGER) - (b.overs ?? Number.MAX_SAFE_INTEGER))
    .map((b) => ({
      key: b.overs === null ? 'unrecorded' : String(b.overs),
      label: b.overs === null ? 'Format not recorded' : `${b.overs} overs`,
      matches: b.matches,
      runs: b.runs,
      avg: perMatch(b.runs, b.matches),
    }));
}

function SectionHeading({
  styles,
  M,
  title,
}: {
  styles: Styles;
  M: MockPalette;
  title: string;
}): React.ReactNode {
  return (
    <View style={styles.sectionHeading}>
      <AppText variant="heading" color={M.text} style={styles.sectionTitle}>
        {title}
      </AppText>
    </View>
  );
}

/** A load failure states itself and offers the retry, instead of reading as "no data". */
function Notice({
  styles,
  M,
  text,
  onRetry,
}: {
  styles: Styles;
  M: MockPalette;
  text: string;
  onRetry: () => void;
}): React.ReactNode {
  return (
    <View style={styles.notice}>
      <AppText variant="caption" color={M.muted} style={styles.noticeText}>
        {text}
      </AppText>
      <Pressable style={styles.retry} onPress={onRetry} accessibilityRole="button">
        <AppText variant="label" color={M.text}>
          Retry
        </AppText>
      </Pressable>
    </View>
  );
}

function HeroCard({
  styles,
  M,
  fullName,
  areaName,
  avatarUrl,
  roleLabel,
  sports,
  sportLabel,
  onEdit,
}: {
  styles: Styles;
  M: MockPalette;
  fullName: string | null;
  areaName: string | null;
  avatarUrl: string | null;
  roleLabel: string | null;
  sports: Sport[];
  sportLabel: (sport: Sport) => string;
  onEdit: () => void;
}): React.ReactNode {
  const initial = fullName?.trim().charAt(0).toUpperCase() ?? '';
  return (
    <View style={styles.hero}>
      <View style={styles.avatarWrap}>
        <View style={styles.avatar}>
          {avatarUrl ? (
            <Image source={{ uri: avatarUrl }} style={styles.avatarImg} />
          ) : initial ? (
            <AppText variant="title" color={M.text} style={styles.avatarInitial}>
              {initial}
            </AppText>
          ) : (
            <IconUser color={M.faint} size={44} />
          )}
        </View>
        {/*
          A 32px badge with 8px hitSlop: the tappable area clears 44pt without a
          44px disc covering a third of the avatar it sits on.
        */}
        <Pressable
          style={styles.avatarEdit}
          onPress={onEdit}
          hitSlop={8}
          accessibilityRole="button"
          accessibilityLabel="Edit profile photo and details"
        >
          <IconEdit color={M.limeInk} size={16} />
        </Pressable>
      </View>

      <AppText variant="title" color={M.text} style={styles.heroName}>
        {fullName || 'Your profile'}
      </AppText>

      {areaName ? (
        <View style={styles.heroRow}>
          <IconPin color={M.muted} size={14} />
          <AppText variant="caption" color={M.muted} style={styles.heroArea}>
            {areaName}
          </AppText>
        </View>
      ) : null}

      <View style={styles.chipRow}>
        {roleLabel ? (
          <View style={[styles.chip, { backgroundColor: M.chip }]}>
            <IconStar color={M.green} size={13} />
            <AppText variant="caption" color={M.text} style={styles.chipText}>
              {roleLabel}
            </AppText>
          </View>
        ) : null}
        {sports.map((sport) => (
          <View key={sport} style={[styles.chip, { backgroundColor: M.chip }]}>
            <IconBolt color={M.muted} size={13} />
            <AppText variant="caption" color={M.muted} style={styles.chipText}>
              {sportLabel(sport)}
            </AppText>
          </View>
        ))}
      </View>
    </View>
  );
}

function CareerRow({
  styles,
  M,
  stats,
}: {
  styles: Styles;
  M: MockPalette;
  stats: PlayerStats | null | undefined;
}): React.ReactNode {
  const cells: { label: string; value: string }[] = [
    { label: 'Matches Played', value: stats ? String(stats.matches_played) : '—' },
    { label: 'Runs Scored', value: stats ? String(stats.runs) : '—' },
    { label: 'Wickets Taken', value: stats ? String(stats.wickets) : '—' },
    { label: 'Player of Match', value: stats ? String(stats.motm) : '—' },
  ];
  return (
    <View style={styles.careerCard}>
      {cells.map((cell, i) => (
        <View key={cell.label} style={[styles.careerCell, i > 0 ? styles.careerCellDivided : null]}>
          <AppText variant="heading" color={M.text} style={styles.careerValue}>
            {cell.value}
          </AppText>
          <AppText variant="caption" color={M.muted} center style={styles.careerLabel}>
            {cell.label}
          </AppText>
        </View>
      ))}
    </View>
  );
}

function TabBar({
  styles,
  M,
  active,
  onChange,
}: {
  styles: Styles;
  M: MockPalette;
  active: TabKey;
  onChange: (key: TabKey) => void;
}): React.ReactNode {
  return (
    <View style={styles.tabBar} accessibilityRole="tablist">
      {TABS.map((tab) => {
        const on = tab.key === active;
        return (
          <Pressable
            key={tab.key}
            style={[styles.tab, on ? { backgroundColor: M.lime } : null]}
            onPress={() => onChange(tab.key)}
            accessibilityRole="tab"
            accessibilityState={{ selected: on }}
          >
            <AppText variant="label" color={on ? M.limeInk : M.muted} style={styles.tabText}>
              {tab.label}
            </AppText>
          </Pressable>
        );
      })}
    </View>
  );
}

function PerfTile({
  styles,
  M,
  label,
  value,
  sub,
}: {
  styles: Styles;
  M: MockPalette;
  label: string;
  value: string;
  sub: string;
}): React.ReactNode {
  return (
    <View style={styles.tile}>
      <AppText variant="caption" color={M.muted}>
        {label}
      </AppText>
      <AppText variant="title" color={M.text} style={styles.tileValue}>
        {value}
      </AppText>
      <AppText variant="caption" color={M.faint}>
        {sub}
      </AppText>
    </View>
  );
}

/**
 * Runs per match, oldest→newest. One series, so there is no legend — the
 * section title names it — and one y axis, 0 to the best score in the window.
 * Only the axis ends and the latest point carry a number; labelling every point
 * turns a chart into a table with a line drawn through it.
 *
 * `M.green` is the series colour and is contrast-validated against `M.card`
 * (7.81:1 dark, 4.91:1 light). Every glyph of text stays in `M.muted`/`M.text`,
 * never in the series colour.
 *
 * Assumes `rows.length >= MIN_TREND_POINTS`; the caller enforces that.
 */
function RunsTrendChart({
  styles,
  M,
  rows,
  width,
}: {
  styles: Styles;
  M: MockPalette;
  rows: BattingHistoryRow[];
  width: number;
}): React.ReactNode {
  const geom = useMemo(() => {
    const plotW = Math.max(width - PAD_L - PAD_R, 40);
    const plotH = CHART_HEIGHT - PAD_T - PAD_B;
    const best = rows.reduce((max, r) => Math.max(max, r.runs), 0);
    // An all-zero series still needs a domain with height, or every point
    // divides by zero. The top label prints this value, so it never lies.
    const yTop = best > 0 ? best : 1;
    const px = (i: number) => PAD_L + (plotW * i) / (rows.length - 1);
    const py = (v: number) => PAD_T + plotH - (plotH * v) / yTop;
    const dots = rows.map((row, i) => ({ x: px(i), y: py(row.runs), key: row.match_id }));
    // The caller only renders this for MIN_TREND_POINTS or more rows, so these
    // are always present; reading them through a guard rather than a non-null
    // assertion keeps the geometry honest under noUncheckedIndexedAccess.
    const oldest = rows[0];
    const latest = rows[rows.length - 1];
    if (!oldest || !latest) return null;
    return {
      dots,
      last: { x: px(rows.length - 1), y: py(latest.runs) },
      points: dots.map((d) => `${d.x},${d.y}`).join(' '),
      grid: [0, yTop / 2, yTop].map((v) => py(v)),
      yTop,
      baseline: py(0),
      lastRuns: latest.runs,
      firstLabel: formatDay(oldest.played_at),
      lastLabel: formatDay(latest.played_at),
    };
  }, [rows, width]);

  if (!geom) return null;

  return (
    <View
      accessible
      accessibilityLabel={`Runs over time. ${rows.length} matches, ${geom.firstLabel} to ${geom.lastLabel}. Best ${geom.yTop} runs, latest ${geom.lastRuns} runs.`}
    >
      <Svg width={width} height={CHART_HEIGHT}>
        {geom.grid.map((gy) => (
          <Line
            key={`grid-${gy}`}
            x1={PAD_L}
            y1={gy}
            x2={width - PAD_R}
            y2={gy}
            stroke={M.border}
            strokeWidth={1}
          />
        ))}
        <Polyline
          points={geom.points}
          fill="none"
          stroke={M.green}
          strokeWidth={2}
          strokeLinecap="round"
          strokeLinejoin="round"
        />
        {geom.dots.map((d, i) => {
          const latest = i === geom.dots.length - 1;
          return (
            <Circle
              key={d.key}
              cx={d.x}
              cy={d.y}
              r={latest ? 5 : 4}
              fill={latest ? M.green : M.card}
              stroke={latest ? M.card : M.green}
              strokeWidth={2}
            />
          );
        })}
        <SvgText x={PAD_L - 6} y={PAD_T + 4} fill={M.muted} fontSize={11} textAnchor="end">
          {String(geom.yTop)}
        </SvgText>
        <SvgText x={PAD_L - 6} y={geom.baseline + 4} fill={M.muted} fontSize={11} textAnchor="end">
          0
        </SvgText>
        <SvgText x={PAD_L} y={CHART_HEIGHT - 6} fill={M.muted} fontSize={11} textAnchor="start">
          {geom.firstLabel}
        </SvgText>
        <SvgText
          x={width - PAD_R}
          y={CHART_HEIGHT - 6}
          fill={M.muted}
          fontSize={11}
          textAnchor="end"
        >
          {geom.lastLabel}
        </SvgText>
        <SvgText
          x={geom.last.x}
          y={Math.max(geom.last.y - 12, 12)}
          fill={M.text}
          fontSize={12}
          fontWeight="700"
          textAnchor="end"
        >
          {String(geom.lastRuns)}
        </SvgText>
      </Svg>
      <AppText variant="caption" color={M.faint} style={styles.chartFoot}>
        Runs per match, oldest to newest
      </AppText>
    </View>
  );
}

function FormatStats({
  styles,
  M,
  buckets,
}: {
  styles: Styles;
  M: MockPalette;
  buckets: FormatBucket[];
}): React.ReactNode {
  return (
    <View style={styles.card}>
      <View style={styles.formatHead}>
        <AppText variant="caption" color={M.faint} style={styles.formatName}>
          FORMAT
        </AppText>
        <AppText variant="caption" color={M.faint} style={styles.formatNum}>
          M
        </AppText>
        <AppText variant="caption" color={M.faint} style={styles.formatNum}>
          RUNS
        </AppText>
        <AppText variant="caption" color={M.faint} style={styles.formatNum}>
          AVG
        </AppText>
      </View>
      {buckets.map((b) => (
        <View key={b.key} style={styles.formatRow}>
          <AppText variant="label" color={M.text} style={styles.formatName} numberOfLines={1}>
            {b.label}
          </AppText>
          <AppText variant="label" color={M.muted} style={styles.formatNum}>
            {String(b.matches)}
          </AppText>
          <AppText variant="label" color={M.text} style={styles.formatNum}>
            {String(b.runs)}
          </AppText>
          <AppText variant="label" color={M.text} style={styles.formatNum}>
            {b.avg}
          </AppText>
        </View>
      ))}
    </View>
  );
}

function MatchCard({
  styles,
  M,
  row,
}: {
  styles: Styles;
  M: MockPalette;
  row: BattingHistoryRow;
}): React.ReactNode {
  const outcomeColor =
    row.outcome === 'won' ? M.green : row.outcome === 'lost' ? M.danger : M.muted;
  return (
    <View style={styles.matchCard}>
      <View style={styles.matchMain}>
        <View style={styles.matchTitleRow}>
          <AppText variant="label" color={M.text} style={styles.matchOpponent} numberOfLines={1}>
            {row.opponent_name ?? 'Opponent'}
          </AppText>
          {row.is_motm ? (
            <View style={[styles.motm, { backgroundColor: M.lime }]}>
              <IconStar color={M.limeInk} size={11} />
              <AppText variant="caption" color={M.limeInk} style={styles.motmText}>
                POTM
              </AppText>
            </View>
          ) : null}
        </View>
        <View style={styles.matchMetaRow}>
          <AppText variant="caption" color={M.muted}>
            {formatDay(row.played_at)}
          </AppText>
          <AppText variant="caption" color={M.faint} style={styles.dot}>
            ·
          </AppText>
          <AppText variant="caption" color={outcomeColor} style={styles.outcome}>
            {OUTCOME_LABEL[row.outcome]}
          </AppText>
        </View>
      </View>
      <View style={styles.matchScore}>
        <AppText variant="heading" color={M.text}>
          {String(row.runs)}
        </AppText>
        <AppText variant="caption" color={M.muted}>
          {row.fours} × 4s · {row.sixes} × 6s
        </AppText>
      </View>
    </View>
  );
}

export default function ProfileScreen(): React.ReactNode {
  const M = useMock();
  const { isDark, setScheme } = useTheme();
  const styles = useMemo(() => makeStyles(M), [M]);
  const router = useRouter();
  const { width: screenWidth } = useWindowDimensions();
  const profile = useAuthStore((s) => s.profile);
  const isSuperadmin = useAuthStore((s) => s.isSuperadmin);
  const sportLabel = useSportLabel();
  const sports = profile?.sport_pref ?? [];
  const statsQuery = usePlayerStats();
  const historyQuery = usePlayerBattingHistory(10);
  const [tab, setTab] = useState<TabKey>('overview');

  const stats = statsQuery.data;
  const history = historyQuery.data;

  // The RPC returns newest first; a trend reads left to right in time.
  const trendRows = useMemo(() => (history ? [...history].reverse() : []), [history]);
  const formats = useMemo(() => buildFormats(history ?? []), [history]);

  const played = stats?.matches_played ?? 0;
  // The plot sits inside the card's padding, inside the screen's own gutters.
  const chartWidth = Math.max(screenWidth - S.lg * 2 - S.md * 2, 220);

  return (
    <SafeAreaView style={styles.safe} edges={['top', 'left', 'right']}>
      <View style={styles.header}>
        <IconMenu color={M.text} />
        <AppLogo width={84} />
        <IconGear color={M.text} />
      </View>

      <ScrollView contentContainerStyle={styles.scroll} showsVerticalScrollIndicator={false}>
        {/* 1 — identity, from the logged-in profile */}
        <HeroCard
          styles={styles}
          M={M}
          fullName={profile?.full_name ?? stats?.full_name ?? null}
          areaName={profile?.area_name ?? stats?.area_name ?? null}
          avatarUrl={profile?.avatar_url ?? stats?.avatar_url ?? null}
          roleLabel={stats?.playing_role ? PLAYING_ROLE_LABEL[stats.playing_role] : null}
          sports={sports}
          sportLabel={sportLabel}
          onEdit={() => router.push('/profile/edit' as never)}
        />

        {/* 2 — career totals */}
        <CareerRow styles={styles} M={M} stats={stats} />
        {statsQuery.isError ? (
          <Notice
            styles={styles}
            M={M}
            text="Couldn't load your career figures."
            onRetry={() => void statsQuery.refetch()}
          />
        ) : null}

        {/* 3 — tabs. No Fielding tab: nothing in the schema records a catch. */}
        <TabBar styles={styles} M={M} active={tab} onChange={setTab} />

        {/* 4 — every tile is a real column or a stated division of two of them */}
        {tab === 'overview' ? (
          <>
            <SectionHeading styles={styles} M={M} title="Performance" />
            <View style={styles.tileGrid}>
              <PerfTile
                styles={styles}
                M={M}
                label="Runs"
                value={String(stats?.runs ?? 0)}
                sub={`Avg ${perMatch(stats?.runs ?? 0, played)}`}
              />
              <PerfTile
                styles={styles}
                M={M}
                label="Wickets"
                value={String(stats?.wickets ?? 0)}
                sub={`Avg ${perMatch(stats?.wickets ?? 0, played)}`}
              />
              <PerfTile
                styles={styles}
                M={M}
                label="Player of Match"
                value={String(stats?.motm ?? 0)}
                sub={shareOfMatches(stats?.motm ?? 0, played)}
              />
              <PerfTile
                styles={styles}
                M={M}
                label="Win Rate"
                value={`${stats?.win_rate ?? 0}%`}
                sub={`${stats?.wins ?? 0} ${(stats?.wins ?? 0) === 1 ? 'Win' : 'Wins'}`}
              />
            </View>
            <AppText variant="caption" color={M.faint} style={styles.footnote}>
              Wickets is the only bowling figure the app records, so it sits here rather than in a
              section of its own.
            </AppText>
          </>
        ) : null}

        {tab === 'batting' ? (
          <>
            {/* 5 — one series, so the section title is the legend */}
            <SectionHeading styles={styles} M={M} title="Runs Over Time" />
            <View style={styles.card}>
              {historyQuery.isError ? (
                <Notice
                  styles={styles}
                  M={M}
                  text="Couldn't load your batting history."
                  onRetry={() => void historyQuery.refetch()}
                />
              ) : trendRows.length >= MIN_TREND_POINTS ? (
                <RunsTrendChart styles={styles} M={M} rows={trendRows} width={chartWidth} />
              ) : (
                <AppText variant="body" color={M.muted}>
                  Play a few scored matches and your run trend appears here.
                </AppText>
              )}
            </View>

            {/* 6 — dropped entirely while no match has a recorded over count */}
            {formats.length > 0 ? (
              <>
                <SectionHeading styles={styles} M={M} title="Match Format Stats" />
                <FormatStats styles={styles} M={M} buckets={formats} />
              </>
            ) : null}
          </>
        ) : null}

        {/* 7 — no "View All": there is no match-history route to send it to */}
        {tab === 'recent' ? (
          <>
            <SectionHeading styles={styles} M={M} title="Recent Performances" />
            {historyQuery.isError ? (
              <Notice
                styles={styles}
                M={M}
                text="Couldn't load your recent matches."
                onRetry={() => void historyQuery.refetch()}
              />
            ) : history && history.length > 0 ? (
              history.map((row) => <MatchCard key={row.match_id} styles={styles} M={M} row={row} />)
            ) : (
              <View style={styles.card}>
                <AppText variant="body" color={M.text}>
                  {historyQuery.isLoading ? 'Loading your matches…' : 'No completed matches yet'}
                </AppText>
                <AppText variant="caption" color={M.muted} style={styles.emptyHint}>
                  {historyQuery.isLoading
                    ? 'One moment.'
                    : 'Your batting card appears here once a fixture you played is finished.'}
                </AppText>
              </View>
            )}
          </>
        ) : null}

        {/* Settings — unchanged, now below the statistics */}
        <AppText variant="caption" color={M.faint} style={styles.settingsLabel}>
          ACCOUNT SETTINGS
        </AppText>
        {/*
          The theme switch lives here as a labelled row, not only as an
          unlabelled glyph in Home's header. A header icon sitting between two
          action buttons reads as a third action; this reads as the setting it
          actually is, and it is where people look for one.
        */}
        <Pressable
          style={styles.settingRow}
          onPress={() => setScheme(isDark ? 'light' : 'dark')}
          accessibilityRole="switch"
          accessibilityState={{ checked: isDark }}
          accessibilityLabel={`Appearance, currently ${isDark ? 'dark' : 'light'}. Double tap to switch to ${isDark ? 'light' : 'dark'}.`}
        >
          <View style={[styles.settingIcon, { backgroundColor: M.iconChip }]}>
            {isDark ? <IconMoon color={M.green} size={20} /> : <IconSun color={M.green} size={20} />}
          </View>
          <AppText variant="label" color={M.text} style={{ flex: 1, fontSize: 16 }}>
            Appearance
          </AppText>
          <AppText variant="caption" color={M.muted}>
            {isDark ? 'Dark' : 'Light'}
          </AppText>
        </Pressable>

        {settingsFor(M).map(({ key, label, Icon, tint, route }) => (
          <Pressable
            key={key}
            style={styles.settingRow}
            onPress={() => (route ? router.push(route as never) : undefined)}
          >
            <View style={[styles.settingIcon, { backgroundColor: tint }]}>
              <Icon color={key === 'notif' ? M.green : M.text} size={20} />
            </View>
            <AppText variant="label" color={M.text} style={{ flex: 1, fontSize: 16 }}>
              {label}
            </AppText>
            <IconChevron color={M.faint} size={20} />
          </Pressable>
        ))}

        {/* Admin — superadmin only. RLS enforces access server-side regardless. */}
        {isSuperadmin ? (
          <>
            <AppText variant="caption" color={M.faint} style={styles.settingsLabel}>
              ADMIN
            </AppText>
            <Pressable
              style={styles.settingRow}
              onPress={() => router.push('/(admin)/venues' as never)}
            >
              <View style={[styles.settingIcon, { backgroundColor: M.iconChip }]}>
                <IconShieldCheck color={M.green} size={20} />
              </View>
              <AppText variant="label" color={M.text} style={{ flex: 1, fontSize: 16 }}>
                Manage venues
              </AppText>
              <IconChevron color={M.faint} size={20} />
            </Pressable>
            <Pressable
              style={styles.settingRow}
              onPress={() => router.push('/(admin)/users' as never)}
            >
              <View style={[styles.settingIcon, { backgroundColor: M.border }]}>
                <IconUser color={M.text} size={20} />
              </View>
              <AppText variant="label" color={M.text} style={{ flex: 1, fontSize: 16 }}>
                All users
              </AppText>
              <IconChevron color={M.faint} size={20} />
            </Pressable>
            <Pressable style={styles.settingRow} onPress={() => router.push('/(admin)/sports' as never)}>
              <View style={[styles.settingIcon, { backgroundColor: M.iconChip }]}><IconShieldCheck color={M.green} size={20} /></View>
              <AppText variant="label" color={M.text} style={{ flex: 1, fontSize: 16 }}>Sports management</AppText>
              <IconChevron color={M.faint} size={20} />
            </Pressable>
          </>
        ) : null}

        <Pressable style={styles.logout} onPress={() => void authRepository.signOut()}>
          <IconLogout color={M.danger} size={20} />
          <AppText variant="label" color={M.danger} style={{ marginLeft: S.sm, fontSize: 16 }}>
            Logout
          </AppText>
        </Pressable>
      </ScrollView>
    </SafeAreaView>
  );
}

const makeStyles = (M: MockPalette) => StyleSheet.create({
  safe: { flex: 1, backgroundColor: M.bg },
  header: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingHorizontal: S.lg,
    paddingVertical: S.md,
  },
  scroll: { paddingHorizontal: S.lg, paddingBottom: S.xl },

  // 1 — hero
  hero: {
    alignItems: 'center',
    backgroundColor: M.card,
    borderRadius: R.lg,
    borderWidth: 1,
    borderColor: M.border,
    paddingVertical: S.lg,
    paddingHorizontal: S.md,
    marginTop: S.sm,
  },
  avatarWrap: { width: 96, height: 96 },
  avatar: {
    width: 96,
    height: 96,
    borderRadius: 48,
    backgroundColor: M.cardHi,
    borderWidth: 3,
    borderColor: M.border,
    alignItems: 'center',
    justifyContent: 'center',
    overflow: 'hidden',
  },
  avatarImg: { width: '100%', height: '100%' },
  avatarInitial: { fontSize: 36, fontWeight: '800' },
  avatarEdit: {
    position: 'absolute',
    right: -2,
    bottom: -2,
    width: 32,
    height: 32,
    borderRadius: 16,
    backgroundColor: M.lime,
    borderWidth: 2,
    borderColor: M.card,
    alignItems: 'center',
    justifyContent: 'center',
  },
  heroName: { fontSize: 24, fontWeight: '800', marginTop: S.md, textAlign: 'center' },
  heroRow: { flexDirection: 'row', alignItems: 'center', marginTop: S.xs },
  heroArea: { marginLeft: 4 },
  chipRow: {
    flexDirection: 'row',
    gap: S.sm,
    marginTop: S.md,
    flexWrap: 'wrap',
    justifyContent: 'center',
  },
  chip: {
    flexDirection: 'row',
    alignItems: 'center',
    borderRadius: R.pill,
    paddingHorizontal: S.md,
    paddingVertical: 6,
  },
  chipText: { marginLeft: 5, fontWeight: '600' },

  // 2 — career row
  careerCard: {
    flexDirection: 'row',
    backgroundColor: M.card,
    borderRadius: R.md,
    borderWidth: 1,
    borderColor: M.border,
    paddingVertical: S.md,
    marginTop: S.md,
  },
  careerCell: { flex: 1, alignItems: 'center', paddingHorizontal: S.xs },
  careerCellDivided: { borderLeftWidth: 1, borderLeftColor: M.border },
  careerValue: { fontSize: 22, fontWeight: '800' },
  careerLabel: { fontSize: 11, marginTop: 2 },

  // 3 — tabs
  tabBar: {
    flexDirection: 'row',
    backgroundColor: M.card,
    borderRadius: R.pill,
    borderWidth: 1,
    borderColor: M.border,
    padding: 4,
    marginTop: S.lg,
  },
  tab: {
    flex: 1,
    minHeight: 44,
    borderRadius: R.pill,
    alignItems: 'center',
    justifyContent: 'center',
  },
  tabText: { fontSize: 14, fontWeight: '700' },

  sectionHeading: { marginTop: S.lg, marginBottom: S.sm },
  sectionTitle: { fontSize: 18, fontWeight: '800' },

  // 4 — performance tiles
  tileGrid: { flexDirection: 'row', flexWrap: 'wrap', gap: S.md },
  tile: {
    flexGrow: 1,
    flexBasis: '45%',
    backgroundColor: M.card,
    borderRadius: R.md,
    borderWidth: 1,
    borderColor: M.border,
    padding: S.md,
  },
  tileValue: { fontSize: 26, fontWeight: '800', marginVertical: 2 },
  footnote: { marginTop: S.md, lineHeight: 18 },

  // shared shell for the chart, the format table and the empty states
  card: {
    backgroundColor: M.card,
    borderRadius: R.md,
    borderWidth: 1,
    borderColor: M.border,
    padding: S.md,
  },
  chartFoot: { marginTop: S.xs },
  emptyHint: { marginTop: S.xs },

  // 6 — format table
  formatHead: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingBottom: S.sm,
    borderBottomWidth: 1,
    borderBottomColor: M.border,
  },
  formatRow: { flexDirection: 'row', alignItems: 'center', minHeight: 44 },
  formatName: { flex: 1, letterSpacing: 0.5 },
  formatNum: { width: 56, textAlign: 'right' },

  // 7 — recent performances
  matchCard: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: M.card,
    borderRadius: R.md,
    borderWidth: 1,
    borderColor: M.border,
    padding: S.md,
    marginBottom: S.sm,
    minHeight: 44,
  },
  matchMain: { flex: 1 },
  matchTitleRow: { flexDirection: 'row', alignItems: 'center', gap: S.sm },
  matchOpponent: { fontSize: 16, flexShrink: 1 },
  matchMetaRow: { flexDirection: 'row', alignItems: 'center', marginTop: 2 },
  dot: { marginHorizontal: 6 },
  outcome: { fontWeight: '700' },
  matchScore: { alignItems: 'flex-end', marginLeft: S.md },
  motm: {
    flexDirection: 'row',
    alignItems: 'center',
    borderRadius: R.pill,
    paddingHorizontal: 8,
    paddingVertical: 3,
  },
  motmText: { marginLeft: 3, fontSize: 11, fontWeight: '800' },

  notice: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: M.card,
    borderRadius: R.md,
    borderWidth: 1,
    borderColor: M.border,
    padding: S.md,
    marginTop: S.sm,
    minHeight: 44,
  },
  noticeText: { flex: 1 },
  retry: {
    minHeight: 44,
    justifyContent: 'center',
    paddingHorizontal: S.md,
    marginLeft: S.sm,
    borderRadius: R.sm,
    borderWidth: 1,
    borderColor: M.border,
  },

  settingsLabel: { letterSpacing: 1, fontWeight: '700', marginTop: S.xl, marginBottom: S.sm },
  settingRow: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: M.card,
    borderRadius: R.md,
    borderWidth: 1,
    borderColor: M.border,
    padding: S.md,
    marginBottom: S.md,
    minHeight: 44,
  },
  settingIcon: {
    width: 40,
    height: 40,
    borderRadius: R.sm,
    alignItems: 'center',
    justifyContent: 'center',
    marginRight: S.md,
  },
  logout: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    borderWidth: 1,
    borderColor: M.border,
    borderRadius: R.md,
    paddingVertical: S.md + 2,
    marginTop: S.lg,
    minHeight: 44,
  },
});
