/**
 * Scorecard — every innings of the match with its team total.
 *
 * Team totals only. Scoring records runs, extras and wickets without naming a
 * striker or a bowler (see the team_only_scoring migration), so there are no
 * per-player batting or bowling figures to show. `get_batting_card` and
 * `get_bowling_card` still exist and still report correctly for matches that
 * were scored with players; nothing in the app calls them.
 *
 * The rows come from `innings`, not `get_live_state`: the latter returns only
 * the innings in play, which made the first innings a derived `target - 1` with
 * no wickets and no overs.
 */
import { useMemo } from 'react';
import { ActivityIndicator, StyleSheet, View } from 'react-native';
import { Stack, useLocalSearchParams } from 'expo-router';

import { SlotBadge } from '@features/matches/presentation/SlotBadge';
import { useMatch, useMatchSides } from '@features/matches/presentation/useMatches';
import { useSlotCountdown } from '@features/matches/presentation/useSlotCountdown';
import { useMatchInnings } from '@features/scoring/presentation/useScoring';
import { formatOvers, runRate } from '@features/scoring/domain/scoringSchema';
import { radius, spacing, type AppColors } from '@shared/theme';
import { useTheme } from '@shared/theme/ThemeContext';
import { AppText } from '@shared/ui/AppText';
import { Screen } from '@shared/ui/Screen';

export default function ScorecardScreen(): React.ReactNode {
  const { colors } = useTheme();
  const styles = useMemo(() => makeStyles(colors), [colors]);
  const { id } = useLocalSearchParams<{ id: string }>();
  const matchId = id ?? '';

  const match = useMatch(matchId);
  const innings = useMatchInnings(matchId);
  const sides = useMatchSides(matchId);
  const slot = useSlotCountdown(match.data?.end_time);

  /**
   * Innings rows carry team IDs, not names — `teams` is members-only, so the
   * table cannot join to it for a player on the opposing side. get_match_sides
   * is the read model that may hand out both names.
   */
  const teamName = useMemo(() => {
    const sd = sides.data;
    return (teamId: string): string => {
      if (sd?.team_a_id === teamId) return sd.team_a_name ?? 'Team A';
      if (sd?.team_b_id === teamId) return sd.team_b_name ?? 'Team B';
      return 'Team';
    };
  }, [sides.data]);

  if (innings.isLoading) {
    return (
      <Screen>
        <Stack.Screen options={{ title: 'Scorecard' }} />
        <View style={styles.center}>
          <ActivityIndicator color={colors.primary} />
        </View>
      </Screen>
    );
  }

  const rows = innings.data ?? [];

  if (rows.length === 0) {
    return (
      <Screen>
        <Stack.Screen options={{ title: 'Scorecard' }} />
        <View style={styles.card}>
          <AppText muted>No scoring yet for this match.</AppText>
        </View>
      </Screen>
    );
  }

  return (
    <Screen scroll>
      <Stack.Screen options={{ title: 'Scorecard' }} />

      <SlotBadge slot={slot} />

      {match.data?.result_text ? (
        <View style={[styles.card, styles.result]}>
          <AppText variant="heading" color={colors.textInverse}>
            {match.data.result_text}
          </AppText>
        </View>
      ) : null}

      {rows.map((inn) => {
        const rr = runRate(inn.runs, inn.legal_balls);
        return (
          <View key={inn.id} style={styles.card}>
            <View style={styles.head}>
              <View style={styles.flex}>
                <AppText variant="heading" numberOfLines={1}>
                  {teamName(inn.batting_team_id)}
                </AppText>
                <AppText variant="caption" muted>
                  {inn.number === 1 ? '1st' : '2nd'} innings
                  {inn.status === 'in_progress' ? ' · in progress' : ''}
                </AppText>
              </View>
              <View style={styles.scoreBox}>
                <AppText variant="heading" color={colors.primaryDark}>
                  {inn.runs}/{inn.wickets}
                </AppText>
                <AppText variant="caption" muted>
                  ({formatOvers(inn.legal_balls)} ov{rr !== null ? ` · RR ${rr}` : ''})
                </AppText>
              </View>
            </View>

            {inn.target !== null ? (
              <AppText variant="caption" muted>
                Chasing {inn.target} to win.
              </AppText>
            ) : null}
          </View>
        );
      })}
    </Screen>
  );
}

const makeStyles = (colors: AppColors) =>
  StyleSheet.create({
    center: { flex: 1, alignItems: 'center', justifyContent: 'center', paddingTop: spacing.xxl },
    card: {
      gap: spacing.sm,
      padding: spacing.md,
      borderRadius: radius.md,
      backgroundColor: colors.surface,
      borderWidth: 1,
      borderColor: colors.border,
      marginBottom: spacing.md,
    },
    result: { backgroundColor: colors.primary, borderColor: colors.primary },
    flex: { flex: 1 },
    head: {
      flexDirection: 'row',
      alignItems: 'flex-start',
      justifyContent: 'space-between',
      gap: spacing.sm,
    },
    scoreBox: { alignItems: 'flex-end' },
  });
