/**
 * Bottom navigation: Home · Matches · Teams · Activity · Profile.
 *
 * Home is the player dashboard. The screen that used to live here — sport
 * filter, create, join with code, my matches, nearby list — moved verbatim to
 * `matches.tsx`; nothing about it was rebuilt.
 *
 * Available and Venues keep their routes but leave the bar (`href: null`).
 * Five tabs is already the practical limit on a phone, and both are reachable
 * from Home's quick actions. Removing the files would have deleted working
 * screens, which is not the same thing as removing a tab.
 *
 * Colours come from useMock() so the bar follows the theme toggle; reading the
 * frozen `M` here is what kept it dark before.
 */
import { Tabs } from 'expo-router';

import { useMock } from '@shared/theme/mockTheme';
import { IconBell, IconBolt, IconHome, IconPin, IconUser, IconUsers } from '@shared/ui/icons';

export default function TabsLayout(): React.ReactNode {
  const M = useMock();

  return (
    <Tabs
      screenOptions={{
        headerShown: false,
        tabBarActiveTintColor: M.green,
        tabBarInactiveTintColor: M.muted,
        tabBarStyle: {
          backgroundColor: M.card,
          borderTopColor: M.border,
        },
      }}
    >
      <Tabs.Screen
        name="index"
        options={{
          title: 'Home',
          tabBarIcon: ({ color }) => <IconHome color={color as string} size={22} />,
        }}
      />
      <Tabs.Screen
        name="matches"
        options={{
          title: 'Matches',
          tabBarIcon: ({ color }) => <IconPin color={color as string} size={22} />,
        }}
      />
      <Tabs.Screen
        name="teams"
        options={{
          title: 'Teams',
          tabBarIcon: ({ color }) => <IconUsers color={color as string} size={22} />,
        }}
      />
      <Tabs.Screen
        name="activity"
        options={{
          title: 'Activity',
          tabBarIcon: ({ color }) => <IconBell color={color as string} size={22} />,
        }}
      />
      <Tabs.Screen
        name="profile"
        options={{
          title: 'Profile',
          tabBarIcon: ({ color }) => <IconUser color={color as string} size={22} />,
        }}
      />

      {/* Routable, not in the bar. Reached from Home quick actions. */}
      <Tabs.Screen
        name="available"
        options={{
          href: null,
          title: 'Available',
          tabBarIcon: ({ color }) => <IconBolt color={color as string} size={22} />,
        }}
      />
      <Tabs.Screen name="venues" options={{ href: null, title: 'Venues' }} />
    </Tabs>
  );
}
