/**
 * Home — player dashboard.
 *
 * Answers "what is happening with ME?". Finding and joining matches moved to
 * the Matches tab (this file's previous contents, preserved verbatim as
 * `matches.tsx`), so nothing was rebuilt or lost.
 *
 * Every number here comes from a real row. There is no seeded data: an account
 * that has never played reads zero everywhere, and each card has an explicit
 * empty state instead of a plausible-looking placeholder.
 */
import { useMemo } from 'react';
import { ActivityIndicator, Image, Pressable, ScrollView, StyleSheet, View } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { useRouter } from 'expo-router';

import { useAuthStore } from '@core/auth/authStore';
import {
  useNextMatch,
  usePendingActions,
  usePlayerStats,
  useRecentMatches,
} from '@features/dashboard/presentation/useDashboard';
import { PLAYING_ROLE_LABEL } from '@features/dashboard/data/dashboardRepository';
import type { PendingAction } from '@features/dashboard/data/dashboardRepository';
import { useMyTeams } from '@features/teams/presentation/useTeams';
import { R, S, useMock, type MockPalette } from '@shared/theme/mockTheme';
import { AppLogo } from '@shared/ui/AppLogo';
import { AppText } from '@shared/ui/AppText';
import { IconBell, IconClock, IconPin, IconPlus, IconSend } from '@shared/ui/icons';

function greeting(now: Date): string {
  const h = now.getHours();
  if (h < 12) return 'Good Morning';
  if (h < 17) return 'Good Afternoon';
  return 'Good Evening';
}

const MONTH = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];

function formatWhen(iso: string): string {
  const d = new Date(iso);
  if (Number.isNaN(d.getTime())) return '';
  const hh = d.getHours() % 12 || 12;
  const mm = String(d.getMinutes()).padStart(2, '0');
  const ap = d.getHours() < 12 ? 'AM' : 'PM';
  return `${d.getDate()} ${MONTH[d.getMonth()]} · ${hh}:${mm} ${ap}`;
}

function formatDay(iso: string): string {
  const d = new Date(iso);
  if (Number.isNaN(d.getTime())) return '';
  return `${d.getDate()} ${MONTH[d.getMonth()]}`;
}

const URGENCY_DOT: Record<PendingAction['urgency'], keyof MockPalette> = {
  high: 'danger',
  medium: 'lime',
  low: 'green',
};

export default function HomeScreen(): React.ReactNode {
  const M = useMock();
  const styles = useMemo(() => makeStyles(M), [M]);
  const router = useRouter();

  const profile = useAuthStore((s) => s.profile);
  const stats = usePlayerStats();
  const next = useNextMatch();
  const recent = useRecentMatches(3);
  const actions = usePendingActions();
  const teams = useMyTeams();

  const firstName = (stats.data?.full_name ?? profile?.full_name ?? '').split(' ')[0] || 'there';
  const area = stats.data?.area_name ?? profile?.area_name ?? null;
  const primaryTeam = (teams.data ?? [])[0] ?? null;
  const teamCount = (teams.data ?? []).length;
  const s = stats.data;
  const hasPlayed = (s?.matches_played ?? 0) > 0;

  return (
    <SafeAreaView style={styles.safe} edges={['top']}>
      <ScrollView contentContainerStyle={styles.scroll} showsVerticalScrollIndicator={false}>
        {/* ---------------- Header ---------------- */}
        <View style={styles.header}>
          <View style={{ flex: 1 }}>
            <AppText variant="title" color={M.text} style={{ fontSize: 22 }}>
              {greeting(new Date())}, {firstName} 👋
            </AppText>
            {area ? (
              <AppText variant="caption" color={M.muted}>
                {area}
              </AppText>
            ) : null}
          </View>
          <Pressable
            onPress={() => router.push('/(tabs)/activity')}
            style={styles.iconBtn}
            accessibilityRole="button"
            accessibilityLabel="Notifications"
          >
            <IconBell color={M.text} size={20} />
            {(actions.data ?? []).length > 0 ? <View style={styles.badge} /> : null}
          </Pressable>
        </View>

        {/* ---------------- Player summary ---------------- */}
        <View style={styles.card}>
          {stats.isLoading ? (
            <ActivityIndicator color={M.green} />
          ) : (
            <>
              <View style={styles.playerRow}>
                {s?.avatar_url ? (
                  <Image source={{ uri: s.avatar_url }} style={styles.avatar} />
                ) : (
                  <View style={[styles.avatar, styles.avatarFallback]}>
                    <AppLogo variant="icon" width={38} />
                  </View>
                )}
                <View style={{ flex: 1 }}>
                  <AppText variant="heading" color={M.text} style={{ fontSize: 18 }}>
                    {s?.full_name ?? 'Your profile'}
                  </AppText>
                  <AppText variant="caption" color={M.muted}>
                    {s?.playing_role ? PLAYING_ROLE_LABEL[s.playing_role] : 'Role not set'}
                  </AppText>
                </View>
                <Pressable onPress={() => router.push('/(tabs)/profile')}>
                  <AppText variant="caption" color={M.green}>
                    View Profile →
                  </AppText>
                </Pressable>
              </View>

              <View style={styles.statRow}>
                <Stat M={M} label="Matches" value={s?.matches_played ?? 0} />
                <Stat M={M} label="Runs" value={s?.runs ?? 0} />
                <Stat M={M} label="Wickets" value={s?.wickets ?? 0} />
                <Stat M={M} label="MVP" value={s?.motm ?? 0} last />
              </View>
            </>
          )}
        </View>

        {/* ---------------- Matches played + My team ---------------- */}
        <View style={styles.grid}>
          <View style={[styles.card, styles.gridCell]}>
            <AppText variant="caption" color={M.muted}>
              MATCHES PLAYED
            </AppText>
            <AppText style={styles.bigNumber}>{s?.matches_played ?? 0}</AppText>
            {hasPlayed ? (
              <>
                <Row M={M} left="Wins" right={String(s?.wins ?? 0)} />
                <Row M={M} left="Win Rate" right={`${s?.win_rate ?? 0}%`} />
              </>
            ) : (
              <AppText variant="caption" color={M.muted}>
                Start playing to build your match history.
              </AppText>
            )}
          </View>

          <View style={[styles.card, styles.gridCell]}>
            <AppText variant="caption" color={M.muted}>
              MY TEAM
            </AppText>
            {teams.isLoading ? (
              <ActivityIndicator color={M.green} />
            ) : primaryTeam ? (
              <>
                <AppText variant="heading" color={M.text} style={{ fontSize: 16 }}>
                  {primaryTeam.name}
                </AppText>
                <AppText variant="caption" color={M.muted}>
                  {primaryTeam.invite_code}
                </AppText>
                <Pressable
                  onPress={() =>
                    teamCount > 1
                      ? router.push('/(tabs)/teams')
                      : router.push({ pathname: '/teams/[id]', params: { id: primaryTeam.id } })
                  }
                >
                  <AppText variant="caption" color={M.green} style={{ marginTop: S.xs }}>
                    {teamCount > 1 ? 'View All Teams →' : 'View Team →'}
                  </AppText>
                </Pressable>
              </>
            ) : (
              <>
                <AppText variant="caption" color={M.muted}>
                  You haven&apos;t joined a team yet.
                </AppText>
                <Pressable onPress={() => router.push('/teams/create')}>
                  <AppText variant="caption" color={M.green} style={{ marginTop: S.xs }}>
                    Create Team →
                  </AppText>
                </Pressable>
                <Pressable onPress={() => router.push('/teams/join')}>
                  <AppText variant="caption" color={M.green}>
                    Join Team →
                  </AppText>
                </Pressable>
              </>
            )}
          </View>
        </View>

        {/* ---------------- Upcoming match ---------------- */}
        <AppText variant="caption" color={M.muted} style={styles.section}>
          UPCOMING MATCH
        </AppText>
        {next.isLoading ? (
          <View style={styles.card}>
            <ActivityIndicator color={M.green} />
          </View>
        ) : next.data ? (
          <Pressable
            style={styles.card}
            onPress={() => router.push(`/match/${next.data!.match_id}`)}
            accessibilityRole="button"
          >
            <View style={styles.vsRow}>
              <AppText variant="label" color={M.text} style={styles.vsTeam} numberOfLines={2}>
                {next.data.team_a_name ?? 'Your side'}
              </AppText>
              <AppText variant="caption" color={M.green}>
                VS
              </AppText>
              <AppText
                variant="label"
                color={M.text}
                style={[styles.vsTeam, { textAlign: 'right' }]}
                numberOfLines={2}
              >
                {next.data.team_b_name ?? 'Opponent TBD'}
              </AppText>
            </View>
            <View style={styles.metaRow}>
              <IconClock color={M.muted} size={14} />
              <AppText variant="caption" color={M.muted}>
                {formatWhen(next.data.scheduled_at)}
              </AppText>
            </View>
            {next.data.venue_text ? (
              <View style={styles.metaRow}>
                <IconPin color={M.muted} size={14} />
                <AppText variant="caption" color={M.muted}>
                  {next.data.venue_text}
                </AppText>
              </View>
            ) : null}
            <View style={styles.metaRow}>
              <AppText variant="caption" color={M.muted}>
                {next.data.confirmed_count}/{next.data.total_slots} confirmed
              </AppText>
            </View>
            {next.data.my_status === 'invited' ? (
              <AppText variant="caption" color={M.danger}>
                You haven&apos;t confirmed yet — tap to reply
              </AppText>
            ) : null}
            <AppText variant="caption" color={M.green} style={{ marginTop: S.xs }}>
              Match Details →
            </AppText>
          </Pressable>
        ) : (
          <View style={styles.card}>
            <AppText variant="label" color={M.text}>
              No upcoming matches
            </AppText>
            <AppText variant="caption" color={M.muted}>
              Find a match nearby or challenge another team.
            </AppText>
            <View style={styles.btnRow}>
              <Pressable style={styles.ctaGhost} onPress={() => router.push('/(tabs)/matches')}>
                <AppText variant="caption" color={M.text}>
                  Find Match
                </AppText>
              </Pressable>
              <Pressable style={styles.ctaSolid} onPress={() => router.push('/match/create')}>
                <AppText variant="caption" color={M.ctaText}>
                  Create Match
                </AppText>
              </Pressable>
            </View>
          </View>
        )}

        {/* ---------------- Pending actions ---------------- */}
        {(actions.data ?? []).length > 0 ? (
          <>
            <AppText variant="caption" color={M.muted} style={styles.section}>
              YOUR ACTIONS
            </AppText>
            <View style={styles.card}>
              {(actions.data ?? []).map((a, i) => (
                <Pressable
                  key={`${a.kind}-${i}`}
                  style={styles.actionRow}
                  onPress={() => a.route && router.push(a.route as never)}
                  accessibilityRole="button"
                >
                  <View style={[styles.dot, { backgroundColor: M[URGENCY_DOT[a.urgency]] }]} />
                  <View style={{ flex: 1 }}>
                    <AppText variant="label" color={M.text}>
                      {a.title}
                    </AppText>
                    {a.subtitle ? (
                      <AppText variant="caption" color={M.muted}>
                        {a.subtitle}
                      </AppText>
                    ) : null}
                  </View>
                </Pressable>
              ))}
            </View>
          </>
        ) : null}

        {/* ---------------- Recent matches ---------------- */}
        {(recent.data ?? []).length > 0 ? (
          <>
            <AppText variant="caption" color={M.muted} style={styles.section}>
              RECENT MATCHES
            </AppText>
            <View style={styles.card}>
              {(recent.data ?? []).map((r) => (
                <Pressable
                  key={r.match_id}
                  style={styles.recentRow}
                  onPress={() => router.push(`/match/${r.match_id}/scorecard`)}
                  accessibilityRole="button"
                >
                  <View style={{ flex: 1 }}>
                    <AppText variant="label" color={M.text} numberOfLines={1}>
                      {r.my_team_name ?? r.match_name}
                    </AppText>
                    <AppText variant="caption" color={M.muted} numberOfLines={1}>
                      vs {r.opponent_name ?? 'Opponent'} · {formatDay(r.played_at)}
                    </AppText>
                  </View>
                  <View style={{ alignItems: 'flex-end' }}>
                    <AppText
                      variant="caption"
                      color={
                        r.outcome === 'won' ? M.green : r.outcome === 'lost' ? M.danger : M.muted
                      }
                    >
                      {r.outcome.toUpperCase()}
                    </AppText>
                    {r.my_runs !== null && r.their_runs !== null ? (
                      <AppText variant="caption" color={M.muted}>
                        {r.my_runs} - {r.their_runs}
                      </AppText>
                    ) : null}
                  </View>
                </Pressable>
              ))}
              <Pressable onPress={() => router.push('/matches')}>
                <AppText variant="caption" color={M.green} style={{ textAlign: 'right' }}>
                  View All →
                </AppText>
              </Pressable>
            </View>
          </>
        ) : null}

        {/* ---------------- Quick actions ---------------- */}
        <AppText variant="caption" color={M.muted} style={styles.section}>
          QUICK ACTIONS
        </AppText>
        <View style={styles.quickGrid}>
          <Quick M={M} label="Create Match" onPress={() => router.push('/match/create')} icon="plus" />
          <Quick M={M} label="Find Match" onPress={() => router.push('/(tabs)/matches')} icon="pin" />
          <Quick M={M} label="My Teams" onPress={() => router.push('/(tabs)/teams')} icon="send" />
          <Quick
            M={M}
            label="I'm Available"
            onPress={() => router.push('/(tabs)/available')}
            icon="clock"
          />
        </View>
      </ScrollView>
    </SafeAreaView>
  );
}

function Stat({
  M,
  label,
  value,
  last,
}: {
  M: MockPalette;
  label: string;
  value: number;
  last?: boolean;
}): React.ReactNode {
  const styles = makeStyles(M);
  return (
    <View style={[styles.stat, last ? null : styles.statDivider]}>
      <AppText variant="caption" color={M.muted}>
        {label}
      </AppText>
      <AppText variant="heading" color={M.text} style={{ fontSize: 20 }}>
        {value}
      </AppText>
    </View>
  );
}

function Row({ M, left, right }: { M: MockPalette; left: string; right: string }): React.ReactNode {
  return (
    <View style={{ flexDirection: 'row', justifyContent: 'space-between', marginTop: 2 }}>
      <AppText variant="caption" color={M.muted}>
        {left}
      </AppText>
      <AppText variant="caption" color={M.text}>
        {right}
      </AppText>
    </View>
  );
}

function Quick({
  M,
  label,
  onPress,
  icon,
}: {
  M: MockPalette;
  label: string;
  onPress: () => void;
  icon: 'plus' | 'pin' | 'send' | 'clock';
}): React.ReactNode {
  const styles = makeStyles(M);
  const Glyph = icon === 'plus' ? IconPlus : icon === 'pin' ? IconPin : icon === 'send' ? IconSend : IconClock;
  return (
    <Pressable style={styles.quick} onPress={onPress} accessibilityRole="button">
      <Glyph color={M.green} size={18} />
      <AppText variant="caption" color={M.text}>
        {label}
      </AppText>
    </Pressable>
  );
}

const makeStyles = (M: MockPalette) =>
  StyleSheet.create({
    safe: { flex: 1, backgroundColor: M.bg },
    scroll: { padding: S.md, paddingBottom: S.xl, gap: S.sm },
    header: { flexDirection: 'row', alignItems: 'center', gap: S.sm, marginBottom: S.xs },
    iconBtn: {
      width: 44,
      height: 44,
      borderRadius: 22,
      borderWidth: 1,
      borderColor: M.border,
      backgroundColor: M.card,
      alignItems: 'center',
      justifyContent: 'center',
    },
    badge: {
      position: 'absolute',
      top: 10,
      right: 11,
      width: 9,
      height: 9,
      borderRadius: 5,
      backgroundColor: M.danger,
    },
    card: {
      backgroundColor: M.card,
      borderRadius: R.md,
      borderWidth: 1,
      borderColor: M.border,
      padding: S.md,
      gap: S.xs,
    },
    playerRow: { flexDirection: 'row', alignItems: 'center', gap: S.sm },
    avatar: { width: 54, height: 54, borderRadius: 27, backgroundColor: M.cardHi },
    avatarFallback: { alignItems: 'center', justifyContent: 'center' },
    statRow: {
      flexDirection: 'row',
      marginTop: S.sm,
      borderTopWidth: 1,
      borderTopColor: M.border,
      paddingTop: S.sm,
    },
    stat: { flex: 1, alignItems: 'center', gap: 2 },
    statDivider: { borderRightWidth: 1, borderRightColor: M.border },
    // Two cards side by side; each is allowed to shrink, so a long team name
    // wraps instead of pushing the row wider than the screen.
    grid: { flexDirection: 'row', gap: S.sm },
    gridCell: { flex: 1, minWidth: 0 },
    bigNumber: { fontSize: 30, fontWeight: '800', color: M.text },
    section: { marginTop: S.md, letterSpacing: 0.5 },
    vsRow: { flexDirection: 'row', alignItems: 'center', gap: S.sm },
    vsTeam: { flex: 1, fontSize: 15 },
    metaRow: { flexDirection: 'row', alignItems: 'center', gap: S.xs },
    btnRow: { flexDirection: 'row', gap: S.sm, marginTop: S.sm },
    ctaGhost: {
      flex: 1,
      paddingVertical: S.sm,
      borderRadius: R.pill,
      borderWidth: 1,
      borderColor: M.border,
      alignItems: 'center',
    },
    ctaSolid: {
      flex: 1,
      paddingVertical: S.sm,
      borderRadius: R.pill,
      backgroundColor: M.lime,
      alignItems: 'center',
    },
    actionRow: {
      flexDirection: 'row',
      alignItems: 'center',
      gap: S.sm,
      paddingVertical: S.xs,
    },
    dot: { width: 9, height: 9, borderRadius: 5 },
    recentRow: {
      flexDirection: 'row',
      alignItems: 'center',
      gap: S.sm,
      paddingVertical: S.sm,
      borderBottomWidth: 1,
      borderBottomColor: M.border,
    },
    quickGrid: { flexDirection: 'row', flexWrap: 'wrap', gap: S.sm },
    quick: {
      flexGrow: 1,
      flexBasis: '46%',
      flexDirection: 'row',
      alignItems: 'center',
      gap: S.sm,
      padding: S.md,
      borderRadius: R.md,
      borderWidth: 1,
      borderColor: M.border,
      backgroundColor: M.card,
    },
  });
