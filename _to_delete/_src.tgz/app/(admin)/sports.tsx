import { useState } from 'react';
import { ActivityIndicator, StyleSheet, View } from 'react-native';
import { Stack } from 'expo-router';
import { useMutation, useQuery, useQueryClient } from '@tanstack/react-query';
import { supabase } from '@core/api/supabaseClient';
import { AppError, toAppError } from '@core/errors/AppError';
import { colors, radius, spacing } from '@shared/theme';
import { AppText } from '@shared/ui/AppText';
import { Button } from '@shared/ui/Button';
import { Screen } from '@shared/ui/Screen';
import { TextField } from '@shared/ui/TextField';

const key=['admin','sports'] as const;
export default function SportsManagement():React.ReactNode {const qc=useQueryClient();const [name,setName]=useState('');const [error,setError]=useState<string|null>(null);const sports=useQuery({queryKey:key,queryFn:async()=>{const {data,error}=await supabase.from('sports').select('*').order('created_at');if(error)throw toAppError(error);return data??[];}});const add=useMutation({mutationFn:async()=>{const clean=name.trim();if(!clean)throw new AppError('validation','Enter a sport name.');throw new AppError('validation','Adding a brand-new sport requires a supported sport key migration; existing sport keys can be safely hidden or shown below.');},onError:e=>setError(e instanceof AppError?e.message:'Unable to add sport.')});const toggle=useMutation({mutationFn:async(s:{id:string;is_active:boolean})=>{const {error}=await supabase.from('sports').update({is_active:!s.is_active}).eq('id',s.id);if(error)throw toAppError(error);},onSuccess:()=>void qc.invalidateQueries({queryKey:key})});return <Screen scroll><Stack.Screen options={{title:'Sports management'}}/><AppText variant="heading">Sports management</AppText><View style={styles.add}><TextField label="Add sport" value={name} onChangeText={setName} placeholder="Sport name"/><Button label="Add sport" loading={add.isPending} onPress={()=>{setError(null);add.mutate();}}/>{error?<AppText color={colors.danger}>{error}</AppText>:null}</View>{sports.isLoading?<ActivityIndicator color={colors.primary}/>:sports.data?.map(s=><View style={styles.row} key={s.id}><View style={{flex:1}}><AppText variant="label">{s.name}</AppText><AppText muted variant="caption">{s.is_active?'ACTIVE':'HIDDEN'} · {new Date(s.created_at).toLocaleDateString()}</AppText></View><Button label={s.is_active?'Hide':'Show'} variant="secondary" loading={toggle.isPending} onPress={()=>toggle.mutate(s)}/></View>)}</Screen>};const styles=StyleSheet.create({add:{gap:spacing.sm,marginVertical:spacing.lg},row:{flexDirection:'row',alignItems:'center',gap:spacing.md,padding:spacing.md,borderRadius:radius.md,borderWidth:1,borderColor:colors.border,backgroundColor:colors.surface,marginBottom:spacing.sm}});
