import { useQuery } from '@tanstack/react-query';
import { sportsRepository } from '@features/sports/data/sportsRepository';
export function useActiveSports(){return useQuery({queryKey:['sports','active'],queryFn:()=>sportsRepository.listActive(),staleTime:60000});}
