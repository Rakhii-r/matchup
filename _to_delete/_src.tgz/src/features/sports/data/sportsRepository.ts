import { supabase } from '@core/api/supabaseClient';
import { toAppError } from '@core/errors/AppError';
import type { Sport } from '@shared/types/database.types';
export interface ManagedSport { id:string; sport:Sport; name:string; is_active:boolean; created_at:string; updated_at:string }
export const sportsRepository={async listActive():Promise<ManagedSport[]>{const {data,error}=await supabase.from('sports').select('*').eq('is_active',true).order('name');if(error)throw toAppError(error);return data??[];}};
