import { useMemo, useState } from 'react';
import { Alert, Image, Pressable, ScrollView, StyleSheet, TextInput, View } from 'react-native';
import * as ImagePicker from 'expo-image-picker';
import { SafeAreaView } from 'react-native-safe-area-context';
import { MotiView } from 'moti';
import { Stack, useRouter } from 'expo-router';

import { useAuthStore } from '@core/auth/authStore';
import { useUpdateProfile } from '@features/profile/presentation/useUpdateProfile';
import { useActiveSports } from '@features/sports/presentation/useSports';
import type { Sport } from '@shared/types/database.types';
import { R, S, useMock, type MockPalette } from '@shared/theme/mockTheme';
import { AppText } from '@shared/ui/AppText';
import { IconBack } from '@shared/ui/icons';

export default function EditProfileScreen(): React.ReactNode {
  const M = useMock();
  const styles = useMemo(() => makeStyles(M), [M]);
  const router = useRouter();
  const profile = useAuthStore((s) => s.profile);
  const session = useAuthStore((s) => s.session);
  const { loading, error, submit } = useUpdateProfile();
  const activeSports = useActiveSports();

  const [fullName, setFullName] = useState(profile?.full_name ?? '');
  const [areaName, setAreaName] = useState(profile?.area_name ?? '');
  const [sports, setSports] = useState<Sport[]>(profile?.sport_pref ?? []);
  const [avatarUri, setAvatarUri] = useState<string | null>(profile?.avatar_url ?? null);
  const [avatarBase64, setAvatarBase64] = useState<string | null>(null);
  const [removeAvatar, setRemoveAvatar] = useState(false);

  const pickPhoto = async (): Promise<void> => { const permission=await ImagePicker.requestMediaLibraryPermissionsAsync(); if(!permission.granted) return; const result=await ImagePicker.launchImageLibraryAsync({mediaTypes:['images'],allowsEditing:true,aspect:[1,1],quality:0.7,base64:true}); const asset=result.canceled?null:result.assets[0];if(asset?.base64){setAvatarUri(asset.uri);setAvatarBase64(asset.base64);setRemoveAvatar(false);} };

  const toggleSport = (sport: Sport): void => {
    setSports((prev) => (prev.includes(sport) ? prev.filter((s) => s !== sport) : [...prev, sport]));
  };

  const onSubmit = async (): Promise<void> => {
    const ok = await submit({ fullName, areaName, sportPref: sports, avatarBase64, removeAvatar });
    if (ok) router.back();
  };

  // Phone-OTP is the login identity; email belongs to Supabase Auth, so it is
  // shown read-only here.
  const loginContact = session?.user.phone
    ? `+${session.user.phone}`
    : (session?.user.email ?? 'Not set');

  return (
    <SafeAreaView style={styles.safe} edges={['top', 'left', 'right']}>
      <Stack.Screen options={{ headerShown: false }} />

      {/* Header */}
      <View style={styles.header}>
        <Pressable hitSlop={10} onPress={() => router.back()} style={styles.backBtn}>
          <IconBack color={M.text} size={22} />
        </Pressable>
        <AppText variant="heading" color={M.text}>
          Edit profile
        </AppText>
        <View style={styles.backBtn} />
      </View>

      <ScrollView
        contentContainerStyle={styles.scroll}
        showsVerticalScrollIndicator={false}
        keyboardShouldPersistTaps="handled"
      >
        <View style={styles.photoArea}><Pressable accessibilityRole="button" accessibilityLabel={avatarUri?'Change profile photo':'Add profile photo'} hitSlop={12} onPress={()=>void pickPhoto()} style={styles.photoPicker}><View style={styles.avatar}>{avatarUri?<Image source={{uri:avatarUri}} style={styles.avatarImage}/>:<AppText variant="heading" color={M.faint}>+</AppText>}</View><AppText variant="label" color={M.green}>{avatarUri?'Change photo':'Add profile photo'}</AppText></Pressable>{avatarUri?<Pressable hitSlop={12} onPress={()=>Alert.alert('Remove profile photo?','This will remove your current profile picture.',[{text:'Cancel',style:'cancel'},{text:'Remove',style:'destructive',onPress:()=>{setAvatarUri(null);setAvatarBase64(null);setRemoveAvatar(true);}}])}><AppText variant="caption" color={M.danger}>Remove photo</AppText></Pressable>:null}</View>
        {/* Name */}
        <AppText variant="label" color={M.muted} style={styles.fieldLabel}>
          Name
        </AppText>
        <TextInput
          value={fullName}
          onChangeText={setFullName}
          placeholder="Your name"
          placeholderTextColor={M.faint}
          style={styles.input}
        />

        {/* Area */}
        <AppText variant="label" color={M.muted} style={styles.fieldLabel}>
          Area
        </AppText>
        <TextInput
          value={areaName}
          onChangeText={setAreaName}
          placeholder="e.g. Kukatpally, Hyderabad"
          placeholderTextColor={M.faint}
          style={styles.input}
        />

        {/* Sports */}
        <AppText variant="label" color={M.muted} style={styles.fieldLabel}>
          Sports you play
        </AppText>
        <View style={styles.chips}>
          {activeSports.data?.map((s) => {
            const selected = sports.includes(s.sport);
            return (
              <Pressable
                key={s.id}
                onPress={() => toggleSport(s.sport)}
                accessibilityRole="button"
                accessibilityState={{ selected }}
                style={styles.chipWrap}
              >
                <MotiView
                  animate={{
                    backgroundColor: selected ? M.green : M.card,
                    borderColor: selected ? M.green : M.border,
                  }}
                  transition={{ type: 'timing', duration: 160 }}
                  style={styles.chip}
                >
                  <AppText variant="label" color={selected ? M.limeInk : M.text}>
                    {s.name}
                  </AppText>
                </MotiView>
              </Pressable>
            );
          })}
        </View>

        {/* Login (read-only) */}
        <View style={styles.readonly}>
          <AppText variant="label" color={M.muted}>
            Login (phone)
          </AppText>
          <AppText color={M.text} style={{ marginTop: 4 }}>
            {loginContact}
          </AppText>
          <AppText variant="caption" color={M.faint} style={{ marginTop: 4 }}>
            Your login is managed by sign-in and can&apos;t be changed here.
          </AppText>
        </View>

        {error ? (
          <AppText variant="caption" color={M.danger} style={{ marginBottom: S.sm }}>
            {error}
          </AppText>
        ) : null}

        <Pressable
          disabled={loading}
          onPress={onSubmit}
          style={({ pressed }) => [
            styles.cta,
            { transform: [{ scale: pressed ? 0.98 : 1 }], opacity: loading ? 0.6 : 1 },
          ]}
          accessibilityRole="button"
        >
          <AppText variant="label" color={M.limeInk} style={{ fontSize: 16 }}>
            {loading ? 'Saving…' : 'Save changes'}
          </AppText>
        </Pressable>
      </ScrollView>
    </SafeAreaView>
  );
}

const makeStyles = (M: MockPalette) => StyleSheet.create({
  safe: { flex: 1, backgroundColor: M.bg },
  header: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingHorizontal: S.lg,
    paddingTop: S.sm,
    paddingBottom: S.md,
    borderBottomWidth: 1,
    borderBottomColor: M.border,
  },
  backBtn: { width: 40, height: 40, alignItems: 'center', justifyContent: 'center' },
  scroll: { paddingHorizontal: S.lg, paddingTop: S.lg, paddingBottom: S.xl },
  photoArea:{alignItems:'center',gap:S.sm,marginBottom:S.lg},
  photoPicker:{alignItems:'center',gap:S.sm,padding:S.sm},
  avatar:{width:96,height:96,borderRadius:48,overflow:'hidden',alignItems:'center',justifyContent:'center',backgroundColor:M.card,borderWidth:1,borderColor:M.border},
  avatarImage:{width:'100%',height:'100%'},
  fieldLabel: { marginBottom: S.sm, fontSize: 14 },
  input: {
    backgroundColor: M.card,
    borderRadius: R.md,
    borderWidth: 1,
    borderColor: M.border,
    paddingHorizontal: S.md,
    minHeight: 52,
    color: M.text,
    fontSize: 16,
    marginBottom: S.lg,
  },
  chips: { flexDirection: 'row', gap: S.md, marginBottom: S.lg },
  chipWrap: { flex: 1 },
  chip: {
    minHeight: 48,
    borderRadius: R.pill,
    borderWidth: 1.5,
    alignItems: 'center',
    justifyContent: 'center',
  },
  readonly: {
    padding: S.md,
    borderRadius: R.lg,
    borderWidth: 1,
    borderColor: M.border,
    backgroundColor: M.card,
    marginBottom: S.lg,
  },
  cta: {
    minHeight: 54,
    borderRadius: 18,
    backgroundColor: M.green,
    alignItems: 'center',
    justifyContent: 'center',
    shadowColor: M.green,
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.35,
    shadowRadius: 12,
    elevation: 6,
  },
});
