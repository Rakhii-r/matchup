/**
 * Home — the player dashboard.
 *
 * Answers "what is happening near me, and what is happening to me?". Every
 * section is horizontal by design: the reference puts four browsable rails on
 * one screen, and a vertical list of any one of them would push the rest below
 * the fold.
 *
 * Every figure comes from a real row. There is no seeded data — an account with
 * no matches reads empty, and each rail states that plainly rather than showing
 * a plausible-looking placeholder.
 *
 * Sports come from the `sports` table, never from a hard-coded list, so a sport
 * hidden in Sports Management disappears here on the next refetch.
 */
import { useMemo, useState } from 'react';
import {
  ActivityIndicator,
  Image,
  Pressable,
  RefreshControl,
  ScrollView,
  StyleSheet,
  View,
} from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { useRouter } from 'expo-router';

import { useAuthStore } from '@core/auth/authStore';
import { usePendingActions, usePlayerStats } from '@features/dashboard/presentation/useDashboard';
import { useJoinedMatches, useNearbyMatches } from '@features/matches/presentation/useMatches';
import { useActiveSports } from '@features/sports/presentation/useSports';
import { useVenues } from '@features/venues/presentation/useVenues';
import type { Sport } from '@shared/types/database.types';
import { useTheme } from '@shared/theme/ThemeContext';
import { R, S, useMock, type MockPalette } from '@shared/theme/mockTheme';
import { AppText } from '@shared/ui/AppText';
import {
  IconBadminton,
  IconBell,
  IconCalendar,
  IconClock,
  IconCricket,
  IconMoon,
  IconPin,
  IconStar,
  IconSun,
  IconUsers,
} from '@shared/ui/icons';

const MONTH = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];

function greeting(now: Date): string {
  const h = now.getHours();
  if (h < 12) return 'Good Morning';
  if (h < 17) return 'Good Afternoon';
  return 'Good Evening';
}

function formatWhen(iso: string): string {
  const d = new Date(iso);
  if (Number.isNaN(d.getTime())) return '';
  const hh = d.getHours() % 12 || 12;
  const mm = String(d.getMinutes()).padStart(2, '0');
  const ap = d.getHours() < 12 ? 'AM' : 'PM';
  return `${d.getDate()} ${MONTH[d.getMonth()]} · ${hh}:${mm} ${ap}`;
}

/**
 * Straight-line distance in km. `nearby_matches` filters by radius server-side
 * but returns the plain match row, so the per-card distance is derived here
 * rather than by widening the RPC's return type.
 */
function distanceKm(
  from: { lat: number; lng: number },
  to: { lat: number | null; lng: number | null },
): number | null {
  if (to.lat == null || to.lng == null) return null;
  const toRad = (d: number): number => (d * Math.PI) / 180;
  const dLat = toRad(to.lat - from.lat);
  const dLng = toRad(to.lng - from.lng);
  const a =
    Math.sin(dLat / 2) ** 2 +
    Math.cos(toRad(from.lat)) * Math.cos(toRad(to.lat)) * Math.sin(dLng / 2) ** 2;
  return 6371 * 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
}

function km(value: number | null): string {
  if (value == null) return '';
  return value < 1 ? `${Math.round(value * 1000)} m` : `${value.toFixed(1)} km`;
}

const SPORT_ICON: Record<string, typeof IconCricket> = {
  box_cricket: IconCricket,
  badminton: IconBadminton,
};

export default function HomeScreen(): React.ReactNode {
  const M = useMock();
  const styles = useMemo(() => makeStyles(M), [M]);
  const router = useRouter();
  const { isDark, setScheme } = useTheme();

  const profile = useAuthStore((s) => s.profile);
  const [sport, setSport] = useState<Sport | null>(null);

  const coords =
    profile?.home_lat != null && profile?.home_lng != null
      ? { lat: profile.home_lat, lng: profile.home_lng }
      : null;

  const stats = usePlayerStats();
  const actions = usePendingActions();
  const sports = useActiveSports();
  const nearby = useNearbyMatches(coords, sport);
  const venues = useVenues();
  const joined = useJoinedMatches();

  const firstName = (stats.data?.full_name ?? profile?.full_name ?? '').split(' ')[0] || 'there';
  const area = stats.data?.area_name ?? profile?.area_name ?? null;

  const upcoming = (joined.data ?? [])
    .filter((j) => j.match.status !== 'completed' && new Date(j.match.scheduled_at) >= new Date())
    .sort((a, b) => a.match.scheduled_at.localeCompare(b.match.scheduled_at));

  const refreshing =
    nearby.isRefetching || venues.isRefetching || joined.isRefetching || sports.isRefetching;

  const onRefresh = (): void => {
    void nearby.refetch();
    void venues.refetch();
    void joined.refetch();
    void sports.refetch();
  };

  return (
    <SafeAreaView style={styles.safe} edges={['top']}>
      <ScrollView
        contentContainerStyle={styles.scroll}
        showsVerticalScrollIndicator={false}
        refreshControl={
          <RefreshControl refreshing={refreshing} onRefresh={onRefresh} tintColor={M.green} />
        }
      >
        {/* ---------------- Header ---------------- */}
        <View style={styles.header}>
          <View style={{ flex: 1, minWidth: 0 }}>
            <AppText variant="caption" color={M.muted}>
              {greeting(new Date())},
            </AppText>
            <AppText variant="title" color={M.text} style={{ fontSize: 22 }} numberOfLines={1}>
              {firstName} 👋
            </AppText>
            {area ? (
              <View style={styles.areaRow}>
                <IconPin color={M.muted} size={12} />
                <AppText variant="caption" color={M.muted} numberOfLines={1}>
                  {area}
                </AppText>
              </View>
            ) : null}
          </View>

          <Pressable
            onPress={() => setScheme(isDark ? 'light' : 'dark')}
            style={styles.iconBtn}
            accessibilityRole="button"
            accessibilityLabel={isDark ? 'Switch to light mode' : 'Switch to dark mode'}
          >
            {isDark ? (
              <IconSun color={M.text} size={18} />
            ) : (
              <IconMoon color={M.text} size={18} />
            )}
          </Pressable>
          <Pressable
            onPress={() => router.push('/(tabs)/matches')}
            style={styles.iconBtn}
            accessibilityRole="button"
            accessibilityLabel="Your match schedule"
          >
            <IconCalendar color={M.text} size={18} />
          </Pressable>
          <Pressable
            onPress={() => router.push('/(tabs)/activity')}
            style={styles.iconBtn}
            accessibilityRole="button"
            accessibilityLabel={
              (actions.data ?? []).length > 0
                ? `Notifications, ${(actions.data ?? []).length} needing attention`
                : 'Notifications'
            }
          >
            <IconBell color={M.text} size={18} />
            {(actions.data ?? []).length > 0 ? <View style={styles.badge} /> : null}
          </Pressable>
        </View>

        {/* ---------------- Create match ---------------- */}
        <Pressable
          style={styles.createCta}
          onPress={() => router.push('/match/create')}
          accessibilityRole="button"
          accessibilityLabel="Create a match"
        >
          <AppText variant="label" color={M.ctaText} style={{ fontSize: 16 }}>
            + Create a Match
          </AppText>
        </Pressable>

        {/* ---------------- Sports ---------------- */}
        <SectionHead
          M={M}
          styles={styles}
          title="SPORTS"
          actionLabel={sport ? 'Clear filter' : undefined}
          onAction={sport ? () => setSport(null) : undefined}
        />
        {sports.isLoading ? (
          <ActivityIndicator color={M.green} />
        ) : (sports.data ?? []).length === 0 ? (
          <AppText variant="caption" color={M.faint}>
            No sports are active right now.
          </AppText>
        ) : (
          <ScrollView horizontal showsHorizontalScrollIndicator={false} contentContainerStyle={styles.rail}>
            {(sports.data ?? []).map((s) => {
              const Glyph = SPORT_ICON[s.sport] ?? IconUsers;
              const on = sport === s.sport;
              return (
                <Pressable
                  key={s.id}
                  onPress={() => setSport(on ? null : s.sport)}
                  style={[styles.sportCard, on && styles.sportCardOn]}
                  accessibilityRole="button"
                  accessibilityState={{ selected: on }}
                  accessibilityLabel={`${s.name}${on ? ', filter active' : ', filter matches'}`}
                >
                  <Glyph color={on ? M.ctaText : M.green} size={26} />
                  <AppText variant="caption" color={on ? M.ctaText : M.text} numberOfLines={1}>
                    {s.name}
                  </AppText>
                </Pressable>
              );
            })}
          </ScrollView>
        )}

        {/* ---------------- Games near you ---------------- */}
        <SectionHead
          M={M}
          styles={styles}
          title="GAMES NEAR YOU"
          actionLabel="See All"
          onAction={() => router.push('/(tabs)/matches')}
        />
        {!coords ? (
          <View style={styles.card}>
            <AppText variant="label" color={M.text}>
              Set your area to see games nearby
            </AppText>
            <Pressable onPress={() => router.push('/profile/edit')} accessibilityRole="button">
              <AppText variant="caption" color={M.green}>
                Update your location →
              </AppText>
            </Pressable>
          </View>
        ) : nearby.isLoading ? (
          <ActivityIndicator color={M.green} />
        ) : (nearby.data ?? []).length === 0 ? (
          <View style={styles.card}>
            <AppText variant="label" color={M.text}>
              No open games within 5 km
            </AppText>
            <AppText variant="caption" color={M.muted}>
              Create one and let players near you join.
            </AppText>
          </View>
        ) : (
          <ScrollView horizontal showsHorizontalScrollIndicator={false} contentContainerStyle={styles.rail}>
            {(nearby.data ?? []).map((m) => (
              <Pressable
                key={m.id}
                style={styles.wideCard}
                onPress={() => router.push(`/match/${m.id}`)}
                accessibilityRole="button"
                accessibilityLabel={`${m.match_name}, ${m.missing_count} slots open. Open match`}
              >
                <View style={styles.pillRow}>
                  <View style={styles.pill}>
                    <AppText variant="caption" color={M.green}>
                      {m.status === 'open' ? 'JOINABLE' : m.status.toUpperCase()}
                    </AppText>
                  </View>
                  <AppText variant="caption" color={M.faint}>
                    {km(distanceKm(coords, m))}
                  </AppText>
                </View>
                <AppText variant="label" color={M.text} numberOfLines={1}>
                  {m.match_name}
                </AppText>
                <View style={styles.metaRow}>
                  <IconClock color={M.muted} size={12} />
                  <AppText variant="caption" color={M.muted} numberOfLines={1}>
                    {formatWhen(m.scheduled_at)}
                  </AppText>
                </View>
                {m.venue_text ? (
                  <View style={styles.metaRow}>
                    <IconPin color={M.muted} size={12} />
                    <AppText variant="caption" color={M.muted} numberOfLines={1}>
                      {m.venue_text}
                    </AppText>
                  </View>
                ) : null}
                <View style={styles.joinRow}>
                  <AppText variant="caption" color={M.muted}>
                    {m.filled_slots}/{m.total_slots} players
                  </AppText>
                  <View style={styles.joinBtn}>
                    <AppText variant="caption" color={M.ctaText}>
                      Join Match
                    </AppText>
                  </View>
                </View>
              </Pressable>
            ))}
          </ScrollView>
        )}

        {/* ---------------- Venues ---------------- */}
        <SectionHead
          M={M}
          styles={styles}
          title="VENUES"
          actionLabel="See All"
          onAction={() => router.push('/(tabs)/venues')}
        />
        {venues.isLoading ? (
          <ActivityIndicator color={M.green} />
        ) : (venues.data ?? []).length === 0 ? (
          <View style={styles.card}>
            <AppText variant="caption" color={M.muted}>
              No venues listed yet.
            </AppText>
          </View>
        ) : (
          <ScrollView horizontal showsHorizontalScrollIndicator={false} contentContainerStyle={styles.rail}>
            {(venues.data ?? []).map((v) => (
              <Pressable
                key={v.id}
                style={styles.venueCard}
                onPress={() => router.push('/(tabs)/venues')}
                accessibilityRole="button"
                accessibilityLabel={`${v.name}, ${v.address}. Open venues`}
              >
                {v.image_url ? (
                  <Image source={{ uri: v.image_url }} style={styles.venueImg} />
                ) : (
                  <View style={[styles.venueImg, styles.venueImgFallback]}>
                    <IconPin color={M.faint} size={20} />
                  </View>
                )}
                <View style={{ padding: S.sm, gap: 2 }}>
                  <AppText variant="label" color={M.text} numberOfLines={1}>
                    {v.name}
                  </AppText>
                  <AppText variant="caption" color={M.muted} numberOfLines={1}>
                    {v.address}
                  </AppText>
                  <View style={styles.venueMeta}>
                    {v.rating != null ? (
                      <View style={styles.metaRow}>
                        <IconStar color={M.green} size={11} />
                        <AppText variant="caption" color={M.muted}>
                          {v.rating}
                        </AppText>
                      </View>
                    ) : null}
                    {coords ? (
                      <AppText variant="caption" color={M.faint}>
                        {km(distanceKm(coords, v))}
                      </AppText>
                    ) : null}
                    {v.price_per_hour != null ? (
                      <AppText variant="caption" color={M.green}>
                        ₹{v.price_per_hour}/hr
                      </AppText>
                    ) : null}
                  </View>
                </View>
              </Pressable>
            ))}
          </ScrollView>
        )}

        {/* ---------------- Your matches ---------------- */}
        {upcoming.length > 0 ? (
          <>
            <SectionHead
              M={M}
              styles={styles}
              title="YOUR MATCHES"
              actionLabel="See All"
              onAction={() => router.push('/(tabs)/matches')}
            />
            <ScrollView horizontal showsHorizontalScrollIndicator={false} contentContainerStyle={styles.rail}>
              {upcoming.map(({ match, myStatus }) => (
                <Pressable
                  key={match.id}
                  style={styles.wideCard}
                  onPress={() => router.push(`/match/${match.id}`)}
                  accessibilityRole="button"
                  accessibilityLabel={`${match.match_name}. Open match`}
                >
                  <View style={styles.pillRow}>
                    <View style={styles.pill}>
                      <AppText variant="caption" color={M.green}>
                        {match.status.toUpperCase()}
                      </AppText>
                    </View>
                    {myStatus === 'invited' ? (
                      <AppText variant="caption" color={M.danger}>
                        Reply needed
                      </AppText>
                    ) : null}
                  </View>
                  <AppText variant="label" color={M.text} numberOfLines={2}>
                    {match.match_name}
                  </AppText>
                  <View style={styles.metaRow}>
                    <IconClock color={M.muted} size={12} />
                    <AppText variant="caption" color={M.muted}>
                      {formatWhen(match.scheduled_at)}
                    </AppText>
                  </View>
                  {match.venue_text ? (
                    <View style={styles.metaRow}>
                      <IconPin color={M.muted} size={12} />
                      <AppText variant="caption" color={M.muted} numberOfLines={1}>
                        {match.venue_text}
                      </AppText>
                    </View>
                  ) : null}
                  <AppText variant="caption" color={M.green} style={{ marginTop: S.xs }}>
                    View Match →
                  </AppText>
                </Pressable>
              ))}
            </ScrollView>
          </>
        ) : null}
      </ScrollView>
    </SafeAreaView>
  );
}

function SectionHead({
  M,
  styles,
  title,
  actionLabel,
  onAction,
}: {
  M: MockPalette;
  styles: ReturnType<typeof makeStyles>;
  title: string;
  actionLabel?: string;
  onAction?: () => void;
}): React.ReactNode {
  return (
    <View style={styles.sectionHead}>
      <AppText variant="caption" color={M.muted} style={{ letterSpacing: 0.5 }}>
        {title}
      </AppText>
      {actionLabel && onAction ? (
        <Pressable onPress={onAction} accessibilityRole="button" accessibilityLabel={`${actionLabel}, ${title}`} hitSlop={10}>
          <AppText variant="caption" color={M.green}>
            {actionLabel}
          </AppText>
        </Pressable>
      ) : null}
    </View>
  );
}

const makeStyles = (M: MockPalette) =>
  StyleSheet.create({
    safe: { flex: 1, backgroundColor: M.bg },
    scroll: { paddingVertical: S.md, paddingBottom: S.xl, gap: S.sm },
    header: {
      flexDirection: 'row',
      alignItems: 'center',
      gap: S.xs,
      paddingHorizontal: S.md,
      marginBottom: S.sm,
    },
    areaRow: { flexDirection: 'row', alignItems: 'center', gap: 3, marginTop: 1 },
    iconBtn: {
      width: 40,
      height: 40,
      borderRadius: 20,
      borderWidth: 1,
      borderColor: M.border,
      backgroundColor: M.card,
      alignItems: 'center',
      justifyContent: 'center',
    },
    badge: {
      position: 'absolute',
      top: 9,
      right: 10,
      width: 8,
      height: 8,
      borderRadius: 4,
      backgroundColor: M.danger,
    },
    createCta: {
      marginHorizontal: S.md,
      minHeight: 52,
      borderRadius: R.md,
      backgroundColor: M.lime,
      alignItems: 'center',
      justifyContent: 'center',
    },
    sectionHead: {
      flexDirection: 'row',
      alignItems: 'center',
      justifyContent: 'space-between',
      paddingHorizontal: S.md,
      marginTop: S.md,
    },
    // Rails bleed to the screen edge so the next card peeks in, which is what
    // tells the user the row scrolls.
    rail: { paddingHorizontal: S.md, gap: S.sm },
    card: {
      marginHorizontal: S.md,
      backgroundColor: M.card,
      borderRadius: R.md,
      borderWidth: 1,
      borderColor: M.border,
      padding: S.md,
      gap: S.xs,
    },
    sportCard: {
      width: 92,
      height: 92,
      borderRadius: R.md,
      borderWidth: 1,
      borderColor: M.border,
      backgroundColor: M.card,
      alignItems: 'center',
      justifyContent: 'center',
      gap: S.xs,
      paddingHorizontal: S.xs,
    },
    sportCardOn: { backgroundColor: M.lime, borderColor: M.lime },
    wideCard: {
      width: 250,
      borderRadius: R.md,
      borderWidth: 1,
      borderColor: M.border,
      backgroundColor: M.card,
      padding: S.md,
      gap: S.xs,
    },
    pillRow: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between' },
    pill: {
      paddingHorizontal: S.sm,
      paddingVertical: 2,
      borderRadius: R.pill,
      borderWidth: 1,
      borderColor: M.green,
    },
    metaRow: { flexDirection: 'row', alignItems: 'center', gap: 4 },
    joinRow: {
      flexDirection: 'row',
      alignItems: 'center',
      justifyContent: 'space-between',
      marginTop: S.xs,
    },
    joinBtn: {
      paddingHorizontal: S.md,
      minHeight: 32,
      borderRadius: R.pill,
      backgroundColor: M.lime,
      alignItems: 'center',
      justifyContent: 'center',
    },
    venueCard: {
      width: 200,
      borderRadius: R.md,
      borderWidth: 1,
      borderColor: M.border,
      backgroundColor: M.card,
      overflow: 'hidden',
    },
    venueImg: { width: '100%', height: 92, backgroundColor: M.cardHi },
    venueImgFallback: { alignItems: 'center', justifyContent: 'center' },
    venueMeta: { flexDirection: 'row', alignItems: 'center', gap: S.sm, marginTop: 2 },
  });
