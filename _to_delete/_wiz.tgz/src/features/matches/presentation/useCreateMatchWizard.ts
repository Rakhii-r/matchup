/**
 * State for the three-step Create Match wizard (`app/match/create/`).
 *
 * The wizard is a stack of real routes so hardware back works and each step is
 * deep-linkable, which rules out threading the answers through route params:
 * params are trivially lost on back-navigation and would have to be re-encoded
 * at every push. A tiny client store instead — same house pattern as
 * `src/core/auth/authStore.ts` — keeps every answer alive for as long as the
 * stack is mounted, so re-entering a step shows what was chosen before.
 *
 * `reset()` is called when Step 1 mounts. Going *back* to Step 1 does not
 * remount it (it is the root of the stack and was never unmounted), so a back
 * navigation preserves the answers; only a fresh entry into the wizard clears
 * them.
 */
import { create } from 'zustand';

import type { GameType, Sport } from '@shared/types/database.types';

/**
 * Which of the two flows the user picked on Step 1.
 *
 * There is exactly ONE creation engine behind both: `usePostOpenChallenge` →
 * `post_open_challenge` → radar → offers. `matchType` is stored because it is
 * persisted and displayed later; it must NEVER decide which RPC runs. The
 * opponent is always found by the search, never picked by hand, which is why
 * there is no `opponentTeamId` here.
 *
 * The old `solo` branch is gone: the wizard offers only these two team types.
 * `useCreateMatch` deliberately stays in the codebase — it is the direct
 * match-creation path and other surfaces may use it again — it simply has no
 * entry point from this wizard any more.
 */
export type MatchType = 'team_vs_team' | 'post_match';

/** The wizard routes, in order. Three steps, no branching. */
export type WizardStep = 'sport' | 'venue' | 'details';

const STEP_ORDER: WizardStep[] = ['sport', 'venue', 'details'];

/** Where a step sits in the flow, for the "Step N of 3" indicator. */
export function stepPosition(step: WizardStep): { index: number; total: number } {
  const at = STEP_ORDER.indexOf(step);
  return { index: at === -1 ? STEP_ORDER.length : at + 1, total: STEP_ORDER.length };
}

interface CreateMatchWizardState {
  // Step 1 — sport and match type share one screen.
  sport: Sport | null;
  matchType: MatchType | null;
  // Step 2
  venueId: string | null;
  // Step 3
  /** Team A. Team B is found by the radar search and is never set here. */
  teamId: string | null;
  /** Players per side. The sheet total is twice this. */
  playersPerSide: number | null;
  dayOffset: number | null;
  timeHHmm: string;
  /** Optional finish time. Empty string means "left open". */
  endTimeHHmm: string;
  gameType: GameType;
  /** Metres, to match the RPC. The chips are in km and multiply by 1000. */
  searchRadiusM: number;

  setSport: (sport: Sport) => void;
  setMatchType: (matchType: MatchType) => void;
  setVenueId: (venueId: string) => void;
  setTeamId: (teamId: string) => void;
  setPlayersPerSide: (playersPerSide: number) => void;
  setDayOffset: (dayOffset: number) => void;
  setTimeHHmm: (timeHHmm: string) => void;
  setEndTimeHHmm: (endTimeHHmm: string) => void;
  setGameType: (gameType: GameType) => void;
  setSearchRadiusM: (searchRadiusM: number) => void;
  reset: () => void;
}

/** Defaults chosen to match the old form: a friendly game, 25 km of search. */
const INITIAL = {
  sport: null,
  matchType: null,
  venueId: null,
  teamId: null,
  playersPerSide: null,
  dayOffset: null,
  timeHHmm: '',
  endTimeHHmm: '',
  gameType: 'friendly',
  searchRadiusM: 25000,
} satisfies Omit<
  CreateMatchWizardState,
  | 'setSport'
  | 'setMatchType'
  | 'setVenueId'
  | 'setTeamId'
  | 'setPlayersPerSide'
  | 'setDayOffset'
  | 'setTimeHHmm'
  | 'setEndTimeHHmm'
  | 'setGameType'
  | 'setSearchRadiusM'
  | 'reset'
>;

export const useCreateMatchWizard = create<CreateMatchWizardState>((set) => ({
  ...INITIAL,

  /**
   * Changing the sport invalidates every downstream answer that was filtered by
   * it — the venue list, the team list and the players-per-side list are all
   * per-sport, so keeping a stale id would submit a venue that does not host the
   * game. Re-picking the same sport is a no-op so tapping the selected card
   * twice does not wipe the rest of the form.
   */
  setSport: (sport) =>
    set((state) =>
      state.sport === sport ? {} : { sport, venueId: null, teamId: null, playersPerSide: null },
    ),
  // Both types post the same challenge, so switching keeps every other answer.
  setMatchType: (matchType) => set(() => ({ matchType })),
  setVenueId: (venueId) => set(() => ({ venueId })),
  setTeamId: (teamId) => set(() => ({ teamId })),
  setPlayersPerSide: (playersPerSide) => set(() => ({ playersPerSide })),
  setDayOffset: (dayOffset) => set(() => ({ dayOffset })),
  setTimeHHmm: (timeHHmm) => set(() => ({ timeHHmm })),
  setEndTimeHHmm: (endTimeHHmm) => set(() => ({ endTimeHHmm })),
  setGameType: (gameType) => set(() => ({ gameType })),
  setSearchRadiusM: (searchRadiusM) => set(() => ({ searchRadiusM })),
  reset: () => set(() => ({ ...INITIAL })),
}));
