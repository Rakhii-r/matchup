/**
 * Match Offers — one screen, two sides of the same open challenge.
 *
 * INCOMING (no params). Fixtures the matcher put in front of a team I belong
 * to. This is the accept side: losing the race is a normal outcome, not a
 * failure — the RPC row-locks the challenge and the loser gets
 * CHALLENGE_ALREADY_TAKEN, which is shown as information and the list refreshed.
 *
 * OUTGOING (`?challengeId=…`). The teams MY posted fixture was offered to,
 * which is where the radar's "View Match Offers" lands. These rows come from
 * `get_challenge_candidates`, not from the table: `teams` is members-only, so a
 * plain select can only ever give the poster a uuid for a team they are not in.
 * That RPC is the only place the poster can read a candidate's name, squad size
 * and record.
 *
 * There is deliberately NO accept button on the outgoing side.
 * `accept_open_challenge` checks `teams.owner_id = auth.uid()` for the
 * ACCEPTING team, so the poster cannot take the fixture on another squad's
 * behalf. Showing an Accept there would be a button that always fails.
 */
import { useCallback, useMemo, useState } from 'react';
import { ActivityIndicator, Alert, FlatList, Image, Pressable, StyleSheet, View } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { Stack, useLocalSearchParams, useRouter } from 'expo-router';

import { AppError } from '@core/errors/AppError';
import {
  useAcceptOpenChallenge,
  useChallengeCandidatesFull,
  useDeclineOpenChallenge,
  useMyOffers,
} from '@features/teams/presentation/useChallenges';
import { useMyTeamsOverview } from '@features/teams/presentation/useTeams';
import type { TeamOverviewRow } from '@features/teams/data/teamRepository';
import type {
  ChallengeCandidateFull,
  OpenOffer,
} from '@features/teams/domain/challengeSchema';
import { R, S, useMock, type MockPalette } from '@shared/theme/mockTheme';
import { AppText } from '@shared/ui/AppText';
import { IconUsers } from '@shared/ui/icons';

/** Smallest comfortable tap target, same figure as the create-match wizard. */
const TOUCH = 44;

function formatWhen(iso: string): string {
  const d = new Date(iso);
  if (Number.isNaN(d.getTime())) return 'Date unavailable';
  return d.toLocaleString(undefined, {
    weekday: 'short',
    day: 'numeric',
    month: 'short',
    hour: 'numeric',
    minute: '2-digit',
  });
}

function formatDistance(metres: number): string {
  if (!Number.isFinite(metres) || metres < 0) return '';
  return metres < 1000 ? `${Math.round(metres)} m away` : `${(metres / 1000).toFixed(1)} km away`;
}

/** "12 played · 7 won · 58%" — or an honest line when nothing has been played. */
function formatRecord(matchesPlayed: number, wins: number, winRate: number): string {
  if (matchesPlayed <= 0) return 'No matches played yet';
  return `${matchesPlayed} played · ${wins} won · ${winRate}% win rate`;
}

const CANDIDATE_STATUS_LABEL: Record<string, string> = {
  offered: 'Offer sent',
  accepted: 'Accepted',
  declined: 'Declined',
  expired: 'Expired',
};

/**
 * The team block from the reference card: badge, name, squad size, record.
 * Every figure is passed in from a real row — there is no default record.
 */
function TeamBlock({
  name,
  logoUrl,
  playerCount,
  matchesPlayed,
  wins,
  winRate,
  styles,
  M,
}: {
  name: string;
  logoUrl: string | null;
  playerCount: number;
  matchesPlayed: number;
  wins: number;
  winRate: number;
  styles: ReturnType<typeof makeStyles>;
  M: MockPalette;
}): React.ReactNode {
  return (
    <View style={styles.teamRow}>
      {logoUrl ? (
        <Image source={{ uri: logoUrl }} style={styles.badge} accessibilityIgnoresInvertColors />
      ) : (
        <View style={[styles.badge, styles.badgeFallback]}>
          <AppText variant="label" color={M.limeInk}>
            {name.trim().slice(0, 1).toUpperCase()}
          </AppText>
        </View>
      )}
      <View style={styles.teamText}>
        <AppText variant="label" color={M.text} numberOfLines={1}>
          {name}
        </AppText>
        <View style={styles.playersRow}>
          <IconUsers size={14} color={M.faint} />
          <AppText variant="caption" color={M.muted}>
            {playerCount === 1 ? '1 Player' : `${playerCount} Players`}
          </AppText>
        </View>
        <AppText variant="caption" color={M.faint}>
          {formatRecord(matchesPlayed, wins, winRate)}
        </AppText>
      </View>
    </View>
  );
}

export default function OffersScreen(): React.ReactNode {
  const M = useMock();
  const styles = useMemo(() => makeStyles(M), [M]);
  const router = useRouter();
  const { challengeId: rawId } = useLocalSearchParams<{ challengeId?: string }>();
  const challengeId = typeof rawId === 'string' && rawId.length > 0 ? rawId : null;

  // Both queries are declared unconditionally — hooks cannot sit behind the
  // mode check — and each is disabled in the mode it does not serve.
  const offers = useMyOffers();
  // The poster's own candidate list keeps polling here for the same reason it
  // does on the radar: a team can accept while this screen is open.
  const candidates = useChallengeCandidatesFull(challengeId);
  const myTeams = useMyTeamsOverview();
  const accept = useAcceptOpenChallenge();
  const decline = useDeclineOpenChallenge();
  const [pendingId, setPendingId] = useState<string | null>(null);

  const outgoing = challengeId !== null;

  /** My teams by id, so an incoming card can show that squad's real record. */
  const myTeamById = useMemo(() => {
    const map = new Map<string, TeamOverviewRow>();
    for (const team of myTeams.data ?? []) map.set(team.id, team);
    return map;
  }, [myTeams.data]);

  const onAccept = useCallback(
    (offer: OpenOffer) => {
      if (!offer.challenge) return;
      setPendingId(offer.id);
      accept.mutate(
        { challengeId: offer.challenge_id, teamId: offer.team_id },
        {
          onSuccess: (challenge) => {
            setPendingId(null);
            if (challenge.match_id) {
              router.replace(`/match/${challenge.match_id}`);
            } else {
              void offers.refetch();
            }
          },
          onError: (error: unknown) => {
            setPendingId(null);
            const message =
              error instanceof AppError ? error.message : 'Could not accept the fixture.';
            Alert.alert('Fixture', message);
            // Whether we lost the race or hit a validation rule, the list is
            // now stale either way.
            void offers.refetch();
          },
        },
      );
    },
    [accept, offers, router],
  );

  const renderIncoming = useCallback(
    ({ item }: { item: OpenOffer }) => {
      if (!item.challenge) return null;
      const busy = pendingId === item.id;
      const team = myTeamById.get(item.team_id);

      return (
        <View style={styles.card}>
          <AppText variant="label" color={M.text}>
            {item.challenge.match_name}
          </AppText>
          <AppText variant="caption" color={M.muted}>
            {formatWhen(item.challenge.scheduled_at)}
          </AppText>
          <AppText variant="caption" color={M.muted}>
            {formatDistance(item.distance_m)} · {item.challenge.total_slots} players
          </AppText>

          {team ? (
            <TeamBlock
              name={team.name}
              logoUrl={team.logo_url}
              playerCount={team.player_count}
              matchesPlayed={team.matches_played}
              wins={team.wins}
              winRate={team.win_rate}
              styles={styles}
              M={M}
            />
          ) : (
            // The overview call is the only source for squad size and record.
            // While it is in flight, say so rather than printing zeroes.
            <View style={styles.teamRow}>
              {myTeams.isLoading ? <ActivityIndicator color={M.green} /> : null}
              <AppText variant="caption" color={M.muted}>
                {myTeams.isError
                  ? 'Could not load your squad’s details.'
                  : myTeams.isLoading
                    ? 'Loading your squad…'
                    : `Offered to ${item.team?.name ?? 'your team'}`}
              </AppText>
            </View>
          )}

          {item.challenge.message ? (
            <AppText variant="body" color={M.text} style={styles.message}>
              {item.challenge.message}
            </AppText>
          ) : null}

          <View style={styles.ctaRow}>
            <Pressable
              onPress={() => router.push(`/teams/${item.team_id}`)}
              style={[styles.btn, styles.btnGhost]}
              accessibilityRole="button"
            >
              <AppText variant="label" color={M.green}>
                View Details
              </AppText>
            </Pressable>
            <Pressable
              onPress={() => onAccept(item)}
              disabled={accept.isPending}
              accessibilityRole="button"
              accessibilityState={{ disabled: accept.isPending, busy }}
              style={[styles.btn, styles.btnPrimary, { opacity: accept.isPending ? 0.45 : 1 }]}
            >
              {busy ? <ActivityIndicator color={M.limeInk} /> : null}
              <AppText variant="label" color={M.limeInk}>
                Accept
              </AppText>
            </Pressable>
          </View>

          <Pressable
            disabled={busy || decline.isPending}
            accessibilityRole="button"
            accessibilityState={{ disabled: busy || decline.isPending }}
            style={[styles.declineBtn, { opacity: busy || decline.isPending ? 0.45 : 1 }]}
            onPress={() =>
              Alert.alert(
                'Decline offer?',
                'This offer will no longer be available to your team.',
                [
                  { text: 'Cancel', style: 'cancel' },
                  {
                    text: 'Decline',
                    style: 'destructive',
                    onPress: () =>
                      decline.mutate({ challengeId: item.challenge_id, teamId: item.team_id }),
                  },
                ],
              )
            }
          >
            <AppText variant="caption" color={M.danger}>
              Decline
            </AppText>
          </Pressable>
        </View>
      );
    },
    [
      M,
      accept.isPending,
      decline,
      myTeamById,
      myTeams.isError,
      myTeams.isLoading,
      onAccept,
      pendingId,
      router,
      styles,
    ],
  );

  const renderCandidate = useCallback(
    ({ item }: { item: ChallengeCandidateFull }) => (
      <View style={styles.card}>
        <TeamBlock
          name={item.team_name}
          logoUrl={item.logo_url}
          playerCount={item.player_count}
          matchesPlayed={item.matches_played}
          wins={item.wins}
          winRate={item.win_rate}
          styles={styles}
          M={M}
        />
        <AppText variant="caption" color={M.muted}>
          {formatDistance(item.distance_m)} · {CANDIDATE_STATUS_LABEL[item.status] ?? item.status}
        </AppText>
        <View style={styles.ctaRow}>
          <Pressable
            onPress={() => router.push(`/teams/${item.team_id}`)}
            style={[styles.btn, styles.btnGhost]}
            accessibilityRole="button"
          >
            <AppText variant="label" color={M.green}>
              View Details
            </AppText>
          </Pressable>
        </View>
        {item.status === 'offered' ? (
          <AppText variant="caption" color={M.faint}>
            Waiting for them to accept — only their captain can take the fixture.
          </AppText>
        ) : null}
      </View>
    ),
    [M, router, styles],
  );

  // Split rather than a union of the two query objects: they resolve to
  // different row types, and only these three facts are shared.
  const isLoading = outgoing ? candidates.isLoading : offers.isLoading;
  const isError = outgoing ? candidates.isError : offers.isError;
  const onRetry = useCallback(() => {
    if (outgoing) void candidates.refetch();
    else void offers.refetch();
  }, [candidates, offers, outgoing]);

  return (
    <SafeAreaView style={styles.safe} edges={['top', 'left', 'right']}>
      <Stack.Screen options={{ title: 'Match offers' }} />

      {isLoading ? (
        <View style={styles.centre}>
          <ActivityIndicator color={M.green} />
        </View>
      ) : isError ? (
        <View style={styles.centre}>
          <AppText variant="body" color={M.danger} center>
            {outgoing ? 'Could not load the teams this fixture reached.' : 'Could not load offers.'}
          </AppText>
          <Pressable onPress={onRetry} style={styles.secondaryBtn} accessibilityRole="button">
            <AppText variant="label" color={M.green}>
              Try again
            </AppText>
          </Pressable>
        </View>
      ) : outgoing ? (
        <FlatList
          data={candidates.data ?? []}
          keyExtractor={(item) => item.candidate_id}
          renderItem={renderCandidate}
          refreshing={candidates.isRefetching}
          onRefresh={() => void candidates.refetch()}
          contentContainerStyle={styles.list}
          ListHeaderComponent={
            <AppText variant="caption" color={M.muted}>
              Teams your fixture was offered to. The first to accept gets the match.
            </AppText>
          }
          ListEmptyComponent={
            <View style={styles.centre}>
              <AppText variant="label" color={M.text} center>
                No teams reached yet
              </AppText>
              <AppText variant="caption" color={M.muted} center>
                Nobody nearby matched this fixture. Withdraw it and post again with a
                wider search radius.
              </AppText>
            </View>
          }
        />
      ) : (
        <FlatList
          data={offers.data ?? []}
          keyExtractor={(item) => item.id}
          renderItem={renderIncoming}
          refreshing={offers.isRefetching}
          onRefresh={() => void offers.refetch()}
          contentContainerStyle={styles.list}
          ListEmptyComponent={
            <View style={styles.centre}>
              <AppText variant="label" color={M.text} center>
                No offers right now
              </AppText>
              <AppText variant="caption" color={M.muted} center>
                When a nearby team posts a fixture that fits your squad, it appears here.
              </AppText>
            </View>
          }
        />
      )}
    </SafeAreaView>
  );
}

const makeStyles = (M: MockPalette) =>
  StyleSheet.create({
    safe: { flex: 1, backgroundColor: M.bg },
    list: { padding: S.md, gap: S.md },
    centre: { padding: S.xl, alignItems: 'center', gap: S.sm },
    card: {
      backgroundColor: M.card,
      borderRadius: R.lg,
      borderWidth: 1,
      borderColor: M.border,
      padding: S.md,
      gap: S.xs,
    },
    teamRow: {
      flexDirection: 'row',
      alignItems: 'center',
      gap: S.sm,
      marginTop: S.sm,
      paddingTop: S.sm,
      borderTopWidth: 1,
      borderTopColor: M.border,
    },
    teamText: { flex: 1, gap: 2 },
    playersRow: { flexDirection: 'row', alignItems: 'center', gap: S.xs },
    badge: { width: 44, height: 44, borderRadius: R.pill, backgroundColor: M.chip },
    badgeFallback: { alignItems: 'center', justifyContent: 'center', backgroundColor: M.lime },
    message: { marginTop: S.xs },
    ctaRow: { flexDirection: 'row', gap: S.sm, marginTop: S.sm },
    btn: {
      flex: 1,
      flexDirection: 'row',
      alignItems: 'center',
      justifyContent: 'center',
      gap: S.xs,
      minHeight: TOUCH,
      borderRadius: R.pill,
      paddingHorizontal: S.md,
    },
    btnGhost: { borderWidth: 1.5, borderColor: M.green },
    btnPrimary: { backgroundColor: M.green },
    declineBtn: {
      minHeight: TOUCH,
      alignItems: 'center',
      justifyContent: 'center',
      marginTop: S.xs,
    },
    secondaryBtn: {
      minHeight: TOUCH,
      paddingHorizontal: S.lg,
      alignItems: 'center',
      justifyContent: 'center',
      borderRadius: R.pill,
      borderWidth: 1.5,
      borderColor: M.green,
    },
  });
