/**
 * Finding Opponent — the radar the organiser lands on straight after posting.
 *
 * It is one route inside the create-match stack (`/match/create/searching?
 * challengeId=…`) rather than a modal, so hardware back leaves the wizard the
 * same way every other step does and the screen can be reopened from a push.
 *
 * THE RADAR IS DECORATION OVER REAL DATA. Every dot on it is a row from
 * `get_challenge_candidates` — the offer ledger for this challenge, with the
 * team names resolved server-side. Nothing is simulated: no blip exists without
 * a candidate row behind it, the search radius is read from the challenge, and
 * the count under the dish is the number of teams the matcher actually reached.
 *
 * The only thing driven by a clock is the three-line stage checklist, which is
 * labelled as presentational where it is defined.
 */
import { useCallback, useEffect, useMemo, useState } from 'react';
import {
  ActivityIndicator,
  Alert,
  Pressable,
  ScrollView,
  StyleSheet,
  View,
  useWindowDimensions,
} from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { Stack, useLocalSearchParams, useRouter } from 'expo-router';
import { MotiView } from 'moti';
import { Easing } from 'react-native-reanimated';

import { AppError } from '@core/errors/AppError';
import { TOUCH } from '@features/matches/presentation/CreateMatchWizardUI';
import {
  useCancelChallenge,
  useChallenge,
  useChallengeCandidatesFull,
} from '@features/teams/presentation/useChallenges';
import type { ChallengeCandidateFull } from '@features/teams/domain/challengeSchema';
import { R, S, useMock, type MockPalette } from '@shared/theme/mockTheme';
import { AppText } from '@shared/ui/AppText';
import { IconBack, IconSearch, IconUsers } from '@shared/ui/icons';

/** One full turn of the sweep. Slow enough to read as a scan, not a spinner. */
const SWEEP_MS = 2600;

/**
 * PRESENTATIONAL ONLY — these are NOT backend stages.
 *
 * `post_open_challenge` ranks and offers to every candidate inline, in one
 * transaction, before this screen ever mounts. There is therefore no server
 * progress to report and nothing here is derived from data: the labels are
 * driven purely off seconds elapsed so that a wait does not look frozen. Do not
 * wire them to query state — that would imply work the backend is not doing.
 */
const STAGES: { atSeconds: number; label: string }[] = [
  { atSeconds: 0, label: 'Looking for teams' },
  { atSeconds: 4, label: 'Verifying availability' },
  { atSeconds: 9, label: 'Almost there…' },
];

/**
 * Fan the dots apart by rank. A candidate row carries a distance but no
 * bearing — the matcher ranks by distance and never stores a direction — so the
 * ANGLE is a layout choice and the golden angle keeps consecutive ranks from
 * stacking on top of each other. The RADIUS is real: how far that team is, as a
 * fraction of the radius the poster asked to search.
 */
const GOLDEN_ANGLE_DEG = 137.507;

function blipOffset(
  candidate: Pick<ChallengeCandidateFull, 'rank' | 'distance_m'>,
  searchRadiusM: number | null,
  radiusPx: number,
): { x: number; y: number } {
  const angle = ((candidate.rank * GOLDEN_ANGLE_DEG - 90) * Math.PI) / 180;
  const ratio =
    searchRadiusM && searchRadiusM > 0
      ? Math.min(Math.max(candidate.distance_m / searchRadiusM, 0), 1)
      : 1;
  // Held off the centre so the closest team is still a visible dot, and inside
  // the rim so the furthest is not clipped by the outer ring.
  const r = (0.18 + 0.74 * ratio) * radiusPx;
  return { x: Math.cos(angle) * r, y: Math.sin(angle) * r };
}

function formatKm(metres: number | null): string | null {
  if (metres === null || !Number.isFinite(metres) || metres <= 0) return null;
  const km = metres / 1000;
  return km >= 10 ? `${Math.round(km)}` : `${Math.round(km * 10) / 10}`.replace(/\.0$/, '');
}

export default function SearchingScreen(): React.ReactNode {
  const M = useMock();
  const styles = useMemo(() => makeStyles(M), [M]);
  const router = useRouter();
  const { width } = useWindowDimensions();
  const { challengeId: rawId } = useLocalSearchParams<{ challengeId?: string }>();
  const challengeId = typeof rawId === 'string' && rawId.length > 0 ? rawId : null;

  const challenge = useChallenge(challengeId);
  const isOpen = challenge.data?.status === 'open';
  const candidates = useChallengeCandidatesFull(challengeId, isOpen);
  const cancel = useCancelChallenge();

  const [elapsed, setElapsed] = useState(0);

  // Cosmetic stage clock. One interval, cleared on unmount — nothing else on
  // this screen owns a timer, and the sweep is cancelled by Moti when the view
  // that carries it unmounts.
  useEffect(() => {
    const id = setInterval(() => setElapsed((n) => n + 1), 1000);
    return () => clearInterval(id);
  }, []);

  const rows = useMemo(() => candidates.data ?? [], [candidates.data]);
  const radiusM = challenge.data?.search_radius_m ?? null;
  const radiusKm = formatKm(radiusM);

  // Square, capped so it does not dominate a tablet.
  const dishSize = Math.min(width - S.lg * 2, 320);
  const radiusPx = dishSize / 2;

  const onCancel = useCallback(() => {
    if (!challengeId) return;
    Alert.alert(
      'Cancel search?',
      'The fixture will be withdrawn and the teams it was offered to will no longer see it.',
      [
        { text: 'Keep searching', style: 'cancel' },
        {
          text: 'Cancel search',
          style: 'destructive',
          onPress: () => {
            cancel.mutate(challengeId, {
              onSuccess: () => router.replace('/(tabs)'),
              onError: (e: unknown) =>
                Alert.alert(
                  'Cancel search',
                  e instanceof AppError ? e.message : 'Could not withdraw the fixture.',
                ),
            });
          },
        },
      ],
    );
  }, [cancel, challengeId, router]);

  /**
   * Widening means re-posting: `post_open_challenge` refuses a second live
   * challenge for the same team (OPEN_CHALLENGE_ALREADY_LIVE), so this one has
   * to be withdrawn before Step 3 can submit again. The wizard's answers live
   * in the zustand store, so the form comes back filled in.
   */
  const onWiden = useCallback(() => {
    if (!challengeId) return;
    Alert.alert(
      'Search a wider area?',
      'This fixture will be withdrawn so you can post it again with a bigger radius.',
      [
        { text: 'Not now', style: 'cancel' },
        {
          text: 'Change radius',
          onPress: () => {
            cancel.mutate(challengeId, {
              onSuccess: () => router.replace('/match/create/details'),
              onError: (e: unknown) =>
                Alert.alert(
                  'Search a wider area',
                  e instanceof AppError ? e.message : 'Could not withdraw the fixture.',
                ),
            });
          },
        },
      ],
    );
  }, [cancel, challengeId, router]);

  const onBack = useCallback(() => {
    if (router.canGoBack()) router.back();
    else router.replace('/(tabs)');
  }, [router]);

  // The first poll has come back and found nobody. Ranking happens inline
  // inside post_open_challenge, so an empty first answer is the final answer
  // for this radius — saying so beats sweeping forever.
  const searchedAndFoundNobody = candidates.isSuccess && rows.length === 0;
  const found = rows.length;
  const stageIndex = STAGES.reduce(
    (acc, stage, i) => (elapsed >= stage.atSeconds ? i : acc),
    0,
  );

  const header = (
    <View style={styles.header}>
      <Pressable
        onPress={onBack}
        hitSlop={10}
        style={styles.backBtn}
        accessibilityRole="button"
        accessibilityLabel="Go back"
      >
        <IconBack color={M.text} />
      </Pressable>
      <View style={styles.headerText}>
        <AppText variant="heading" color={M.text}>
          Finding Opponent
        </AppText>
      </View>
      <View style={styles.backBtn} />
    </View>
  );

  if (!challengeId) {
    return (
      <SafeAreaView style={styles.safe} edges={['top', 'left', 'right']}>
        <Stack.Screen options={{ headerShown: false }} />
        {header}
        <View style={styles.statePad}>
          <View style={styles.stateBox}>
            <AppText variant="body" color={M.danger} center>
              This link is missing the fixture it belongs to.
            </AppText>
            <Pressable onPress={onBack} style={styles.secondaryBtn} accessibilityRole="button">
              <AppText variant="label" color={M.green}>
                Go back
              </AppText>
            </Pressable>
          </View>
        </View>
      </SafeAreaView>
    );
  }

  if (challenge.isLoading) {
    return (
      <SafeAreaView style={styles.safe} edges={['top', 'left', 'right']}>
        <Stack.Screen options={{ headerShown: false }} />
        {header}
        <View style={styles.statePad}>
          <View style={styles.stateBox}>
            <ActivityIndicator color={M.green} />
            <AppText variant="body" color={M.muted} center>
              Opening your fixture…
            </AppText>
          </View>
        </View>
      </SafeAreaView>
    );
  }

  if (challenge.isError || !challenge.data) {
    return (
      <SafeAreaView style={styles.safe} edges={['top', 'left', 'right']}>
        <Stack.Screen options={{ headerShown: false }} />
        {header}
        <View style={styles.statePad}>
          <View style={styles.stateBox}>
            <AppText variant="body" color={M.danger} center>
              {challenge.isError
                ? 'Could not load this fixture.'
                : 'That fixture is no longer available.'}
            </AppText>
            <Pressable
              onPress={() => void challenge.refetch()}
              style={styles.secondaryBtn}
              accessibilityRole="button"
            >
              <AppText variant="label" color={M.green}>
                Try again
              </AppText>
            </Pressable>
          </View>
        </View>
      </SafeAreaView>
    );
  }

  const settled = challenge.data.status !== 'open';

  return (
    <SafeAreaView style={styles.safe} edges={['top', 'left', 'right']}>
      <Stack.Screen options={{ headerShown: false }} />
      {header}

      <ScrollView contentContainerStyle={styles.scroll} showsVerticalScrollIndicator={false}>
        <AppText variant="body" color={M.muted} center style={styles.lede}>
          {radiusKm
            ? `Searching for nearby teams within ${radiusKm} km…`
            : 'Searching for nearby teams…'}
        </AppText>

        {/* ---------------- The dish ---------------- */}
        <View style={styles.dishWrap}>
          <View
            style={[styles.dish, { width: dishSize, height: dishSize }]}
            accessibilityRole="image"
            accessibilityLabel={
              radiusKm
                ? `Radar showing ${found} teams found within ${radiusKm} kilometres`
                : `Radar showing ${found} teams found`
            }
          >
            <View style={styles.ringOuter} />
            <View style={styles.ringMid} />
            <View style={styles.ringInner} />

            {/* Sweep. Moti drives this on the UI thread through Reanimated and
                tears the loop down with the view, so there is no handle to
                clear here and nothing survives unmount. Paused once the
                challenge is settled — a scan that keeps turning after the
                fixture is taken is a lie. */}
            {settled ? null : (
              <MotiView
                from={{ rotate: '0deg' }}
                animate={{ rotate: '360deg' }}
                transition={{
                  type: 'timing',
                  duration: SWEEP_MS,
                  easing: Easing.linear,
                  loop: true,
                  repeatReverse: false,
                }}
                style={styles.sweep}
                pointerEvents="none"
              >
                <View style={styles.sweepArm} />
                <View style={styles.sweepTip} />
              </MotiView>
            )}

            {/* Pulse, same period as the sweep so the two read as one motion. */}
            {settled ? null : (
              <MotiView
                from={{ scale: 0.2, opacity: 0.45 }}
                animate={{ scale: 1, opacity: 0 }}
                transition={{
                  type: 'timing',
                  duration: SWEEP_MS,
                  easing: Easing.out(Easing.ease),
                  loop: true,
                  repeatReverse: false,
                }}
                style={styles.pulse}
                pointerEvents="none"
              />
            )}

            <View style={styles.hub} />

            {/* One dot per real candidate row. */}
            {rows.map((row) => {
              const { x, y } = blipOffset(row, radiusM, radiusPx);
              return (
                <MotiView
                  key={row.candidate_id}
                  from={{ opacity: 0, scale: 0.4 }}
                  animate={{ opacity: 1, scale: 1 }}
                  transition={{ type: 'timing', duration: 260 }}
                  style={[
                    styles.blip,
                    { left: radiusPx + x - BLIP / 2, top: radiusPx + y - BLIP / 2 },
                  ]}
                />
              );
            })}
          </View>
        </View>

        {/* ---------------- Count ---------------- */}
        <View style={styles.countRow}>
          {candidates.isLoading ? (
            <ActivityIndicator color={M.green} />
          ) : (
            <IconUsers color={found > 0 ? M.green : M.faint} />
          )}
          <AppText variant="label" color={found > 0 ? M.text : M.muted}>
            {candidates.isLoading
              ? 'Checking who was reached…'
              : found === 1
                ? '1 team found'
                : `${found} teams found`}
          </AppText>
        </View>

        {candidates.isError ? (
          <View style={styles.stateBox}>
            <AppText variant="body" color={M.danger} center>
              Could not load the teams this fixture reached.
            </AppText>
            <Pressable
              onPress={() => void candidates.refetch()}
              style={styles.secondaryBtn}
              accessibilityRole="button"
            >
              <AppText variant="label" color={M.green}>
                Try again
              </AppText>
            </Pressable>
          </View>
        ) : null}

        {/* ---------------- Cosmetic stage checklist ---------------- */}
        {!settled && !searchedAndFoundNobody ? (
          <View style={styles.checklist}>
            {STAGES.map((stage, i) => {
              const done = i < stageIndex;
              const active = i === stageIndex;
              return (
                <View key={stage.label} style={styles.checkRow}>
                  <View
                    style={[
                      styles.checkDot,
                      done || active ? styles.checkDotOn : styles.checkDotOff,
                    ]}
                  />
                  <AppText variant="body" color={done || active ? M.text : M.faint}>
                    {stage.label}
                  </AppText>
                  {active ? <ActivityIndicator color={M.green} size="small" /> : null}
                </View>
              );
            })}
          </View>
        ) : null}

        {/* ---------------- Honest empty state ---------------- */}
        {searchedAndFoundNobody && !settled ? (
          <View style={styles.stateBox}>
            <IconSearch color={M.faint} />
            <AppText variant="body" color={M.text} center>
              {radiusKm
                ? `No teams were found within ${radiusKm} km.`
                : 'No teams were found in that area.'}
            </AppText>
            <AppText variant="caption" color={M.muted} center>
              Nobody nearby plays this sport at that time yet. A wider search is the
              quickest way to find one.
            </AppText>
            <Pressable
              onPress={onWiden}
              style={styles.secondaryBtn}
              accessibilityRole="button"
              accessibilityState={{ disabled: cancel.isPending }}
              disabled={cancel.isPending}
            >
              <AppText variant="label" color={M.green}>
                Search a wider area
              </AppText>
            </Pressable>
          </View>
        ) : null}

        {/* ---------------- Already settled ---------------- */}
        {settled ? (
          <View style={styles.stateBox}>
            <AppText variant="body" color={M.text} center>
              {challenge.data.status === 'accepted'
                ? 'A team accepted this fixture.'
                : 'This fixture is no longer open.'}
            </AppText>
            {challenge.data.match_id ? (
              <Pressable
                onPress={() => router.replace(`/match/${challenge.data?.match_id}`)}
                style={styles.secondaryBtn}
                accessibilityRole="button"
              >
                <AppText variant="label" color={M.green}>
                  Go to the match
                </AppText>
              </Pressable>
            ) : null}
          </View>
        ) : null}
      </ScrollView>

      {/* ---------------- Actions ---------------- */}
      <View style={styles.footer}>
        {found > 0 ? (
          <Pressable
            onPress={() =>
              router.push({ pathname: '/teams/offers', params: { challengeId } })
            }
            accessibilityRole="button"
            style={({ pressed }) => [
              styles.cta,
              { transform: [{ scale: pressed ? 0.98 : 1 }] },
            ]}
          >
            <AppText variant="label" color={M.limeInk} style={styles.ctaLabel}>
              View Match Offers
            </AppText>
          </Pressable>
        ) : null}

        <Pressable
          onPress={onCancel}
          disabled={cancel.isPending || settled}
          accessibilityRole="button"
          accessibilityState={{ disabled: cancel.isPending || settled }}
          style={[styles.cancelBtn, { opacity: cancel.isPending || settled ? 0.45 : 1 }]}
        >
          {cancel.isPending ? <ActivityIndicator color={M.danger} /> : null}
          <AppText variant="label" color={M.danger}>
            Cancel Search
          </AppText>
        </Pressable>
      </View>
    </SafeAreaView>
  );
}

/** Diameter of one candidate dot. Shared by the layout maths and the style. */
const BLIP = 14;

const makeStyles = (M: MockPalette) =>
  StyleSheet.create({
    safe: { flex: 1, backgroundColor: M.bg },
    header: {
      flexDirection: 'row',
      alignItems: 'center',
      justifyContent: 'space-between',
      paddingHorizontal: S.lg,
      paddingVertical: S.sm,
    },
    backBtn: {
      width: TOUCH,
      height: TOUCH,
      alignItems: 'center',
      justifyContent: 'center',
      marginLeft: -S.sm,
    },
    headerText: { flex: 1, alignItems: 'center' },
    scroll: { paddingHorizontal: S.lg, paddingBottom: S.xl, gap: S.md },
    lede: { marginTop: S.xs },

    dishWrap: { alignItems: 'center', marginTop: S.sm },
    dish: { alignItems: 'center', justifyContent: 'center' },
    ringOuter: {
      position: 'absolute',
      width: '100%',
      height: '100%',
      borderRadius: R.pill,
      borderWidth: 1,
      borderColor: M.border,
      backgroundColor: M.card,
    },
    ringMid: {
      position: 'absolute',
      width: '66%',
      height: '66%',
      borderRadius: R.pill,
      borderWidth: 1,
      borderColor: M.border,
    },
    ringInner: {
      position: 'absolute',
      width: '33%',
      height: '33%',
      borderRadius: R.pill,
      borderWidth: 1,
      borderColor: M.border,
    },
    sweep: { position: 'absolute', width: '100%', height: '100%' },
    sweepArm: {
      position: 'absolute',
      left: '50%',
      top: 0,
      marginLeft: -1,
      width: 2,
      height: '50%',
      backgroundColor: M.green,
    },
    sweepTip: {
      position: 'absolute',
      left: '50%',
      top: -4,
      marginLeft: -4,
      width: 8,
      height: 8,
      borderRadius: R.pill,
      backgroundColor: M.green,
    },
    pulse: {
      position: 'absolute',
      width: '100%',
      height: '100%',
      borderRadius: R.pill,
      borderWidth: 2,
      borderColor: M.green,
    },
    hub: {
      width: 10,
      height: 10,
      borderRadius: R.pill,
      backgroundColor: M.green,
    },
    blip: {
      position: 'absolute',
      width: BLIP,
      height: BLIP,
      borderRadius: R.pill,
      backgroundColor: M.lime,
      borderWidth: 2,
      borderColor: M.bg,
    },

    countRow: {
      flexDirection: 'row',
      alignItems: 'center',
      justifyContent: 'center',
      gap: S.sm,
      marginTop: S.sm,
    },

    checklist: {
      backgroundColor: M.card,
      borderRadius: R.lg,
      borderWidth: 1,
      borderColor: M.border,
      padding: S.md,
      gap: S.sm,
    },
    checkRow: { flexDirection: 'row', alignItems: 'center', gap: S.sm },
    checkDot: { width: 10, height: 10, borderRadius: R.pill },
    checkDotOn: { backgroundColor: M.green },
    checkDotOff: { backgroundColor: M.border },

    stateBox: {
      backgroundColor: M.card,
      borderRadius: R.lg,
      borderWidth: 1,
      borderColor: M.border,
      padding: S.lg,
      alignItems: 'center',
      gap: S.md,
    },
    /** Wrapper for the whole-screen states, which sit outside the ScrollView. */
    statePad: { flex: 1, justifyContent: 'center', padding: S.lg },
    secondaryBtn: {
      minHeight: TOUCH,
      paddingHorizontal: S.lg,
      alignItems: 'center',
      justifyContent: 'center',
      borderRadius: R.pill,
      borderWidth: 1.5,
      borderColor: M.green,
    },

    footer: {
      paddingHorizontal: S.lg,
      paddingTop: S.sm,
      paddingBottom: S.lg,
      backgroundColor: M.bg,
      borderTopWidth: 1,
      borderTopColor: M.border,
      gap: S.sm,
    },
    cta: {
      flexDirection: 'row',
      alignItems: 'center',
      justifyContent: 'center',
      minHeight: 54,
      backgroundColor: M.green,
      borderRadius: 18,
    },
    ctaLabel: { fontSize: 16 },
    cancelBtn: {
      flexDirection: 'row',
      alignItems: 'center',
      justifyContent: 'center',
      gap: S.sm,
      minHeight: TOUCH,
      borderRadius: R.pill,
      borderWidth: 1.5,
      borderColor: M.danger,
    },
  });
