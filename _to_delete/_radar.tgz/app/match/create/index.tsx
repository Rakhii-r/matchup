/**
 * Create Match — Step 1 of 3: Select Game + Match Type.
 *
 * Sport and match type share one screen, with a single Next at the bottom that
 * stays dead until both are answered. They used to be two routes (`index` and
 * `type`); the reference frames put them together, and `type.tsx` is gone.
 *
 * Entry point of the wizard, so this is where the store is cleared. Going back
 * here from Step 2 does not remount the screen (it is the root of the nested
 * stack and was never unmounted), so a back navigation keeps every answer;
 * only a fresh entry into the wizard resets.
 *
 * Sports come from the `sports` table via `useActiveSports`, never a hard-coded
 * list — a sport hidden in Sports Management disappears from here on the next
 * refetch. Artwork comes from the one shared map in `@shared/ui/sportImages`.
 */
import { useEffect, useMemo } from 'react';
import { ImageBackground, Pressable, StyleSheet, View } from 'react-native';
import { MotiView } from 'moti';
import { useLocalSearchParams, useRouter } from 'expo-router';

import {
  useCreateMatchWizard,
  stepPosition,
  type MatchType,
} from '@features/matches/presentation/useCreateMatchWizard';
import {
  SectionLabel,
  StepState,
  TOUCH,
  WizardScreen,
} from '@features/matches/presentation/CreateMatchWizardUI';
import { useActiveSports, useSportLabel } from '@features/sports/presentation/useSports';
import type { Sport } from '@shared/types/database.types';
import { R, S, useMock, type MockPalette } from '@shared/theme/mockTheme';
import { AppText } from '@shared/ui/AppText';
import { IconSend, IconUsers } from '@shared/ui/icons';
import { SPORT_IMAGE } from '@shared/ui/sportImages';

/**
 * Exactly two options, side by side.
 *
 * They are two different promises to the user — "find me an opponent" versus
 * "advertise this and let teams come to me" — and the choice is stored and shown
 * later. It does NOT change how the match is created: both post through
 * `usePostOpenChallenge` on Step 3. See the submit comment in `details.tsx`.
 */
const MATCH_TYPES: {
  value: MatchType;
  title: string;
  tag: string;
  caption: string;
  Icon: typeof IconUsers;
}[] = [
  {
    value: 'team_vs_team',
    title: 'Team Vs Team',
    tag: '(Challenge)',
    caption: 'We offer the fixture to the closest teams that fit.',
    Icon: IconUsers,
  },
  {
    value: 'post_match',
    title: 'Post a Match',
    tag: '(Open for all)',
    caption: 'Your fixture is advertised and you wait for a taker.',
    Icon: IconSend,
  },
];

/**
 * Type guard for the untrusted `?sport=` param the Matches tab passes through.
 * Checked against SPORT_IMAGE, which is a `Record<Sport, …>` and therefore
 * exhaustive over Sport, rather than cast.
 */
function isSport(value: unknown): value is Sport {
  return typeof value === 'string' && Object.prototype.hasOwnProperty.call(SPORT_IMAGE, value);
}

export default function SelectGameStep(): React.ReactNode {
  const M = useMock();
  const styles = useMemo(() => makeStyles(M), [M]);
  const router = useRouter();
  const params = useLocalSearchParams<{ sport?: string }>();

  const sports = useActiveSports();
  const sportLabel = useSportLabel();

  const sport = useCreateMatchWizard((s) => s.sport);
  const matchType = useCreateMatchWizard((s) => s.matchType);
  const setSport = useCreateMatchWizard((s) => s.setSport);
  const setMatchType = useCreateMatchWizard((s) => s.setMatchType);
  const reset = useCreateMatchWizard((s) => s.reset);

  const preselected = isSport(params.sport) ? params.sport : null;

  // Fresh entry into the wizard: clear whatever a previous run left behind,
  // then honour the sport the Matches tab may have pre-picked.
  useEffect(() => {
    reset();
    if (preselected) setSport(preselected);
  }, [reset, setSport, preselected]);

  const { index, total } = stepPosition('sport');
  const rows = sports.data ?? [];

  return (
    <WizardScreen
      title="Create Match"
      stepIndex={index}
      totalSteps={total}
      subtitle="Pick the game and how you want to fill it."
      primaryLabel="Next"
      primaryDisabled={sport === null || matchType === null}
      onPrimary={() => router.push('/match/create/venue')}
    >
      <SectionLabel>SELECT GAME</SectionLabel>

      {sports.isLoading ? <StepState kind="loading" message="Loading sports…" /> : null}

      {sports.isError ? (
        <StepState
          kind="error"
          message="Could not load the sport list."
          actionLabel="Try again"
          onAction={() => void sports.refetch()}
        />
      ) : null}

      {!sports.isLoading && !sports.isError && rows.length === 0 ? (
        <StepState
          kind="empty"
          message="No sports are available right now. Please check back later."
        />
      ) : null}

      {rows.length > 0 ? (
        <View style={styles.grid}>
          {rows.map((row) => {
            const on = sport === row.sport;
            return (
              <Pressable
                key={row.id}
                onPress={() => setSport(row.sport)}
                style={styles.tileWrap}
                accessibilityRole="button"
                accessibilityState={{ selected: on }}
                accessibilityLabel={sportLabel(row.sport)}
              >
                <MotiView
                  animate={{ scale: on ? 1 : 0.96, borderColor: on ? M.green : M.border }}
                  transition={{ type: 'spring', damping: 14, stiffness: 180 }}
                  style={[styles.tile, on ? styles.tileOn : null]}
                >
                  <ImageBackground
                    source={SPORT_IMAGE[row.sport]}
                    style={styles.tileImage}
                    imageStyle={styles.tileImageRadius}
                  >
                    <View style={styles.shade} />
                    <AppText variant="label" color={M.text} style={styles.tileLabel}>
                      {sportLabel(row.sport)}
                    </AppText>
                  </ImageBackground>
                </MotiView>
              </Pressable>
            );
          })}
        </View>
      ) : null}

      <SectionLabel>MATCH TYPE</SectionLabel>
      <View style={styles.typeRow}>
        {MATCH_TYPES.map(({ value, title, tag, caption, Icon }) => {
          const on = matchType === value;
          return (
            <Pressable
              key={value}
              onPress={() => setMatchType(value)}
              style={styles.typeWrap}
              accessibilityRole="button"
              accessibilityState={{ selected: on }}
              accessibilityLabel={`${title} ${tag}. ${caption}`}
            >
              <MotiView
                animate={{
                  borderColor: on ? M.green : M.border,
                  backgroundColor: on ? M.cardHi : M.card,
                }}
                transition={{ type: 'timing', duration: 160 }}
                style={styles.typeCard}
              >
                <View style={styles.iconChip}>
                  <Icon color={on ? M.green : M.muted} size={20} />
                </View>
                <AppText variant="label" color={M.text} style={styles.typeTitle}>
                  {title}
                </AppText>
                <AppText variant="caption" color={on ? M.green : M.muted}>
                  {tag}
                </AppText>
                <AppText variant="caption" color={M.faint} style={styles.typeCaption}>
                  {caption}
                </AppText>
              </MotiView>
            </Pressable>
          );
        })}
      </View>
    </WizardScreen>
  );
}

const makeStyles = (M: MockPalette) =>
  StyleSheet.create({
    grid: { flexDirection: 'row', flexWrap: 'wrap', gap: S.md },
    // Two per row with one gap between them, so the tile is comfortably wider
    // than the 44pt minimum on every phone.
    tileWrap: { width: '47%', flexGrow: 1 },
    tile: {
      height: 128,
      borderRadius: 18,
      backgroundColor: M.card,
      borderWidth: 2,
      borderColor: M.border,
      overflow: 'hidden',
    },
    tileOn: {
      shadowColor: M.green,
      shadowOffset: { width: 0, height: 0 },
      shadowOpacity: 0.55,
      shadowRadius: 12,
      elevation: 10,
    },
    tileImage: { flex: 1, justifyContent: 'flex-end' },
    tileImageRadius: { borderRadius: R.md },
    shade: {
      position: 'absolute',
      top: 0,
      left: 0,
      right: 0,
      bottom: 0,
      backgroundColor: M.overlay,
    },
    tileLabel: { paddingHorizontal: S.md, paddingBottom: S.sm + 2, fontSize: 16, fontWeight: '700' },
    // The two type cards sit side by side, one row, equal width.
    typeRow: { flexDirection: 'row', gap: S.md },
    typeWrap: { flex: 1 },
    typeCard: {
      flex: 1,
      gap: S.xs,
      minHeight: 150,
      padding: S.md,
      borderRadius: R.lg,
      borderWidth: 1.5,
      borderColor: M.border,
      backgroundColor: M.card,
    },
    iconChip: {
      width: TOUCH,
      height: TOUCH,
      borderRadius: R.md,
      backgroundColor: M.iconChip,
      alignItems: 'center',
      justifyContent: 'center',
      marginBottom: S.xs,
    },
    typeTitle: { fontSize: 15 },
    typeCaption: { marginTop: S.xs },
  });
