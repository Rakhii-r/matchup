/**
 * Create Match — Step 2 of 3: Select Venue.
 *
 * Real rows from `useVenues`, filtered to the venues that actually host the
 * chosen sport — booking a badminton hall for box cricket is rejected
 * server-side anyway, so it should never be offerable here.
 *
 * "No venue hosts this sport yet" is a legitimate answer, not an error, and
 * says so rather than showing an empty list with a dead Next button.
 */
import { useMemo } from 'react';
import { Image, Pressable, StyleSheet, View } from 'react-native';
import { MotiView } from 'moti';
import { useRouter } from 'expo-router';

import {
  useCreateMatchWizard,
  stepPosition,
} from '@features/matches/presentation/useCreateMatchWizard';
import {
  SectionLabel,
  StepState,
  WizardScreen,
} from '@features/matches/presentation/CreateMatchWizardUI';
import { useSportLabel } from '@features/sports/presentation/useSports';
import { useVenues } from '@features/venues/presentation/useVenues';
import { R, S, useMock, type MockPalette } from '@shared/theme/mockTheme';
import { AppText } from '@shared/ui/AppText';
import { IconPin } from '@shared/ui/icons';
import { venueImage } from '@shared/ui/sportImages';

export default function SelectVenueStep(): React.ReactNode {
  const M = useMock();
  const styles = useMemo(() => makeStyles(M), [M]);
  const router = useRouter();

  const sport = useCreateMatchWizard((s) => s.sport);
  const venueId = useCreateMatchWizard((s) => s.venueId);
  const setVenueId = useCreateMatchWizard((s) => s.setVenueId);

  const venues = useVenues();
  const sportLabel = useSportLabel();

  const eligible = useMemo(
    () => (venues.data ?? []).filter((v) => sport !== null && v.sport_types.includes(sport)),
    [venues.data, sport],
  );

  const { index, total } = stepPosition('venue');

  // The team is picked inline on Step 3 now, so the venue leads straight there.
  const onNext = (): void => {
    router.push('/match/create/details');
  };

  return (
    <WizardScreen
      title="Select Venue"
      stepIndex={index}
      totalSteps={total}
      subtitle={sport ? `Grounds that host ${sportLabel(sport)}.` : undefined}
      primaryLabel="Next"
      primaryDisabled={venueId === null || sport === null}
      onPrimary={onNext}
    >
      {sport === null ? (
        <StepState
          kind="empty"
          message="Pick a sport before choosing a venue."
          actionLabel="Choose a sport"
          onAction={() => router.replace('/match/create')}
        />
      ) : null}

      {sport !== null ? (
        <>
          <SectionLabel>VENUE</SectionLabel>

          {venues.isLoading ? <StepState kind="loading" message="Loading venues…" /> : null}

          {venues.isError ? (
            <StepState
              kind="error"
              message="Could not load the venue list."
              actionLabel="Try again"
              onAction={() => void venues.refetch()}
            />
          ) : null}

          {!venues.isLoading && !venues.isError && eligible.length === 0 ? (
            <StepState
              kind="empty"
              message={`No venue on the app hosts ${sportLabel(sport)} yet. Try another sport, or ask an admin to add the ground.`}
              actionLabel="Change sport"
              onAction={() => router.replace('/match/create')}
            />
          ) : null}

          <View style={styles.list}>
            {eligible.map((venue) => {
              const on = venue.id === venueId;
              return (
                <Pressable
                  key={venue.id}
                  onPress={() => setVenueId(venue.id)}
                  accessibilityRole="button"
                  accessibilityState={{ selected: on }}
                  accessibilityLabel={venue.name}
                >
                  <MotiView
                    animate={{
                      borderColor: on ? M.green : M.border,
                      backgroundColor: on ? M.cardHi : M.card,
                    }}
                    transition={{ type: 'timing', duration: 160 }}
                    style={styles.row}
                  >
                    <Image source={venueImage(venue)} style={styles.thumb} />
                    <View style={styles.rowText}>
                      <AppText variant="label" color={on ? M.green : M.text} numberOfLines={1}>
                        {venue.name}
                      </AppText>
                      {venue.address ? (
                        <View style={styles.addressRow}>
                          <IconPin color={M.faint} size={14} />
                          <AppText variant="caption" color={M.muted} numberOfLines={2}>
                            {venue.address}
                          </AppText>
                        </View>
                      ) : (
                        <AppText variant="caption" color={M.faint}>
                          Address not listed
                        </AppText>
                      )}
                    </View>
                  </MotiView>
                </Pressable>
              );
            })}
          </View>
        </>
      ) : null}
    </WizardScreen>
  );
}

const makeStyles = (M: MockPalette) =>
  StyleSheet.create({
    list: { gap: S.md },
    row: {
      flexDirection: 'row',
      alignItems: 'center',
      gap: S.md,
      // Comfortably past the 44pt minimum touch target.
      minHeight: 76,
      padding: S.sm + 2,
      borderRadius: R.lg,
      borderWidth: 1.5,
      borderColor: M.border,
      backgroundColor: M.card,
    },
    thumb: { width: 64, height: 64, borderRadius: R.md, backgroundColor: M.chip },
    rowText: { flex: 1, gap: 2 },
    addressRow: { flexDirection: 'row', alignItems: 'center', gap: S.xs },
  });
