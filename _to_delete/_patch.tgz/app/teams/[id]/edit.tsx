import { useState } from 'react';
import { ActivityIndicator, Image, StyleSheet, View } from 'react-native';
import { Stack, useLocalSearchParams, useRouter } from 'expo-router';
import { AppError } from '@core/errors/AppError';
import { useTeamOverview, useUpdateTeam } from '@features/teams/presentation/useTeams';
import { colors } from '@shared/theme';
import { AppText } from '@shared/ui/AppText';
import { Button } from '@shared/ui/Button';
import { Screen } from '@shared/ui/Screen';
import { TextField } from '@shared/ui/TextField';
export default function EditTeam(): React.ReactNode { const {id}=useLocalSearchParams<{id:string}>();const teamId=id??'';const q=useTeamOverview(teamId);
 // Ownership is unknown until the overview resolves. Without this branch the
 // owner sees a "not allowed" message flash on every open.
 if(q.isLoading)return <Screen><Stack.Screen options={{title:'Edit team'}}/><View style={styles.center}><ActivityIndicator color={colors.primary}/></View></Screen>;
 if(!q.data?.i_am_owner)return <Screen><Stack.Screen options={{title:'Edit team'}}/><AppText>Only the team owner can edit team details.</AppText></Screen>;return <EditForm key={q.data.id} teamId={teamId} initial={q.data}/> }
function EditForm({teamId,initial}:{teamId:string;initial:{name:string;description:string|null;home_ground:string|null;logo_url?:string|null}}):React.ReactNode {const router=useRouter();const save=useUpdateTeam(teamId);const [name,setName]=useState(initial.name);const [description,setDescription]=useState(initial.description??'');const [homeGround,setHomeGround]=useState(initial.home_ground??'');const [error,setError]=useState<string|null>(null);const submit=async()=>{try{setError(null);await save.mutateAsync({name:name.trim(),description:description.trim(),homeGround:homeGround.trim()});router.back();}catch(e){setError(e instanceof AppError?e.message:'Unable to save changes.')}};return <Screen scroll><Stack.Screen options={{title:'Edit team'}}/>{initial.logo_url?<View style={styles.logoWrap}><Image source={{uri:initial.logo_url}} style={styles.logo}/><AppText muted>Team image is set when the team is created.</AppText></View>:null}<TextField label="Team name" value={name} onChangeText={setName} maxLength={50}/><TextField label="Description" value={description} onChangeText={setDescription} maxLength={500}/><TextField label="Home ground" value={homeGround} onChangeText={setHomeGround} maxLength={100}/>{error?<AppText color={colors.danger}>{error}</AppText>:null}<Button label="Save changes" loading={save.isPending} onPress={()=>void submit()}/></Screen>}
const styles=StyleSheet.create({center:{flex:1,alignItems:'center',justifyContent:'center'},logoWrap:{alignItems:'center',gap:8,marginBottom:16},logo:{width:96,height:96,borderRadius:48}});
