/**
 * Match Complete — mockup frame 17.
 *
 * Reached from the end of the scoring flow (`router.replace` straight after
 * `finish_match` returns) and from the match screen once
 * `matches.status = 'completed'`.
 *
 * EVERY WORD OF THE RESULT COMES FROM THE DATABASE. `finish_match` phrases
 * `matches.result_text` — "ASR WARRIORS won by 12 runs", "… won by 4 wickets",
 * "Match tied" — and this screen renders that column verbatim. The margin is
 * never recomputed here: the wickets-remaining figure depends on the confirmed
 * squad size, and two places computing it is how a scorecard starts disagreeing
 * with itself.
 *
 * Player of the Match is shown only when `motm_user_id` is set. There is no
 * picker in the app yet, so in practice the block never renders — an invented
 * name would be worse than an absent one.
 */
import { useMemo } from 'react';
import { ActivityIndicator, Pressable, ScrollView, StyleSheet, View } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { Stack, useLocalSearchParams, useRouter } from 'expo-router';

import { TOUCH } from '@features/matches/presentation/CreateMatchWizardUI';
import { useMatch, useMatchPlayers } from '@features/matches/presentation/useMatches';
import { useLiveState } from '@features/scoring/presentation/useScoring';
import { R, S, useMock, type MockPalette } from '@shared/theme/mockTheme';
import { AppText } from '@shared/ui/AppText';
import { IconStar } from '@shared/ui/icons';

export default function MatchResultScreen(): React.ReactNode {
  const M = useMock();
  const styles = useMemo(() => makeStyles(M), [M]);
  const { id } = useLocalSearchParams<{ id: string }>();
  const matchId = id ?? '';
  const router = useRouter();

  const match = useMatch(matchId);
  const live = useLiveState(matchId, true); // no polling — the match is over
  const players = useMatchPlayers(matchId);

  const state = live.data ?? null;

  /**
   * `get_live_state` returns the LATEST innings only (`order by number desc
   * limit 1`), and nothing else in the scoring feature returns both. The second
   * innings row does carry every name and number bar one:
   *
   *  - who batted second → `batting_team`
   *  - who batted first  → `bowling_team`, because the sides swap between innings
   *  - the first innings TOTAL → `target - 1`: `start_innings` writes innings 2's
   *    target as the already-closed first innings' runs + 1
   *
   * The first innings' WICKETS are the single figure no read model exposes, so
   * that side is shown as runs alone rather than with a made-up number.
   */
  const second = state !== null && state.innings_number === 2 ? state : null;
  const firstRuns = second !== null && second.target !== null ? second.target - 1 : null;

  const inningsLine = useMemo(() => {
    if (second !== null && firstRuns !== null) {
      return `${second.bowling_team} ${firstRuns} · ${second.batting_team} ${second.runs}/${second.wickets}`;
    }
    // Only one innings on record — show it rather than nothing.
    if (state !== null) return `${state.batting_team} ${state.runs}/${state.wickets}`;
    return null;
  }, [firstRuns, second, state]);

  /**
   * WHICH side won, from the same comparison `finish_match` branches on: the
   * second innings total against the first. Only the identity is derived here.
   * The margin and the wording stay in `result_text`.
   */
  const winner = useMemo(() => {
    if (second === null || firstRuns === null) return null;
    if (second.runs > firstRuns) return second.batting_team;
    if (firstRuns > second.runs) return second.bowling_team;
    return null; // level totals — a tie has no winner
  }, [firstRuns, second]);

  const isTie = second !== null && firstRuns !== null && second.runs === firstRuns;
  const resultText = match.data?.result_text ?? null;
  // A tie must never read as a blank winner.
  const headline = winner ?? (isTie ? 'Match tied' : null);

  const motmId = match.data?.motm_user_id ?? null;
  const motmName = useMemo(() => {
    if (motmId === null) return null;
    const row = (players.data ?? []).find((p) => p.user_id === motmId);
    return row?.profile?.full_name ?? 'Player';
  }, [motmId, players.data]);

  if (match.isLoading || live.isLoading) {
    return (
      <SafeAreaView style={styles.safe} edges={['top', 'left', 'right']}>
        <Stack.Screen options={{ headerShown: false }} />
        <View style={styles.statePad}>
          <View style={styles.stateBox}>
            <ActivityIndicator color={M.green} />
            <AppText variant="body" color={M.muted} center>
              Reading the result…
            </AppText>
          </View>
        </View>
      </SafeAreaView>
    );
  }

  if (match.isError || !match.data) {
    return (
      <SafeAreaView style={styles.safe} edges={['top', 'left', 'right']}>
        <Stack.Screen options={{ headerShown: false }} />
        <View style={styles.statePad}>
          <View style={styles.stateBox}>
            <AppText variant="body" color={M.danger} center>
              {match.isError ? 'Could not load this result.' : 'That match no longer exists.'}
            </AppText>
            <Pressable
              onPress={() => void match.refetch()}
              style={styles.secondaryBtn}
              accessibilityRole="button"
            >
              <AppText variant="label" color={M.green}>
                Try again
              </AppText>
            </Pressable>
            <Pressable
              onPress={() => router.replace('/(tabs)')}
              style={styles.secondaryBtn}
              accessibilityRole="button"
            >
              <AppText variant="label" color={M.green}>
                Back to Home
              </AppText>
            </Pressable>
          </View>
        </View>
      </SafeAreaView>
    );
  }

  // Someone deep-linked here before the scorer finished. Say so plainly instead
  // of dressing an unfinished match up as a result.
  if (match.data.status !== 'completed') {
    return (
      <SafeAreaView style={styles.safe} edges={['top', 'left', 'right']}>
        <Stack.Screen options={{ headerShown: false }} />
        <View style={styles.statePad}>
          <View style={styles.stateBox}>
            <AppText variant="body" color={M.text} center>
              This match has not been finished yet, so there is no result to show.
            </AppText>
            <Pressable
              onPress={() => router.replace(`/match/${matchId}/score`)}
              style={styles.secondaryBtn}
              accessibilityRole="button"
            >
              <AppText variant="label" color={M.green}>
                Back to scoring
              </AppText>
            </Pressable>
          </View>
        </View>
      </SafeAreaView>
    );
  }

  return (
    <SafeAreaView style={styles.safe} edges={['top', 'left', 'right']}>
      <Stack.Screen options={{ headerShown: false }} />

      <ScrollView contentContainerStyle={styles.scroll} showsVerticalScrollIndicator={false}>
        {/* Celebration mark. No trophy asset exists and no icon library is
            installed, so this is the existing star glyph on a brand fill. */}
        <View style={styles.markOuter}>
          <View style={styles.mark} accessibilityRole="image" accessibilityLabel="Trophy">
            <IconStar size={40} color={M.limeInk} />
          </View>
        </View>

        <AppText center style={styles.title}>
          Match Complete
        </AppText>

        {headline !== null ? (
          <AppText center style={styles.winner}>
            {headline}
          </AppText>
        ) : null}

        {/* Verbatim from matches.result_text. Skipped when it would only repeat
            the headline, which is what happens on a tie. */}
        {resultText !== null && resultText !== headline ? (
          <AppText variant="body" color={M.text} center style={styles.resultLine}>
            {resultText}
          </AppText>
        ) : null}

        {resultText === null && headline === null ? (
          <AppText variant="body" color={M.muted} center style={styles.resultLine}>
            The result was not recorded for this match.
          </AppText>
        ) : null}

        {inningsLine !== null ? (
          <View style={styles.card}>
            <AppText variant="caption" color={M.muted}>
              Innings
            </AppText>
            <AppText variant="body" color={M.text}>
              {inningsLine}
            </AppText>
          </View>
        ) : null}

        {live.isError ? (
          <View style={styles.card}>
            <AppText variant="caption" color={M.danger}>
              The innings scores could not be loaded. The result above is unaffected.
            </AppText>
            <Pressable
              onPress={() => void live.refetch()}
              style={styles.secondaryBtn}
              accessibilityRole="button"
            >
              <AppText variant="label" color={M.green}>
                Try again
              </AppText>
            </Pressable>
          </View>
        ) : null}

        {/* Only ever rendered when the column is set. */}
        {motmName !== null ? (
          <View style={styles.card}>
            <AppText variant="caption" color={M.muted}>
              Player of the Match
            </AppText>
            <AppText variant="heading" color={M.text}>
              {motmName}
            </AppText>
          </View>
        ) : null}
      </ScrollView>

      <View style={styles.footer}>
        <Pressable
          onPress={() => router.push(`/match/${matchId}/scorecard`)}
          accessibilityRole="button"
          style={({ pressed }) => [styles.cta, { transform: [{ scale: pressed ? 0.98 : 1 }] }]}
        >
          <AppText variant="label" color={M.limeInk} style={styles.ctaLabel}>
            View Scorecard
          </AppText>
        </Pressable>

        <Pressable
          onPress={() => router.replace('/(tabs)')}
          accessibilityRole="button"
          style={styles.secondaryBtn}
        >
          <AppText variant="label" color={M.green}>
            Back to Home
          </AppText>
        </Pressable>
      </View>
    </SafeAreaView>
  );
}

/** Diameter of the celebration disc. */
const MARK = 88;

const makeStyles = (M: MockPalette) =>
  StyleSheet.create({
    safe: { flex: 1, backgroundColor: M.bg },
    scroll: {
      paddingHorizontal: S.lg,
      paddingTop: S.xl,
      paddingBottom: S.xl,
      gap: S.md,
      flexGrow: 1,
    },

    markOuter: { alignItems: 'center' },
    mark: {
      width: MARK,
      height: MARK,
      borderRadius: R.pill,
      backgroundColor: M.lime,
      alignItems: 'center',
      justifyContent: 'center',
      borderWidth: 4,
      borderColor: M.iconChip,
    },

    title: { fontSize: 22, fontWeight: '700', color: M.muted },
    winner: { fontSize: 32, fontWeight: '800', color: M.text },
    resultLine: { marginTop: -S.xs },

    card: {
      backgroundColor: M.card,
      borderRadius: R.lg,
      borderWidth: 1,
      borderColor: M.border,
      padding: S.md,
      gap: S.xs,
    },

    stateBox: {
      backgroundColor: M.card,
      borderRadius: R.lg,
      borderWidth: 1,
      borderColor: M.border,
      padding: S.lg,
      alignItems: 'center',
      gap: S.md,
    },
    /** Wrapper for the whole-screen states, which sit outside the ScrollView. */
    statePad: { flex: 1, justifyContent: 'center', padding: S.lg },

    footer: {
      paddingHorizontal: S.lg,
      paddingTop: S.sm,
      paddingBottom: S.lg,
      backgroundColor: M.bg,
      borderTopWidth: 1,
      borderTopColor: M.border,
      gap: S.sm,
    },
    cta: {
      flexDirection: 'row',
      alignItems: 'center',
      justifyContent: 'center',
      minHeight: 54,
      // `lime` is the brand fill in BOTH schemes and `limeInk` is the ink that
      // carries the contrast on it — see the palette notes in mockTheme.ts.
      // `green` darkens to #5A7400 in light mode, where limeInk on it fails AA.
      backgroundColor: M.lime,
      borderRadius: 18,
    },
    ctaLabel: { fontSize: 16 },
    secondaryBtn: {
      minHeight: TOUCH,
      paddingHorizontal: S.lg,
      alignItems: 'center',
      justifyContent: 'center',
      borderRadius: R.pill,
      borderWidth: 1.5,
      borderColor: M.green,
    },
  });
