import { useMemo } from 'react';
import { Image, Pressable, ScrollView, StyleSheet, View } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { useRouter } from 'expo-router';

import { authRepository } from '@features/auth/data/authRepository';
import { useAuthStore } from '@core/auth/authStore';
import { useSportLabel } from '@features/sports/presentation/useSports';
import { useTheme } from '@shared/theme/ThemeContext';
import { R, S, useMock, type MockPalette } from '@shared/theme/mockTheme';
import { AppLogo } from '@shared/ui/AppLogo';
import { AppText } from '@shared/ui/AppText';
import {
  IconBolt,
  IconChevron,
  IconMoon,
  IconSun,
  IconEdit,
  IconGear,
  IconLogout,
  IconMenu,
  IconPin,
  IconShieldCheck,
  IconUser,
} from '@shared/ui/icons';

// A factory rather than a constant: the tints are palette values, and a frozen
// array would keep dark tints after a switch to light.
const settingsFor = (
  M: MockPalette,
): { key: string; label: string; Icon: typeof IconEdit; tint: string; route?: string }[] => [
  { key: 'edit', label: 'Edit Profile', Icon: IconEdit, tint: M.border, route: '/profile/edit' },
  { key: 'sports', label: 'Sport Preferences', Icon: IconBolt, tint: M.border, route: '/profile/edit' },
];

export default function ProfileScreen(): React.ReactNode {
  const M = useMock();
  const { isDark, setScheme } = useTheme();
  const styles = useMemo(() => makeStyles(M), [M]);
  const router = useRouter();
  const profile = useAuthStore((s) => s.profile);
  const isSuperadmin = useAuthStore((s) => s.isSuperadmin);
  const sportLabel = useSportLabel();
  const sports = profile?.sport_pref ?? [];

  return (
    <SafeAreaView style={styles.safe} edges={['top', 'left', 'right']}>
      <View style={styles.header}>
        <IconMenu color={M.text} />
        <AppLogo width={84} />
        <IconGear color={M.text} />
      </View>

      <ScrollView contentContainerStyle={styles.scroll} showsVerticalScrollIndicator={false}>
        {/* Identity — real logged-in profile */}
        <View style={styles.identity}>
          <View style={styles.avatar}>
            {profile?.avatar_url ? (
              <Image source={{ uri: profile.avatar_url }} style={styles.avatarImg} />
            ) : (
              <IconUser color={M.faint} size={54} />
            )}
          </View>
          <AppText variant="title" color={M.text} style={{ fontSize: 28, fontWeight: '800', marginTop: S.md }}>
            {profile?.full_name || 'Your profile'}
          </AppText>
          {profile?.area_name ? (
            <View style={styles.areaRow}>
              <IconPin color={M.muted} size={14} />
              <AppText variant="caption" color={M.muted} style={{ marginLeft: 4 }}>
                {profile.area_name}
              </AppText>
            </View>
          ) : null}
          {sports.length > 0 ? (
            <View style={styles.badgeRow}>
              {sports.map((s) => (
                <View key={s} style={[styles.badge, { backgroundColor: M.chip }]}>
                  <IconBolt color={M.muted} size={14} />
                  <AppText variant="caption" color={M.muted} style={styles.badgeText}>
                    {sportLabel(s)}
                  </AppText>
                </View>
              ))}
            </View>
          ) : null}
        </View>

        {/* Settings */}
        <AppText variant="caption" color={M.faint} style={styles.settingsLabel}>
          ACCOUNT SETTINGS
        </AppText>
        {/*
          The theme switch lives here as a labelled row, not only as an
          unlabelled glyph in Home's header. A header icon sitting between two
          action buttons reads as a third action; this reads as the setting it
          actually is, and it is where people look for one.
        */}
        <Pressable
          style={styles.settingRow}
          onPress={() => setScheme(isDark ? 'light' : 'dark')}
          accessibilityRole="switch"
          accessibilityState={{ checked: isDark }}
          accessibilityLabel={`Appearance, currently ${isDark ? 'dark' : 'light'}. Double tap to switch to ${isDark ? 'light' : 'dark'}.`}
        >
          <View style={[styles.settingIcon, { backgroundColor: M.iconChip }]}>
            {isDark ? <IconMoon color={M.green} size={20} /> : <IconSun color={M.green} size={20} />}
          </View>
          <AppText variant="label" color={M.text} style={{ flex: 1, fontSize: 16 }}>
            Appearance
          </AppText>
          <AppText variant="caption" color={M.muted}>
            {isDark ? 'Dark' : 'Light'}
          </AppText>
        </Pressable>

        {settingsFor(M).map(({ key, label, Icon, tint, route }) => (
          <Pressable
            key={key}
            style={styles.settingRow}
            onPress={() => (route ? router.push(route as never) : undefined)}
          >
            <View style={[styles.settingIcon, { backgroundColor: tint }]}>
              <Icon color={key === 'notif' ? M.green : M.text} size={20} />
            </View>
            <AppText variant="label" color={M.text} style={{ flex: 1, fontSize: 16 }}>
              {label}
            </AppText>
            <IconChevron color={M.faint} size={20} />
          </Pressable>
        ))}

        {/* Admin — superadmin only. RLS enforces access server-side regardless. */}
        {isSuperadmin ? (
          <>
            <AppText variant="caption" color={M.faint} style={styles.settingsLabel}>
              ADMIN
            </AppText>
            <Pressable
              style={styles.settingRow}
              onPress={() => router.push('/(admin)/venues' as never)}
            >
              <View style={[styles.settingIcon, { backgroundColor: M.iconChip }]}>
                <IconShieldCheck color={M.green} size={20} />
              </View>
              <AppText variant="label" color={M.text} style={{ flex: 1, fontSize: 16 }}>
                Manage venues
              </AppText>
              <IconChevron color={M.faint} size={20} />
            </Pressable>
            <Pressable
              style={styles.settingRow}
              onPress={() => router.push('/(admin)/users' as never)}
            >
              <View style={[styles.settingIcon, { backgroundColor: M.border }]}>
                <IconUser color={M.text} size={20} />
              </View>
              <AppText variant="label" color={M.text} style={{ flex: 1, fontSize: 16 }}>
                All users
              </AppText>
              <IconChevron color={M.faint} size={20} />
            </Pressable>
            <Pressable style={styles.settingRow} onPress={() => router.push('/(admin)/sports' as never)}>
              <View style={[styles.settingIcon, { backgroundColor: M.iconChip }]}><IconShieldCheck color={M.green} size={20} /></View>
              <AppText variant="label" color={M.text} style={{ flex: 1, fontSize: 16 }}>Sports management</AppText>
              <IconChevron color={M.faint} size={20} />
            </Pressable>
          </>
        ) : null}

        <Pressable style={styles.logout} onPress={() => void authRepository.signOut()}>
          <IconLogout color={M.danger} size={20} />
          <AppText variant="label" color={M.danger} style={{ marginLeft: S.sm, fontSize: 16 }}>
            Logout
          </AppText>
        </Pressable>
      </ScrollView>
    </SafeAreaView>
  );
}

const makeStyles = (M: MockPalette) => StyleSheet.create({
  safe: { flex: 1, backgroundColor: M.bg },
  header: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingHorizontal: S.lg,
    paddingVertical: S.md,
  },
  scroll: { paddingHorizontal: S.lg, paddingBottom: S.xl },
  identity: { alignItems: 'center', marginTop: S.sm },
  avatar: {
    width: 110,
    height: 110,
    borderRadius: 55,
    backgroundColor: M.cardHi,
    borderWidth: 3,
    borderColor: M.border,
    alignItems: 'center',
    justifyContent: 'center',
    overflow: 'hidden',
  },
  avatarImg: { width: '100%', height: '100%' },
  areaRow: { flexDirection: 'row', alignItems: 'center', marginTop: S.sm },
  badgeRow: { flexDirection: 'row', gap: S.sm, marginTop: S.md, flexWrap: 'wrap', justifyContent: 'center' },
  badge: {
    flexDirection: 'row',
    alignItems: 'center',
    borderRadius: R.pill,
    paddingHorizontal: S.md,
    paddingVertical: 6,
  },
  badgeText: { marginLeft: 5, fontWeight: '600' },
  reliability: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    backgroundColor: M.cta,
    borderRadius: R.md,
    padding: S.lg,
    marginTop: S.lg,
  },
  statRow: { flexDirection: 'row', gap: S.md, marginTop: S.md },
  statCard: {
    flex: 1,
    backgroundColor: M.card,
    borderRadius: R.md,
    borderWidth: 1,
    borderColor: M.border,
    padding: S.md,
  },
  settingsLabel: { letterSpacing: 1, fontWeight: '700', marginTop: S.xl, marginBottom: S.sm },
  settingRow: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: M.card,
    borderRadius: R.md,
    borderWidth: 1,
    borderColor: M.border,
    padding: S.md,
    marginBottom: S.md,
  },
  settingIcon: {
    width: 40,
    height: 40,
    borderRadius: R.sm,
    alignItems: 'center',
    justifyContent: 'center',
    marginRight: S.md,
  },
  logout: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    borderWidth: 1,
    borderColor: M.border,
    borderRadius: R.md,
    paddingVertical: S.md + 2,
    marginTop: S.lg,
  },
});
