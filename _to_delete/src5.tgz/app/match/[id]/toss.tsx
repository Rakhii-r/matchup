/**
 * Toss — Captain Heads/Tails Call Selection, Coin Flip Animation, and Winner Decision.
 *
 * Flow:
 *   1. No toss row: Captain selects HEADS or TAILS, picks overs (for cricket), and taps "Flip the coin".
 *   2. Flipped (no decision yet):
 *      - Explains call vs. outcome ("Team called Heads · Coin landed Heads").
 *      - If I won: Choose Bat / Bowl (or Serve / Receive).
 *      - If I lost / Spectator: Waiting indicator for the winning captain.
 *   3. Decision made: Result summary + Who bats first + Back to Match.
 *
 * ORGANISER-ONLY. `matches.creator_id` is the only account that may call, flip,
 * re-flip or choose bat/bowl — `perform_toss`, `redo_toss` and
 * `set_toss_decision` all raise NOT_THE_ORGANISER for anyone else. Both squads
 * see the same three states; only the organiser's phone has controls. Box
 * cricket is played with one person holding the app while both captains stand
 * next to them, and the previous rule (anyone on the sheet) let the opposing
 * captain flip the coin and, worse, claim the scoring keypad by opening it
 * first.
 */
import { useMemo, useState } from 'react';
import { ActivityIndicator, Alert, Pressable, StyleSheet, View } from 'react-native';
import { Stack, useLocalSearchParams, useRouter } from 'expo-router';
import { MotiView } from 'moti';

import { CoinFlip, CoinResting } from '@features/matches/presentation/CoinFlip';
import { useMock, type MockPalette } from '@shared/theme/mockTheme';

import { AppError } from '@core/errors/AppError';
import { useAuthStore } from '@core/auth/authStore';
import { useMatch } from '@features/matches/presentation/useMatches';
import {
  usePerformToss,
  useSetTossDecision,
  useToss,
  useRedoToss,
} from '@features/matches/presentation/useToss';
import {
  OVERS_OPTIONS,
  sportUsesOvers,
  tossDecisionLabel,
  tossDecisionVerb,
  type TossCall,
} from '@features/matches/domain/tossSchema';
import { radius, spacing, type AppColors } from '@shared/theme';
import { useTheme } from '@shared/theme/ThemeContext';
import { AppText } from '@shared/ui/AppText';
import { Button } from '@shared/ui/Button';
import { Screen } from '@shared/ui/Screen';

export default function TossScreen(): React.ReactNode {
  const { colors } = useTheme();
  const styles = useMemo(() => makeStyles(colors), [colors]);
  const { id } = useLocalSearchParams<{ id: string }>();
  const matchId = id ?? '';
  const router = useRouter();

  const match = useMatch(matchId);
  const toss = useToss(matchId);
  const myUserId = useAuthStore((s) => s.session?.user.id);
  const performToss = usePerformToss(matchId);
  const setDecision = useSetTossDecision(matchId);
  const redoToss = useRedoToss(matchId);

  const sport = match.data?.sport ?? null;

  /** Overs exist for box cricket only, and only until the first flip fixes them. */
  const usesOvers = sportUsesOvers(sport);
  const lockedOvers = match.data?.overs ?? null;
  const showOversPicker = usesOvers && lockedOvers === null;

  /**
   * The organiser — the only person with controls on this screen.
   *
   * This is the exact test the three toss RPCs now apply
   * (`matches.creator_id <> auth.uid()` → NOT_THE_ORGANISER), so the client is
   * neither stricter nor looser than the server. Read from the match row rather
   * than `get_toss.i_am_winner` because it has to be known BEFORE a toss row
   * exists, and `get_toss` returns nothing then.
   */
  const isOrganiser = match.data?.creator_id !== undefined && match.data.creator_id === myUserId;

  const [selectedCall, setSelectedCall] = useState<TossCall>('heads');
  const [overs, setOvers] = useState<number>(10);
  const [error, setError] = useState<string | null>(null);
  const M = useMock();

  const [flippedHere, setFlippedHere] = useState(false);
  const [landed, setLanded] = useState(false);

  const onFlip = async (): Promise<void> => {
    setError(null);
    try {
      setFlippedHere(true);
      setLanded(false);
      await performToss.mutateAsync({
        call: selectedCall,
        overs: showOversPicker ? overs : null,
      });
    } catch (e) {
      setFlippedHere(false);
      setLanded(false);
      setError(e instanceof AppError ? e.message : 'Could not do the toss.');
    }
  };

  const onFlipAgain = (): void => {
    Alert.alert(
      'Flip again?',
      `This replaces the current result using your call (${selectedCall.toUpperCase()}). Both captains are told the toss was re-flipped.`,
      [
        { text: 'Keep this result', style: 'cancel' },
        {
          text: 'Flip again',
          style: 'destructive',
          onPress: () => {
            setError(null);
            setFlippedHere(true);
            setLanded(false);
            redoToss.mutate(selectedCall, {
              onError: (e) => {
                setFlippedHere(false);
                setLanded(false);
                setError(e instanceof AppError ? e.message : 'Could not flip again.');
              },
            });
          },
        },
      ],
    );
  };

  const onChoose = async (decision: 'bat' | 'bowl'): Promise<void> => {
    setError(null);
    try {
      await setDecision.mutateAsync(decision);
    } catch (e) {
      setError(e instanceof AppError ? e.message : 'Could not save your choice.');
    }
  };

  if (match.isLoading || toss.isLoading) {
    return (
      <Screen>
        <Stack.Screen options={{ title: 'Match Toss' }} />
        <View style={styles.center}>
          <ActivityIndicator color={colors.primary} />
        </View>
      </Screen>
    );
  }

  const data = toss.data;

  return (
    <Screen scroll>
      <Stack.Screen options={{ title: 'Match Toss' }} />

      {/* ---------------- State 1: No toss yet ---------------- */}
      {!data ? (
        <View style={styles.card}>
          <CoinResting />
          <AppText variant="heading" center style={{ fontSize: 22 }}>
            Time for the Toss
          </AppText>
          <AppText variant="caption" muted center>
            Select your call (Heads or Tails). The coin is flipped randomly on the server.
          </AppText>

          {/* Captain's Heads/Tails Call Selection */}
          {isOrganiser ? (
            <View style={styles.callSection}>
              <AppText variant="label" style={styles.sectionTop}>
                Choose your call:
              </AppText>
              <View style={styles.callRow}>
                <Pressable
                  onPress={() => setSelectedCall('heads')}
                  style={[
                    styles.callOption,
                    selectedCall === 'heads' ? styles.callOptionSelected : null,
                  ]}
                  accessibilityRole="button"
                >
                  <AppText style={{ fontSize: 28 }}>🪙</AppText>
                  <View style={{ flex: 1 }}>
                    <AppText
                      variant="label"
                      color={selectedCall === 'heads' ? '#E8FF59' : colors.text}
                      style={{ fontWeight: '800', fontSize: 16 }}
                    >
                      HEADS
                    </AppText>
                    <AppText variant="caption" muted>
                      Call Heads
                    </AppText>
                  </View>
                  {selectedCall === 'heads' ? (
                    <View style={styles.checkBadge}>
                      <AppText variant="caption" color="#000" style={{ fontWeight: '900' }}>
                        ✓
                      </AppText>
                    </View>
                  ) : null}
                </Pressable>

                <Pressable
                  onPress={() => setSelectedCall('tails')}
                  style={[
                    styles.callOption,
                    selectedCall === 'tails' ? styles.callOptionSelected : null,
                  ]}
                  accessibilityRole="button"
                >
                  <AppText style={{ fontSize: 28 }}>🪙</AppText>
                  <View style={{ flex: 1 }}>
                    <AppText
                      variant="label"
                      color={selectedCall === 'tails' ? '#E8FF59' : colors.text}
                      style={{ fontWeight: '800', fontSize: 16 }}
                    >
                      TAILS
                    </AppText>
                    <AppText variant="caption" muted>
                      Call Tails
                    </AppText>
                  </View>
                  {selectedCall === 'tails' ? (
                    <View style={styles.checkBadge}>
                      <AppText variant="caption" color="#000" style={{ fontWeight: '900' }}>
                        ✓
                      </AppText>
                    </View>
                  ) : null}
                </Pressable>
              </View>
            </View>
          ) : null}

          {/* Overs selection for box cricket */}
          {showOversPicker ? (
            <>
              <AppText variant="label" style={styles.sectionTop}>
                Overs per innings
              </AppText>
              <View style={styles.chipRow}>
                {OVERS_OPTIONS.map((n) => (
                  <Button
                    key={n}
                    label={`${n} Overs`}
                    variant={n === overs ? 'primary' : 'secondary'}
                    onPress={() => setOvers(n)}
                  />
                ))}
              </View>
            </>
          ) : usesOvers && lockedOvers !== null ? (
            <AppText variant="caption" muted style={styles.sectionTop}>
              {lockedOvers} overs per innings set for this match.
            </AppText>
          ) : null}

          {isOrganiser ? (
            <>
              <View style={styles.cta}>
                <Button
                  label={`⚡ Flip the Coin (${selectedCall.toUpperCase()})`}
                  loading={performToss.isPending}
                  onPress={() => void onFlip()}
                />
              </View>
              <AppText variant="caption" muted center>
                You are running this match, so the call and the flip are yours.
              </AppText>
            </>
          ) : (
            /*
              Read-only. perform_toss would refuse this person with
              NOT_THE_ORGANISER, so a live button would only buy them an error
              they could not have avoided.
            */
            <AppText variant="caption" muted center style={styles.sectionTop}>
              The match organiser makes the call and flips the coin. The result appears here as
              soon as they do.
            </AppText>
          )}
        </View>
      ) : null}

      {/* ---------------- State 2: Flipped, awaiting the winner's choice ---------------- */}
      {data && !data.decision ? (
        <View style={styles.card}>
          <CoinFlip
            outcome={data.outcome}
            animate={flippedHere}
            flipKey={data.created_at}
            onSettled={() => setLanded(true)}
            M={M}
          />

          {!flippedHere || landed ? (
            <MotiView
              from={{ opacity: 0, translateY: 8 }}
              animate={{ opacity: 1, translateY: 0 }}
              transition={{ type: 'spring', damping: 15 }}
              style={{ gap: spacing.xs }}
            >
              {/* Call vs Outcome explanation */}
              <View style={styles.callSummaryBox}>
                <AppText variant="caption" muted center>
                  {data.calling_team_name ? data.calling_team_name : 'Calling captain'} called{' '}
                  <AppText variant="caption" color="#E8FF59" style={{ fontWeight: '800' }}>
                    {(data.called_face || 'heads').toUpperCase()}
                  </AppText>{' '}
                  · Coin landed{' '}
                  <AppText variant="caption" color="#E8FF59" style={{ fontWeight: '800' }}>
                    {data.outcome.toUpperCase()}
                  </AppText>
                </AppText>
              </View>

              <AppText variant="heading" center style={{ fontSize: 22 }}>
                {data.i_am_winner ? '🎉 You won the toss!' : `🎉 ${data.winner_team_name} won the toss`}
              </AppText>
            </MotiView>
          ) : (
            <AppText variant="caption" muted center>
              Flipping…
            </AppText>
          )}

          {data.i_am_winner && (!flippedHere || landed) ? (
            <View style={{ gap: spacing.sm, marginTop: spacing.sm }}>
              <AppText variant="label" center style={{ fontSize: 16 }}>
                What is your decision?
              </AppText>
              <View style={styles.decisionRow}>
                <Pressable
                  onPress={() => void onChoose('bat')}
                  disabled={setDecision.isPending}
                  style={[styles.decisionBtn, { backgroundColor: colors.primary }]}
                  accessibilityRole="button"
                >
                  <AppText style={{ fontSize: 24 }}>🏏</AppText>
                  <AppText variant="label" color={colors.textInverse} style={{ fontWeight: '800' }}>
                    {tossDecisionLabel(sport, 'bat').toUpperCase()}
                  </AppText>
                </Pressable>

                <Pressable
                  onPress={() => void onChoose('bowl')}
                  disabled={setDecision.isPending}
                  style={[styles.decisionBtn, { backgroundColor: colors.surface, borderColor: colors.border, borderWidth: 1 }]}
                  accessibilityRole="button"
                >
                  <AppText style={{ fontSize: 24 }}>🎳</AppText>
                  <AppText variant="label" color={colors.text} style={{ fontWeight: '800' }}>
                    {tossDecisionLabel(sport, 'bowl').toUpperCase()}
                  </AppText>
                </Pressable>
              </View>
            </View>
          ) : (
            <View style={styles.waiting}>
              <ActivityIndicator color={colors.primary} />
              <AppText variant="caption" muted>
                Waiting for {data.winner_team_name} captain to choose {sport === 'badminton' ? 'serve or receive' : 'bat or bowl'}.
              </AppText>
            </View>
          )}

          {isOrganiser && !data.decision && (!flippedHere || landed) ? (
            <View style={styles.cta}>
              <Button
                label="Flip again"
                variant="secondary"
                loading={redoToss.isPending}
                onPress={onFlipAgain}
              />
              <AppText variant="caption" muted center>
                Replaces this result. Both captains are notified.
              </AppText>
            </View>
          ) : null}
        </View>
      ) : null}

      {/* ---------------- State 3: Decided ---------------- */}
      {data?.decision ? (
        <MotiView
          from={{ opacity: 0, translateY: 12 }}
          animate={{ opacity: 1, translateY: 0 }}
          transition={{ type: 'timing', duration: 400 }}
          style={styles.card}
        >
          <View style={styles.callSummaryBox}>
            <AppText variant="caption" muted center>
              {data.calling_team_name ? data.calling_team_name : 'Calling captain'} called{' '}
              <AppText variant="caption" color="#E8FF59" style={{ fontWeight: '800' }}>
                {(data.called_face || 'heads').toUpperCase()}
              </AppText>{' '}
              · Coin landed{' '}
              <AppText variant="caption" color="#E8FF59" style={{ fontWeight: '800' }}>
                {data.outcome.toUpperCase()}
              </AppText>
            </AppText>
          </View>

          <AppText variant="heading" center style={{ fontSize: 22 }}>
            {data.winner_team_name} won the toss
          </AppText>
          <AppText style={styles.big} center>
            and elected to {tossDecisionVerb(sport, data.decision as 'bat' | 'bowl')} first
          </AppText>

          {usesOvers && data.overs ? (
            <AppText variant="caption" muted center>
              {data.overs} overs per innings
            </AppText>
          ) : null}

          <View style={styles.cta}>
            <Button
              label="Proceed to Match →"
              onPress={() => router.dismissTo(`/match/${matchId}`)}
            />
          </View>
          <AppText variant="caption" muted center>
            Match innings and batting orders are locked in.
          </AppText>
        </MotiView>
      ) : null}

      {error ? (
        <AppText variant="caption" color={colors.danger} style={styles.error}>
          {error}
        </AppText>
      ) : null}
    </Screen>
  );
}

const makeStyles = (colors: AppColors) =>
  StyleSheet.create({
    center: { flex: 1, alignItems: 'center', justifyContent: 'center', paddingTop: spacing.xxl },
    card: {
      gap: spacing.md,
      padding: spacing.lg,
      borderRadius: radius.lg,
      backgroundColor: colors.surface,
      borderWidth: 1,
      borderColor: colors.border,
    },
    sectionTop: { marginTop: spacing.xs, fontWeight: '700' },
    callSection: { gap: spacing.xs },
    callRow: { flexDirection: 'row', gap: spacing.sm },
    callOption: {
      flex: 1,
      flexDirection: 'row',
      alignItems: 'center',
      gap: spacing.sm,
      padding: spacing.md,
      borderRadius: radius.md,
      backgroundColor: colors.background,
      borderWidth: 1.5,
      borderColor: colors.border,
    },
    callOptionSelected: {
      borderColor: '#E8FF59',
      backgroundColor: 'rgba(232, 255, 89, 0.08)',
    },
    checkBadge: {
      width: 22,
      height: 22,
      borderRadius: 11,
      backgroundColor: '#E8FF59',
      alignItems: 'center',
      justifyContent: 'center',
    },
    callSummaryBox: {
      paddingHorizontal: spacing.md,
      paddingVertical: spacing.xs,
      borderRadius: radius.pill,
      backgroundColor: colors.background,
      alignSelf: 'center',
      borderWidth: 1,
      borderColor: colors.border,
      marginBottom: spacing.xs,
    },
    chipRow: { flexDirection: 'row', flexWrap: 'wrap', gap: spacing.xs },
    cta: { marginTop: spacing.sm },
    decisionRow: { flexDirection: 'row', gap: spacing.sm, marginTop: spacing.xs },
    decisionBtn: {
      flex: 1,
      padding: spacing.md,
      borderRadius: radius.md,
      alignItems: 'center',
      justifyContent: 'center',
      gap: 6,
    },
    waiting: { marginTop: spacing.md, gap: spacing.sm, alignItems: 'center' },
    big: { fontSize: 18, fontWeight: '700', color: colors.primary },
    error: { marginTop: spacing.md },
  });
