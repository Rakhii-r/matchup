import { useEffect, useRef, useState } from 'react';
import { Alert } from 'react-native';
import { useRouter } from 'expo-router';
import { useQueryClient } from '@tanstack/react-query';
import * as Haptics from 'expo-haptics';

import { supabase } from '@core/api/supabaseClient';
import { useAuthStore } from '@core/auth/authStore';
import { matchRepository } from '@features/matches/data/matchRepository';
import { challengeRepository } from '@features/teams/data/challengeRepository';
import type { MatchPlayer } from '@features/matches/domain/matchSchema';
import type { ChallengeCandidate, Challenge } from '@features/teams/domain/challengeSchema';

interface NotificationJobRow {
  id: string;
  user_id: string;
  kind: string;
  title: string;
  body: string;
  data: {
    route?: string;
    challengeId?: string;
    matchId?: string;
    teamId?: string;
  } | null;
}

/**
 * App-wide realtime push/popups and alert notifications for:
 * 1. Incoming match requests from opponent squads (open challenges & candidates)
 * 2. Incoming match join requests from individual players
 * 3. Match confirmations & acceptances
 * 4. Delivered notification jobs directly pushed to user
 */
export function MatchJoinAlerts(): null {
  const userId = useAuthStore((state) => state.session?.user.id);
  const queryClient = useQueryClient();
  const router = useRouter();
  const handledEvents = useRef(new Set<string>());

  const [instanceId] = useState(() => Math.random().toString(36).slice(2, 10));

  const invalidateAll = () => {
    void queryClient.invalidateQueries({ queryKey: ['challenges'] });
    void queryClient.invalidateQueries({ queryKey: ['challenge'] });
    void queryClient.invalidateQueries({ queryKey: ['matches'] });
    void queryClient.invalidateQueries({ queryKey: ['dashboard'] });
    void queryClient.invalidateQueries({ queryKey: ['notifications'] });
    void queryClient.invalidateQueries({ queryKey: ['pending_actions'] });
  };

  useEffect(() => {
    if (!userId) return;

    const topic = `match-join-alerts:${userId}:${instanceId}`;
    for (const stale of supabase.getChannels()) {
      if (stale.topic === `realtime:${topic}`) void supabase.removeChannel(stale);
    }

    const channel = supabase
      .channel(topic)
      // 1. Notification Jobs (Instant in-app push/popup for any enqueued notification)
      .on(
        'postgres_changes',
        { event: 'INSERT', schema: 'public', table: 'notification_jobs' },
        (payload) => {
          const job = payload.new as NotificationJobRow;
          if (job.user_id !== userId) return;

          const eventKey = `notif:${job.id}`;
          if (handledEvents.current.has(eventKey)) return;
          handledEvents.current.add(eventKey);

          void Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success).catch(() => {});
          invalidateAll();

          const route = job.data?.route;
          const challengeId = job.data?.challengeId;
          const matchId = job.data?.matchId;

          const buttons: { text: string; style?: 'cancel' | 'default' | 'destructive'; onPress?: () => void }[] = [
            { text: 'Later', style: 'cancel' },
          ];

          if (job.kind === 'challenge_interest' || challengeId) {
            buttons.push({
              text: 'View Radar ⚡',
              onPress: () => {
                const targetId = challengeId || job.data?.challengeId;
                if (targetId) {
                  router.push({
                    pathname: '/match/create/searching',
                    params: { challengeId: targetId },
                  });
                } else if (route) {
                  router.push(route as never);
                }
              },
            });
          } else if (job.kind === 'challenge_accepted' || matchId) {
            buttons.push({
              text: 'View Match 🎉',
              onPress: () => {
                if (matchId) router.push(`/match/${matchId}`);
                else if (route) router.push(route as never);
              },
            });
          } else if (route) {
            buttons.push({
              text: 'View',
              onPress: () => router.push(route as never),
            });
          }

          Alert.alert(job.title || 'Match Update', job.body || 'You have a new update.', buttons);
        },
      )
      // 2. Candidate Opponents (Interested / Applied to Open Match Challenge)
      .on(
        'postgres_changes',
        { event: 'INSERT', schema: 'public', table: 'challenge_candidates' },
        (payload) => {
          const candidate = payload.new as ChallengeCandidate;
          if (candidate.status !== 'interested') return;

          const eventKey = `candidate_insert:${candidate.id}`;
          if (handledEvents.current.has(eventKey)) return;
          handledEvents.current.add(eventKey);

          void (async () => {
            const challenge = await challengeRepository.getById(candidate.challenge_id);
            if (!challenge || challenge.created_by !== userId) return;

            void Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success).catch(() => {});
            invalidateAll();

            Alert.alert(
              '⚡ New Match Request!',
              `An opponent squad wants to play against your team in “${challenge.match_name}”!`,
              [
                { text: 'Later', style: 'cancel' },
                {
                  text: 'View Radar ⚡',
                  onPress: () => {
                    router.push({
                      pathname: '/match/create/searching',
                      params: { challengeId: candidate.challenge_id },
                    });
                  },
                },
              ],
            );
          })().catch(() => {});
        },
      )
      .on(
        'postgres_changes',
        { event: 'UPDATE', schema: 'public', table: 'challenge_candidates' },
        (payload) => {
          const candidate = payload.new as ChallengeCandidate;
          if (candidate.status !== 'interested') return;

          const eventKey = `candidate_update:${candidate.id}:${candidate.status}:${candidate.responded_at || ''}`;
          if (handledEvents.current.has(eventKey)) return;
          handledEvents.current.add(eventKey);

          void (async () => {
            const challenge = await challengeRepository.getById(candidate.challenge_id);
            if (!challenge || challenge.created_by !== userId) return;

            void Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success).catch(() => {});
            invalidateAll();

            Alert.alert(
              '⚡ Match Request Received!',
              `An opponent team sent a match request for “${challenge.match_name}”.`,
              [
                { text: 'Later', style: 'cancel' },
                {
                  text: 'View Radar ⚡',
                  onPress: () => {
                    router.push({
                      pathname: '/match/create/searching',
                      params: { challengeId: candidate.challenge_id },
                    });
                  },
                },
              ],
            );
          })().catch(() => {});
        },
      )
      // 3. Team Challenges (Direct challenge accepted or received)
      .on(
        'postgres_changes',
        { event: 'UPDATE', schema: 'public', table: 'team_challenges' },
        (payload) => {
          const challenge = payload.new as Challenge;
          if (challenge.status !== 'accepted' || !challenge.match_id) return;

          const eventKey = `challenge_accepted:${challenge.id}:${challenge.match_id}`;
          if (handledEvents.current.has(eventKey)) return;
          handledEvents.current.add(eventKey);

          void Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success).catch(() => {});
          invalidateAll();

          Alert.alert(
            '🎉 Match Confirmed!',
            `The match fixture “${challenge.match_name}” has been locked in!`,
            [
              { text: 'Later', style: 'cancel' },
              {
                text: 'View Match →',
                onPress: () => {
                  if (challenge.match_id) router.push(`/match/${challenge.match_id}`);
                },
              },
            ],
          );
        },
      )
      // 4. Match Players (Individual Player Join Requests & Approvals)
      .on(
        'postgres_changes',
        { event: 'INSERT', schema: 'public', table: 'match_players' },
        (payload) => {
          const request = payload.new as MatchPlayer;
          const eventKey = `insert:${request.id}`;
          if (handledEvents.current.has(eventKey)) return;
          handledEvents.current.add(eventKey);

          void (async () => {
            const match = await matchRepository.getById(request.match_id);
            if (!match || match.creator_id !== userId || request.status !== 'interested') return;

            const players = await matchRepository.listPlayers(request.match_id);
            const player = players.find((item) => item.id === request.id);
            const playerName = player?.profile?.full_name ?? 'A player';

            void Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success).catch(() => {});
            invalidateAll();

            Alert.alert(
              'New join request',
              `${playerName} is interested in joining “${match.match_name}”.`,
              [
                { text: 'Later', style: 'cancel' },
                {
                  text: 'Accept',
                  onPress: () => {
                    void matchRepository
                      .setPlayerStatus(request.id, 'approved')
                      .then(() => {
                        void queryClient.invalidateQueries({ queryKey: ['match', request.match_id] });
                      })
                      .catch(() => Alert.alert('Could not accept player', 'Please try again from the match screen.'));
                  },
                },
              ],
            );
          })().catch(() => {});
        },
      )
      .on(
        'postgres_changes',
        { event: 'UPDATE', schema: 'public', table: 'match_players' },
        (payload) => {
          const membership = payload.new as MatchPlayer;
          if (membership.user_id !== userId || membership.status !== 'approved') return;

          const eventKey = `approved:${membership.id}`;
          if (handledEvents.current.has(eventKey)) return;
          handledEvents.current.add(eventKey);

          void Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success).catch(() => {});
          invalidateAll();

          void (async () => {
            const match = await matchRepository.getById(membership.match_id);
            Alert.alert(
              'Join request accepted',
              match
                ? `You have been accepted for “${match.match_name}”.`
                : 'The match creator accepted your join request.',
              [
                { text: 'OK' },
                ...(match ? [{ text: 'View Match', onPress: () => router.push(`/match/${match.id}`) }] : []),
              ],
            );
          })().catch(() => {
            Alert.alert('Join request accepted', 'The match creator accepted your join request.');
          });
        },
      )
      .subscribe();

    return () => {
      void supabase.removeChannel(channel);
    };
  }, [instanceId, queryClient, router, userId]);

  return null;
}
