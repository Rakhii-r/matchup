import { useEffect, useMemo, useRef, useState } from 'react';
import {
  Alert,
  Animated,
  FlatList,
  Image,
  ImageBackground,
  Pressable,
  StyleSheet,
  View,
} from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { MotiView } from 'moti';
import { useLocalSearchParams, useRouter } from 'expo-router';

import { showDemoMatches } from '@core/config/env';
import { getCurrentCoords } from '@core/location/location';
import type { Coords } from '@core/location/location';
import { AppError } from '@core/errors/AppError';
import {
  useMyMatches,
  useNearbyMatches,
  useRequestToJoinAny,
} from '@features/matches/presentation/useMatches';
import { DEMO_MATCHES, isDemoMatch } from '@features/matches/domain/demoMatches';
import { useSportLabel } from '@features/sports/presentation/useSports';
import type { Match } from '@features/matches/domain/matchSchema';
import type { MatchStatus, Sport } from '@shared/types/database.types';
import { R, S, useMock, type MockPalette } from '@shared/theme/mockTheme';
import { AppLogo } from '@shared/ui/AppLogo';
import { AppText } from '@shared/ui/AppText';
import {
  IconClock,
  IconGear,
  IconPin,
  IconPlus,
  IconSend,
} from '@shared/ui/icons';
import { SPORT_IMAGE } from '@shared/ui/sportImages';

const WEEKDAY = ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'];
const MONTH = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];

function formatWhen(iso: string): string {
  const d = new Date(iso);
  const hh = String(d.getHours()).padStart(2, '0');
  const mm = String(d.getMinutes()).padStart(2, '0');
  return `${WEEKDAY[d.getDay()]} ${d.getDate()} ${MONTH[d.getMonth()]}, ${hh}:${mm}`;
}

const SPORT_CARDS: { value: Sport; label: string }[] = [
  { value: 'box_cricket', label: 'Cricket' },
  { value: 'badminton', label: 'Badminton' },
];

const STATUS_LABEL: Record<MatchStatus, string> = {
  open: 'OPEN',
  locked: 'LOCKED',
  completed: 'DONE',
  cancelled: 'CANCELLED',
};

// Statuses that mean the match is over and should not sit in "Your Matches".
// MatchStatus (src/shared/types/database.types.ts) is exactly
// 'open' | 'locked' | 'completed' | 'cancelled' — there is no 'withdrawn' —
// so 'open' and 'locked' are the live/upcoming ones we keep.
const FINISHED_STATUSES: ReadonlySet<MatchStatus> = new Set<MatchStatus>([
  'completed',
  'cancelled',
]);

/**
 * Type guard for an untrusted route param. The value arrives as
 * `string | string[] | undefined` from `useLocalSearchParams`, so it is checked
 * against the app's own sport keys rather than cast. SPORT_IMAGE is a
 * `Record<Sport, …>`, i.e. exhaustive over Sport, so adding a sport later
 * cannot leave this validator behind.
 */
function isSport(value: unknown): value is Sport {
  return typeof value === 'string' && Object.prototype.hasOwnProperty.call(SPORT_IMAGE, value);
}

/** De-duplicate matches by id, keeping first occurrence and stable order. */
function dedupeById(rows: Match[]): Match[] {
  const seen = new Set<string>();
  const out: Match[] = [];
  for (const row of rows) {
    if (seen.has(row.id)) continue;
    seen.add(row.id);
    out.push(row);
  }
  return out;
}

/** Pressable that scales down slightly while pressed. */
function ScalePressable({
  onPress,
  style,
  children,
  accessibilityLabel,
}: {
  onPress: () => void;
  style?: object;
  children: React.ReactNode;
  /** Required when the child is an icon with no text, or the button is unlabelled. */
  accessibilityLabel?: string;
}): React.ReactNode {
  const scale = useRef(new Animated.Value(1)).current;
  const to = (v: number) =>
    Animated.spring(scale, { toValue: v, useNativeDriver: true, speed: 40, bounciness: 4 }).start();
  return (
    <Pressable
      onPress={onPress}
      accessibilityLabel={accessibilityLabel}
      onPressIn={() => to(0.97)}
      onPressOut={() => to(1)}
      accessibilityRole="button"
    >
      <Animated.View style={[style, { transform: [{ scale }] }]}>{children}</Animated.View>
    </Pressable>
  );
}

/** Pulsing skeleton card shown while nearby matches load. */
function SkeletonCards(): React.ReactNode {
  const M = useMock();
  const styles = useMemo(() => makeStyles(M), [M]);
  const opacity = useRef(new Animated.Value(0.35)).current;
  useEffect(() => {
    const loop = Animated.loop(
      Animated.sequence([
        Animated.timing(opacity, { toValue: 0.7, duration: 700, useNativeDriver: true }),
        Animated.timing(opacity, { toValue: 0.35, duration: 700, useNativeDriver: true }),
      ]),
    );
    loop.start();
    return () => loop.stop();
  }, [opacity]);
  return (
    <View style={{ gap: S.md, paddingTop: S.md }}>
      {[0, 1, 2].map((i) => (
        <Animated.View key={i} style={[styles.skeleton, { opacity }]}>
          <View style={styles.skeletonThumb} />
          <View style={{ flex: 1, gap: S.sm }}>
            <View style={[styles.skeletonLine, { width: '55%' }]} />
            <View style={[styles.skeletonLine, { width: '35%' }]} />
          </View>
        </Animated.View>
      ))}
    </View>
  );
}

/** Premium empty state: pulsing location marker, headline, description, CTA. */
function EmptyState({ onCreate }: { onCreate: () => void }): React.ReactNode {
  const M = useMock();
  const styles = useMemo(() => makeStyles(M), [M]);
  const pulse = useRef(new Animated.Value(0)).current;
  useEffect(() => {
    const loop = Animated.loop(
      Animated.sequence([
        Animated.timing(pulse, { toValue: 1, duration: 1400, useNativeDriver: true }),
        Animated.timing(pulse, { toValue: 0, duration: 0, useNativeDriver: true }),
      ]),
    );
    loop.start();
    return () => loop.stop();
  }, [pulse]);
  const ringScale = pulse.interpolate({ inputRange: [0, 1], outputRange: [0.7, 1.6] });
  const ringOpacity = pulse.interpolate({ inputRange: [0, 1], outputRange: [0.5, 0] });
  return (
    <View style={styles.emptyCard}>
      <View style={styles.emptyMarkerWrap}>
        <Animated.View
          style={[styles.emptyRing, { transform: [{ scale: ringScale }], opacity: ringOpacity }]}
        />
        <View style={styles.emptyMarker}>
          <IconPin color={M.green} size={26} />
        </View>
      </View>
      <AppText variant="heading" color={M.text} center style={{ fontSize: 19, marginTop: S.md }}>
        No open matches within 5 km.
      </AppText>
      <AppText color={M.muted} center style={{ marginTop: 4 }}>
        Be the first — create one!
      </AppText>
      <ScalePressable onPress={onCreate} style={styles.emptyCta}>
        <IconPlus color={M.limeInk} size={18} />
        <AppText variant="label" color={M.limeInk} style={{ fontSize: 15, marginLeft: 6 }}>
          Create Match
        </AppText>
      </ScalePressable>
    </View>
  );
}

export default function NearbyScreen(): React.ReactNode {
  const M = useMock();
  const styles = useMemo(() => makeStyles(M), [M]);
  const router = useRouter();
  const [coords, setCoords] = useState<Coords | null>(null);
  const [locating, setLocating] = useState(true);
  const [sport, setSport] = useState<Sport | null>(null);

  // Home can deep-link into this tab with a sport pre-selected:
  //   router.push({ pathname: '/(tabs)/matches', params: { sport: 'box_cricket' } })
  // The raw param is untrusted (`string | string[] | undefined`), so it is
  // normalised and validated before it is allowed anywhere near the filter.
  const params = useLocalSearchParams<{ sport?: string | string[] }>();
  const rawSportParam = Array.isArray(params.sport) ? params.sport[0] : params.sport;
  const sportParam = isSport(rawSportParam) ? rawSportParam : null;

  // Param-sync rule: the param seeds the filter on arrival and re-applies only
  // when its VALUE CHANGES (the user can tap a different sport on Home and come
  // back, which a mount-only initialiser would silently ignore). Between changes
  // the param stays quiet, so a manual tap — including clearing the filter back
  // to "all sports" — is never overwritten on the next render. An absent or
  // unrecognised param leaves the current filter exactly as it is.
  const appliedSportParam = useRef<Sport | null>(null);
  useEffect(() => {
    if (sportParam === null) return;
    if (appliedSportParam.current === sportParam) return;
    appliedSportParam.current = sportParam;
    setSport(sportParam);
  }, [sportParam]);

  useEffect(() => {
    let active = true;
    void (async () => {
      const c = await getCurrentCoords();
      if (active) {
        setCoords(c);
        setLocating(false);
      }
    })();
    return () => {
      active = false;
    };
  }, []);

  const nearby = useNearbyMatches(coords, sport);
  const myMatches = useMyMatches();
  const sportLabel = useSportLabel();

  // Real rows, de-duplicated. Fake rows are appended only in demo mode
  // (EXPO_PUBLIC_DEMO_MATCHES=true, never in production) so a client walkthrough
  // doesn't open on an empty screen. When both are empty, the empty state shows.
  const list = useMemo<Match[]>(() => {
    const real = nearby.data ?? [];
    return dedupeById(showDemoMatches ? [...real, ...DEMO_MATCHES] : real);
  }, [nearby.data]);

  // "Your Matches" is a way back into matches you can still act on, so finished
  // ones are hidden from this section. Nothing is dropped from the query — the
  // data is untouched, only this section's display is filtered.
  const myLiveMatches = useMemo<Match[]>(
    () => (myMatches.data ?? []).filter((m) => !FINISHED_STATUSES.has(m.status)),
    [myMatches.data],
  );

  const goCreate = () =>
    router.push({ pathname: '/match/create', params: sport ? { sport } : {} });

  const openMatch = (item: Match) => {
    // Demo rows have no database row behind them, so the detail screen would
    // just report "could not be found". Say so plainly instead.
    if (isDemoMatch(item.id)) {
      Alert.alert('Sample match', 'This is placeholder data for the demo and cannot be joined.');
      return;
    }
    router.push({ pathname: '/match/[id]', params: { id: item.id } });
  };

  // Ask to join straight from a card, without a detour through the detail
  // screen. On success we open the match so the player can watch their request
  // move through the organiser's queue.
  const joinAny = useRequestToJoinAny();
  const [joiningId, setJoiningId] = useState<string | null>(null);

  const onJoinPress = async (item: Match): Promise<void> => {
    if (isDemoMatch(item.id)) {
      Alert.alert('Sample match', 'This is placeholder data for the demo and cannot be joined.');
      return;
    }
    if (joiningId) return;
    setJoiningId(item.id);
    try {
      await joinAny.mutateAsync(item.id);
      router.push({ pathname: '/match/[id]', params: { id: item.id } });
    } catch (e) {
      Alert.alert(
        'Could not join',
        e instanceof AppError ? e.message : 'Something went wrong. Please try again.',
      );
    } finally {
      setJoiningId(null);
    }
  };

  // Which non-list state (if any) to show under the header. When null, the list
  // of match cards renders instead.
  const busy = locating || (coords != null && nearby.isLoading);
  const showCards = !busy && !nearby.isError && list.length > 0;
  const data = showCards ? list : [];

  const renderItem = ({ item }: { item: Match }) => {
    const filled = item.filled_slots;
    const total = item.total_slots;
    const pct = total > 0 ? Math.min(1, filled / total) : 0;
    const isOpen = item.status === 'open';
    const title = item.match_name;
    return (
      <ScalePressable onPress={() => openMatch(item)} style={styles.card}>
        <View style={styles.cardTop}>
          <Image source={SPORT_IMAGE[item.sport]} style={styles.cardThumb} />
          <View style={{ flex: 1, gap: 4 }}>
            <View style={styles.cardTitleRow}>
              <AppText variant="heading" color={M.text} style={{ fontSize: 16, flex: 1 }}>
                {title}
              </AppText>
              <View style={[styles.badge, isOpen ? styles.badgeOpen : null]}>
                <AppText
                  variant="caption"
                  color={isOpen ? M.green : M.muted}
                  style={styles.badgeText}
                >
                  {STATUS_LABEL[item.status]}
                </AppText>
              </View>
            </View>
            <View style={styles.metaRow}>
              <IconClock color={M.muted} size={14} />
              <AppText variant="caption" color={M.muted}>
                {formatWhen(item.scheduled_at)}
              </AppText>
            </View>
          </View>
        </View>

        {item.venue_text ? (
          <View style={styles.metaRow}>
            <IconPin color={M.muted} size={14} />
            <AppText variant="caption" color={M.muted} style={{ flex: 1 }}>
              {item.venue_text}
            </AppText>
          </View>
        ) : null}

        <View style={styles.slotsRow}>
          <AppText variant="label" color={M.text}>
            {filled}/{total} Players
          </AppText>
          <AppText variant="caption" color={M.muted}>
            {item.missing_count} {item.missing_count === 1 ? 'spot' : 'spots'} left
          </AppText>
        </View>
        <View style={styles.progressTrack}>
          <View style={[styles.progressFill, { width: `${Math.round(pct * 100)}%` }]} />
        </View>

        <ScalePressable
          onPress={() => (isOpen ? void onJoinPress(item) : openMatch(item))}
          style={[styles.joinBtn, !isOpen || joiningId != null ? styles.joinBtnDisabled : null]}
        >
          <AppText variant="label" color={M.text}>
            {joiningId === item.id ? 'Requesting…' : isOpen ? 'Join Match' : 'View'}
          </AppText>
        </ScalePressable>
      </ScalePressable>
    );
  };

  // Static top-of-screen content. Lives inside the list header so it scrolls
  // with the cards and can never overlap them (single scroll container).
  const ListHeader = (
    <View>
      {/* Brand row */}
      <View style={styles.header}>
        <AppLogo width={92} />
        <View style={styles.headerActions}>
          <ScalePressable onPress={() => router.push('/profile/edit')} style={styles.gearBtn}>
            <IconGear color={M.text} size={20} />
          </ScalePressable>
        </View>
      </View>

      <View style={styles.intro}>
        <AppText variant="title" color={M.text} style={{ fontSize: 26 }}>
          Matches near you
        </AppText>
        <AppText variant="caption" color={M.muted}>
          {sport === null
            ? 'Showing all sports — tap a sport to filter'
            : `Showing ${sportLabel(sport)} only`}
        </AppText>
      </View>

      {/* Sport image cards */}
      <View style={styles.sportRow}>
        {SPORT_CARDS.map(({ value, label }) => {
          const on = sport === value;
          return (
            <Pressable
              key={value}
              style={styles.sportCardWrap}
              onPress={() => setSport(on ? null : value)}
              accessibilityRole="button"
              accessibilityState={{ selected: on }}
            >
              <MotiView
                animate={{ scale: on ? 1 : 0.97, borderColor: on ? M.green : M.border }}
                transition={{ type: 'spring', damping: 14, stiffness: 180 }}
                style={[styles.sportCard, on ? styles.sportCardOn : null]}
              >
                <ImageBackground
                  source={SPORT_IMAGE[value]}
                  style={styles.sportImage}
                  imageStyle={{ borderRadius: 18 }}
                >
                  <View style={styles.sportShade} />
                  <View style={styles.sportTextWrap}>
                    <AppText variant="label" color={M.text} style={styles.sportLabel}>
                      {label}
                    </AppText>
                    <AppText variant="caption" color={M.muted}>
                      Find matches
                    </AppText>
                  </View>
                </ImageBackground>
              </MotiView>
            </Pressable>
          );
        })}
      </View>

      {/* Actions */}
      <View style={styles.actions}>
        <ScalePressable onPress={goCreate} style={styles.primaryBtn}>
          <IconPlus color={M.limeInk} size={18} />
          <AppText
            variant="label"
            color={M.limeInk}
            numberOfLines={1}
            style={{ fontSize: 15, lineHeight: 18, marginLeft: 6, flexShrink: 1 }}
          >
            Create Match
          </AppText>
        </ScalePressable>
        <ScalePressable onPress={() => router.push('/match/join')} style={styles.secondaryBtn}>
          <IconSend color={M.text} size={18} />
          <AppText
            variant="label"
            color={M.text}
            numberOfLines={1}
            style={{ fontSize: 15, lineHeight: 18, marginLeft: 6, flexShrink: 1 }}
          >
            Join with code
          </AppText>
        </ScalePressable>
      </View>

      {/* Section heading — only when cards are shown below */}
      {showCards && data.length > 0 ? (
        <AppText variant="label" color={M.text} style={styles.listHeading}>
          Nearby matches
        </AppText>
      ) : null}

      {/* Non-list states render here, still under the buttons */}
      {busy ? (
        <SkeletonCards />
      ) : !coords ? (
        <View style={styles.notice}>
          <AppText color={M.muted} center>
            Turn on location to see matches near you. You can still create or join with a code.
          </AppText>
        </View>
      ) : nearby.isError ? (
        <View style={styles.notice}>
          <AppText color={M.muted} center>
            Could not load nearby matches.
          </AppText>
          <ScalePressable onPress={() => void nearby.refetch()} style={styles.retryBtn}>
            <AppText variant="label" color={M.text}>
              Retry
            </AppText>
          </ScalePressable>
        </View>
      ) : list.length === 0 ? (
        <EmptyState onCreate={goCreate} />
      ) : null}
    </View>
  );

  // Ordering: nearby is the primary content, so the sport cards, the
  // Create/Join buttons and then the "Nearby matches" heading and its
  // loading/empty/error states finish the header — the nearby cards the
  // FlatList renders from `data` come straight after them. "Your Matches" is
  // history, so it now trails the nearby list instead of leading the screen.
  // It lives in the footer because the header ends where the cards begin:
  // anything appended to ListHeader after the nearby states would wedge itself
  // between the "Nearby matches" heading and the cards it belongs to.
  const ListFooter = (
    <View>
      {/* Full matches list. Deliberately NOT gated on myMatches.length — a user
          who has only joined matches still needs a way in. */}
      {/* My matches — matches you created, so you can always get back to them */}
      {myLiveMatches.length > 0 ? (
        <View style={{ marginTop: S.lg, marginBottom: S.lg }}>
          <AppText variant="label" color={M.text} style={styles.listHeading}>
            Your Matches
          </AppText>
          {myLiveMatches.map((m) => (
            <ScalePressable key={m.id} onPress={() => openMatch(m)} style={styles.mineRow}>
              <View style={{ flex: 1 }}>
                <AppText variant="label" color={M.text}>
                  {m.notes?.trim() ? m.notes.trim() : sportLabel(m.sport)}
                </AppText>
                <AppText variant="caption" color={M.muted}>
                  {formatWhen(m.scheduled_at)} · {STATUS_LABEL[m.status]}
                </AppText>
              </View>
              <AppText variant="caption" color={M.muted}>
                {m.filled_slots}/{m.total_slots}
              </AppText>
            </ScalePressable>
          ))}
        </View>
      ) : null}
    </View>
  );

  return (
    <SafeAreaView style={styles.safe} edges={['top', 'left', 'right']}>
      <FlatList
        style={styles.list}
        data={data}
        keyExtractor={(m) => m.id}
        renderItem={renderItem}
        ListHeaderComponent={ListHeader}
        ListFooterComponent={ListFooter}
        onRefresh={coords ? () => void nearby.refetch() : undefined}
        refreshing={nearby.isRefetching}
        showsVerticalScrollIndicator={false}
        removeClippedSubviews
        initialNumToRender={6}
        windowSize={7}
        ItemSeparatorComponent={() => <View style={{ height: S.md }} />}
        contentContainerStyle={styles.listContent}
      />
    </SafeAreaView>
  );
}

const makeStyles = (M: MockPalette) =>
  StyleSheet.create({
  safe: { flex: 1, backgroundColor: M.bg },
  list: { flex: 1 },
  listContent: { paddingHorizontal: S.lg, paddingTop: S.sm, paddingBottom: S.xl },
  header: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingBottom: S.xs,
  },
    headerActions: { flexDirection: 'row', gap: S.sm, alignItems: 'center' },
  gearBtn: {
    width: 44,
    height: 44,
    borderRadius: 22,
    borderWidth: 1,
    borderColor: M.border,
    backgroundColor: M.card,
    alignItems: 'center',
    justifyContent: 'center',
  },
  intro: { gap: 4, marginBottom: S.md },
  sportRow: { flexDirection: 'row', gap: S.md, marginBottom: S.lg },
  sportCardWrap: { flex: 1 },
  sportCard: {
    height: 128,
    borderRadius: 20,
    borderWidth: 2,
    borderColor: M.border,
    backgroundColor: M.card,
    overflow: 'hidden',
  },
  sportCardOn: {
    shadowColor: M.green,
    shadowOffset: { width: 0, height: 0 },
    shadowOpacity: 0.55,
    shadowRadius: 12,
    elevation: 10,
  },
  sportImage: { flex: 1, justifyContent: 'flex-end' },
  sportShade: {
    position: 'absolute',
    top: 0,
    left: 0,
    right: 0,
    bottom: 0,
    backgroundColor: 'rgba(0,0,0,0.42)',
  },
  sportTextWrap: { paddingHorizontal: S.md, paddingBottom: S.md },
  sportLabel: { fontSize: 17, fontWeight: '700' },
  actions: { flexDirection: 'row', gap: S.md, marginBottom: S.lg },
  primaryBtn: {
    flex: 1,
    minHeight: 52,
    borderRadius: 18,
    flexDirection: 'row',
    backgroundColor: M.green,
    alignItems: 'center',
    justifyContent: 'center',
    shadowColor: M.green,
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.35,
    shadowRadius: 12,
    elevation: 6,
  },
  linkRow: { flexDirection: 'row', gap: S.sm, marginBottom: S.lg },
  linkBtn: {
    flex: 1,
    minHeight: 48,
    borderRadius: 18,
    borderWidth: 1.5,
    borderColor: M.border,
    backgroundColor: M.card,
    alignItems: 'center',
    justifyContent: 'center',
  },
  secondaryBtn: {
    flex: 1,
    minHeight: 52,
    borderRadius: 18,
    flexDirection: 'row',
    borderWidth: 1.5,
    borderColor: M.border,
    backgroundColor: M.card,
    alignItems: 'center',
    justifyContent: 'center',
  },
  listHeading: { fontSize: 16, marginBottom: S.sm },
  mineRow: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: S.md,
    padding: S.md,
    borderRadius: 14,
    borderWidth: 1,
    borderColor: M.border,
    backgroundColor: M.card,
    marginBottom: S.sm,
  },
  notice: { alignItems: 'center', gap: S.md, paddingVertical: S.xl },
  retryBtn: {
    minHeight: 44,
    paddingHorizontal: S.lg,
    borderRadius: 16,
    borderWidth: 1.5,
    borderColor: M.border,
    backgroundColor: M.card,
    alignItems: 'center',
    justifyContent: 'center',
  },
  card: {
    gap: S.sm + 4,
    padding: S.md,
    borderRadius: 20,
    borderWidth: 1,
    borderColor: M.border,
    backgroundColor: M.card,
  },
  cardTop: { flexDirection: 'row', gap: S.md, alignItems: 'center' },
  cardThumb: { width: 56, height: 56, borderRadius: 14, backgroundColor: M.cardHi },
  cardTitleRow: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    gap: S.sm,
  },
  metaRow: { flexDirection: 'row', alignItems: 'center', gap: 6 },
  badge: {
    paddingHorizontal: S.sm,
    paddingVertical: 3,
    borderRadius: R.pill,
    backgroundColor: M.cardHi,
  },
  badgeOpen: { backgroundColor: 'rgba(34,197,94,0.14)' },
  badgeText: { fontSize: 11, fontWeight: '800', letterSpacing: 0.8 },
  slotsRow: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between' },
  progressTrack: {
    height: 6,
    borderRadius: R.pill,
    backgroundColor: M.cardHi,
    overflow: 'hidden',
  },
  progressFill: { height: '100%', borderRadius: R.pill, backgroundColor: M.green },
  joinBtn: {
    minHeight: 48,
    borderRadius: 16,
    borderWidth: 1.5,
    borderColor: M.green,
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: 'rgba(34,197,94,0.10)',
  },
  joinBtnDisabled: { opacity: 0.5 },
  emptyCard: {
    alignItems: 'center',
    padding: S.xl,
    marginTop: S.sm,
    borderRadius: 24,
    borderWidth: 1,
    borderColor: M.border,
    backgroundColor: M.card,
  },
  emptyMarkerWrap: { width: 96, height: 96, alignItems: 'center', justifyContent: 'center' },
  emptyRing: {
    position: 'absolute',
    width: 96,
    height: 96,
    borderRadius: 48,
    borderWidth: 2,
    borderColor: M.green,
  },
  emptyMarker: {
    width: 60,
    height: 60,
    borderRadius: 30,
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: 'rgba(34,197,94,0.12)',
    borderWidth: 1,
    borderColor: 'rgba(34,197,94,0.4)',
  },
  emptyCta: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    minHeight: 52,
    alignSelf: 'stretch',
    marginTop: S.lg,
    borderRadius: 18,
    backgroundColor: M.green,
    shadowColor: M.green,
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.35,
    shadowRadius: 12,
    elevation: 6,
  },
  skeleton: {
    flexDirection: 'row',
    gap: S.md,
    alignItems: 'center',
    padding: S.md,
    borderRadius: 20,
    backgroundColor: M.card,
  },
  skeletonThumb: { width: 56, height: 56, borderRadius: 14, backgroundColor: M.cardHi },
  skeletonLine: { height: 12, borderRadius: 6, backgroundColor: M.cardHi },
});
